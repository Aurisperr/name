"use strict";
var glc=document.getElementById('gl');
var DEAD=false,CTX_LOST=false,FRAME_PAUSED=!!document.hidden,FRAME_QUEUED=false;
/* The context is asked for inside a guard.  A machine with WebGL turned off,
   or a browser that refuses it, used to take the whole script down on the
   line below - and the guard that was written to say "the sea god cannot be
   reached on this machine" sat further down and never got the chance. */
var gl=null,DERIV_EXT=null;
try{
  gl=glc.getContext('webgl',{antialias:false,alpha:false,depth:false,stencil:false,
    preserveDrawingBuffer:false,powerPreference:'high-performance'});
  if(gl) DERIV_EXT=gl.getExtension('OES_standard_derivatives');
}catch(e){ gl=null; }
if(!gl) fatal('this browser has not given the piece a webgl context');

/* A float scene buffer keeps the highlights over 1.0 alive. With an 8-bit
   target every bright value is clamped flat at 1.0, so the sun loses its
   white-hot core and the reflection path loses its heat. */
var FLOAT_RT=false,FLOAT_TYPE=0;
(function(){try{
  var cbf=gl.getExtension('WEBGL_color_buffer_float');
  var ohf=gl.getExtension('OES_texture_half_float');
  var ohl=gl.getExtension('OES_texture_half_float_linear');
  if(cbf&&ohf&&ohl){FLOAT_RT=true;FLOAT_TYPE=ohf.HALF_FLOAT_OES;}
}catch(e){}})();

/* The context can also be taken away after it has been handed over.  Without
   a handler the picture goes black for good and the loop goes on burning a
   core asking for frames nobody will ever draw. */
glc.addEventListener('webglcontextlost',function(ev){
  ev.preventDefault();          /* this is what makes the browser give it back */
  CTX_LOST=true;
  var msg='the light has gone out of the water';
  if(uiStatusEl){ uiStatusEl.textContent=msg; lastUIStatus=msg; }
  if(liveEl){ liveEl.textContent=msg; lastLive=msg; }
},false);
glc.addEventListener('webglcontextrestored',function(){
  CTX_LOST=false;
  /* A lost context takes every GL name with it, and the JavaScript still
     holds the old ones, and they still look true.  layout() only makes a new
     framebuffer when it has none to keep, so this one has to be emptied by
     hand or the scene is drawn into a framebuffer that is not there. */
  sceneFbo=null;
  initGL();
  layout();            /* this hands the words on the sand back to the GPU */
  prevT=performance.now();
  scheduleFrame();
},false);
/* Nothing ever reads the GL canvas back, so the drawing buffer does not
   need to be preserved : keeping it costs a full-canvas copy every
   frame, which is exactly the kind of thing a weak machine cannot
   afford and a phone never notices. */
/* The canvas is fixed and fills the window, so its rectangle can be
   cached. Asking for it on every pointer event forces a synchronous
   layout, and a mouse can deliver a hundred of those a second. */
var glRect={left:0,top:0,width:1,height:1};
function refreshGlRect(){
  var r=glc.getBoundingClientRect();
  glRect.left=r.left; glRect.top=r.top;
  glRect.width=r.width||1; glRect.height=r.height||1;
}

/* ==================================================================
   TIDAL ECHO
   night beach · write in the sand · the tide keeps no record
   WebGL · no external assets · no text
   ================================================================== */

/* ==================================================================
   1. SHADERS
   ================================================================== */
var VS_SRC = [
"attribute vec2 aPos;",
"varying vec2 vUv;",
"void main(){ vUv=aPos*0.5+0.5; gl_Position=vec4(aPos,0.0,1.0); }"
].join("\n");

/* shared GLSL : noise + THE wave (scene and erosion must agree on it) */
var LIB = [
(DERIV_EXT?"#extension GL_OES_standard_derivatives : enable":""),
"precision highp float;",
"uniform float uWaveXScale;",
"float hash11(float p){ p=fract(p*0.1031); p*=p+33.33; p*=p+p; return fract(p); }",
"float hash21(vec2 p){ vec3 q=fract(vec3(p.xyx)*0.1031); q+=dot(q,q.yzx+33.33); return fract((q.x+q.y)*q.z); }",
"float vnoise(vec2 p){ vec2 i=floor(p),f=fract(p); f=f*f*(3.0-2.0*f);",
"  return mix(mix(hash21(i),hash21(i+vec2(1.0,0.0)),f.x),",
"             mix(hash21(i+vec2(0.0,1.0)),hash21(i+vec2(1.0,1.0)),f.x),f.y); }",
"float fbm3(vec2 p){ float a=0.5,s=0.0; for(int i=0;i<3;i++){ s+=a*vnoise(p); p*=2.07; a*=0.5; } return s; }",
"float fbm2(vec2 p){ float s=0.5*vnoise(p); s+=0.25*vnoise(p*2.07); return s*1.34; }",
/* the single wave that moves the tide line, shapes the sun and breaks its light */
"float waveShape(float x,float t){",
"  return sin(x*13.5+t*2.05)*0.42 + sin(x*34.2-t*3.15)*0.24",
"       + sin(x*7.2+t*1.15)*0.50 + sin(x*81.0+t*5.20)*0.10; }",
/* The water line is never a ruled line.  Even when the sea is calm it keeps
   a long swell running along the shore - it is the one movement the water
   never stops making - and the foam, the wet sand and the wash are all read
   off that same curve.  The tide only makes the swell deeper, it does not
   invent a new one. */
"float waveY(float x,float base,float amp,float t){",
"  x*=uWaveXScale;",
"  float swell=sin(x*5.30-t*0.27)*0.62+sin(x*8.90+t*0.18)*0.38;",
"  return base+waveShape(x,t)*amp+swell*0.0130; }"
].join("\n");

/* ---------- SCENE ---------- */
/* ---------- SCENE ---------- */
var SCENE_SRC = LIB + [
"varying vec2 vUv;",
"uniform vec2  uRes;",
"uniform float uTime, uTide, uWave, uCharge, uFlash, uWet, uMark;",
"uniform float uDawn,uLit;",
"uniform float uSunUp;",
"uniform float uShore, uMax, uHorizon;",
"uniform vec2  uSun;",
"uniform float uSunR;",
"uniform vec4  uBox;",
"uniform sampler2D uInk, uEro, uInkBlur;",
"uniform vec2  uMouse;",
"uniform float uMouseOn;",
(DERIV_EXT?"float sceneAA(float v){ return max(fwidth(v),1.0/uRes.y); }":"float sceneAA(float v){ return 1.0/uRes.y; }"),

"vec2 boxUv(vec2 uv){ return (uv-uBox.xy)/uBox.zw; }",
"float warmAt(float x){ return smoothstep(0.18,0.60,abs(x-uSun.x)); }",
"float coldAt(float x){ return smoothstep(0.30,0.60,warmAt(x)); }",
"float inkAt(vec2 uv){ vec2 t=boxUv(uv);",
"  if(t.x<0.0||t.x>1.0||t.y<0.0||t.y>1.0) return 0.0;",
"  return texture2D(uInk,t).a; }",
"float eroAt(vec2 uv){ vec2 t=boxUv(uv);",
"  if(t.x<0.0||t.x>1.0||t.y<0.0||t.y>1.0) return 0.0;",
"  return texture2D(uEro,t).r; }",
/* the writing, spread out : a real blur, not a ring of samples */
"float inkBlurAt(vec2 uv){ vec2 t=boxUv(uv);",
"  if(t.x<0.0||t.x>1.0||t.y<0.0||t.y>1.0) return 0.0;",
"  return texture2D(uInkBlur,t).a; }",
/* the mark and everything it casts are one thing : they must leave together */
"float inkE(vec2 uv){ return inkAt(uv)*(1.0-eroAt(uv)); }",

/* ==================================================================
   THE SUN : a furnace seen through a kilometre of wet air.
   One continuous body of light - no hard core, no rim, no rulings -
   with a corona that carries the glow out into the air.
   ================================================================== */
"vec4 sunBody(vec2 uv,float t){",
"  vec2 p=(uv-uSun)*vec2(uRes.x/uRes.y,1.0);",
"  float R=uSunR;",
"  float d=length(p);",
"  float wv=waveShape(p.x*2.2+uSun.x*3.0,t*0.80);",
"  float edge=R*(1.0+0.020*wv);",
"  float k=clamp(d/edge,0.0,1.0);",
"  float ny=clamp(p.y/edge,-1.0,1.0);",
"  float v=ny*0.5+0.5;",
/* --- the body of the light : one continuous falloff, never a second disc --- */
"  float body=pow(max(1.0-k*k,0.0),0.55);",
"  vec3 deep=vec3(0.72,0.38,1.95);",
"  vec3 warm=vec3(6.60,1.00,6.60);",
"  vec3 milk=vec3(7.10,4.40,7.80);",
"  vec3 c=mix(warm,deep,smoothstep(0.86,1.02,k));",
"  c=mix(c,milk,1.0-smoothstep(0.40,0.58,k));",
"/* the sun sits in thick air : the lower half is deeper and cooler */",
"  c*=0.70+0.30*pow(v,0.85);",
"  c=mix(c,c*vec3(1.10,0.82,0.78),(1.0-v)*0.30);",
/* light drifting through the air inside it : broad and slow, never a ruling */
"  float flow=fbm2(vec2(p.x*5.5+t*0.042,p.y*4.2-t*0.026));",
"  c*=0.93+0.15*flow;",
"  float fine=fbm2(p*24.0+vec2(0.0,t*0.15));",
"  c*=0.965+0.07*fine;",
/* the foot of the sun is eaten by the swell */
"  float melt=1.0-smoothstep(-1.00,-0.40,ny);",
"  float eat=smoothstep(-0.40,0.18,waveShape(p.x*3.4+4.0,t*1.05));",
"  float erode=clamp(melt*(0.32+0.84*eat),0.0,1.0);",
"  float soft=1.0-smoothstep(edge*0.84,edge*1.12,d);",
"  float a=soft*(1.0-erode*0.90);",
/* --- the corona : the light that leaves the disc --- */
"  float kx=p.x/max(R,1e-5);",
"  float ky=p.y/max(0.45*R,1e-5);",
"  float gEll=length(vec2(kx,ky));",
"  float halo=exp(-max(d-edge,0.0)*40.0);",
"  float halo2=1.0-smoothstep(1.55,2.05,gEll);",
"  float air=exp(-d*3.4);",
  "  vec3 haloC=vec3(0.24,0.115,0.52)*halo2",
  "           +vec3(0.36,0.18,0.85)*halo+vec3(1.0,0.62,0.95)*air*0.010;",
"  return vec4(c*a+haloC,a);",
"}",
"",
/* only the air around the sun : it bleeds in front of the city, the disc does not */
"vec3 sunGlow(vec2 uv,float t){",
"  vec2 p=(uv-uSun)*vec2(uRes.x/uRes.y,1.0);",
"  float d=length(p);",
"  float R=uSunR;",
"  float glow=exp(-max(d-R,0.0)*14.0);",
"  float glow2=exp(-max(d-R,0.0)*38.0);",
"  float air=exp(-d*7.0);",
"  return vec3(0.95,0.30,1.55)*glow*0.045+vec3(1.00,0.85,1.00)*glow2*0.090+vec3(0.95,0.34,1.45)*glow*0.050",
"        +vec3(0.62,0.26,1.25)*air*0.055;",
"}",

/* the light column breathes with the same swell that moves the tide */
"float swellPulse(vec2 uv,float t,float dep){",
"  float ph=waveShape(uv.x*1.6+2.0,t*0.85);",
"  float beat=0.5+0.5*sin(dep*17.0-t*2.1+ph*1.8);",
"  float crest=smoothstep(-0.25,0.55,ph);",
"  return (0.26+0.92*beat)*(0.46+0.80*crest);",
"}",

/* ---- the glitter path : the sun's own swell, laid on the water ---- */
"float sunPath(vec2 uv,float t,float dep){",
"  float bend=sin(dep*27.0-t*0.62)*0.0045*(0.25+dep*2.4)",
"            +(fbm2(vec2(dep*8.0+t*0.055,2.7))-0.48)*0.018*(0.18+dep*1.35);",
"  float cx=uSun.x+bend-dep*0.040-dep*dep*0.016;",
"  float dx=uv.x-cx;",
"  float pw=(0.014+dep*0.26)*(0.72+0.38*fbm2(vec2(dep*10.0-t*0.035,6.1)));",
"  float sideScale=dx<0.0?0.78:1.08;",
"  float inPath=1.0-smoothstep(pw*0.16,pw,abs(dx)*sideScale);",
"  if(inPath<=0.0) return 0.0;",
"  float cellX=0.0034+dep*0.021;",
"  float cellY=0.0019+dep*0.0105;",
"  vec2 q=vec2(dx/cellX+(fbm2(vec2(dep*44.0,dx*18.0))-0.5)*1.10,",
"              (dep*dep*4.0+dep*0.72)/cellY);",
"  q.y+=(fbm2(vec2(dx*27.0,dep*73.0-t*0.13))-0.5)*1.70+sin(q.x*0.41+t*0.18)*0.32;",
/* the swell shears the whole field : every flake is dragged sideways by
   the same wave that moves the tide, so the light lies along the water
   instead of sitting on it in squares */
"  q+=vec2(waveShape(uv.x*2.4+dep*3.2,t*0.72),",
"          waveShape(uv.x*3.7-dep*2.1,t*0.54))*1.25;",
"  vec2 id=floor(q);",
"  vec2 cf=fract(q)-0.5;",
"  float h=hash21(id+vec2(dx<0.0?7.3:19.1,3.7));",
"  vec2 jit=vec2(hash21(id+4.1),hash21(id+8.6))-0.5;",
"  float stretch=0.30+0.22*hash11(id.y*2.9+1.0);",
"  float d=length(vec2((cf.x-jit.x*0.58)*stretch,(cf.y-jit.y*0.34)*2.15));",
"  float sp=1.0-smoothstep(0.045,0.185,d);",
"  float on=step(0.48,h);",
/* a flake is water, not a bulb : it goes out as often as it comes on,
   each one on its own phase, and now and then a whole patch drops out */
"  float fl=hash21(id+vec2(23.7,5.9));",
"  float twinkle=0.16+0.84*pow(0.5+0.5*sin(t*(0.42+0.62*fl)+fl*57.0),5.0);",
"  float patch=0.30+0.70*smoothstep(0.30,0.70,fbm2(vec2(dx*9.0+dep*4.0,dep*26.0-t*0.07)));",
"  float cut=smoothstep(0.26,0.68,fbm2(vec2(dx*31.0+dep*8.0,dep*118.0-t*0.14)));",
"  float core=exp(-((dx/(pw*0.32))*(dx/(pw*0.32))));",
"  float wide=exp(-((dx/(pw*0.62))*(dx/(pw*0.62))))*smoothstep(0.37,0.68,fbm2(vec2(dx*51.0+dep*17.0,dep*155.0-t*0.11)));",
"  float ripple=pow(0.5+0.5*sin(dep*96.0+sin(dx/max(pw,0.001)*3.2+t*0.26)*0.72),7.0);",
/* the crest itself throws a second, finer set of bands across the flakes */
"  float ripple2=pow(0.5+0.5*sin(dep*232.0-waveShape(dx*5.4,t*0.9)*1.7-uv.x*14.0),9.0);",
"  float bar=ripple*inPath*smoothstep(0.30,0.72,cut)*0.055;",
"  bar+=ripple2*inPath*smoothstep(0.44,0.86,cut)*0.026*patch;",
"  float amp=smoothstep(0.0,0.012,dep);",
"  float asym=0.68+0.48*smoothstep(-pw,pw,dx);",
"  float flicker=0.80+0.20*sin(t*0.20+dep*76.0)+0.10*sin(t*0.85+dep*23.0);",
"  return inPath*amp*asym*flicker*patch*",
"         (sp*on*twinkle*(0.36+1.05*cut)+core*0.10*(0.55+0.45*cut)*twinkle+wide*0.12+bar);",
"}",
/* ==================================================================
   THE DIVIDE : the line where the sea stops and the air begins.
   It is water, not ink : a ruled line has no life in it. A long swell,
   a short chop that arrives in patches, and a slow drift of noise all
   move it, and the pixels nearest the seam are bent by its slope, so
   the two halves never meet along one dead edge.
   ================================================================== */
"float hzLine(float x,float t){",
"/* The divide is a ruled line. A wandering horizon cannot sit in the same",
"   frame as a ruled datum line : one of the two has to give, and the",
"   datum line is the instrument, so the sea gives. */",
"  return uHorizon; }",
/* the local slope of that divide : what bends light at the seam */
"float hzSlope(float x,float t){ return (hzLine(x+0.0030,t)-hzLine(x-0.0030,t))/0.0060; }",


/* the rain landing on a surface : a ring that opens and a small flash */
,

/* the night sky : ink-blue zenith, oxidized copper haze, hot sodium
   near the horizon. The striations are atmospheric, not wallpaper. */
/* Stars are what keeps the upper frame from reading as a painted wash.
   They are sparse, cold and mostly still : a field of pinpricks, not sparkle. */
"float starField(vec2 uv,float t){",
"  vec2 p=vec2(uv.x*uRes.x/uRes.y,uv.y);",
"  vec2 g=p*190.0;",
"  vec2 id=floor(g);",
"  vec2 f=fract(g)-0.5;",
"  float h=hash21(id);",
"  float gal=exp(-(((uv.y-(uHorizon+0.285+uv.x*0.10))/0.072)*((uv.y-(uHorizon+0.285+uv.x*0.10))/0.072)));",
"  float on=min(1.0,step(0.9742,h)+step(0.9862,h)*gal*1.9);",
"  float tw=0.62+0.38*sin(t*(0.7+h*4.0)+h*57.0);",
"  float s=(1.0-smoothstep(0.0,0.36,length(f)))*on*tw;",
"  float big=step(0.9994,hash21(id+vec2(7.0,3.0)));",
"  s+=big*(1.0-smoothstep(0.0,0.11,length(f)))*1.55;",
"  return s*(0.30+0.70*h);",
"}",
"vec3 skyStrata(vec2 uv,float t){",
"  float above=max(uv.y-uHorizon,0.0);",
/* The screen ruling is an absorbing texture, not emissive neon. */
"  float warp=fbm2(vec2(uv.x*0.72+2.0,uv.y*0.58))*1.8;",
"  float yb=(uv.y-uHorizon)*22.0-t*0.010+warp*0.45;",
"  float broad=1.0-smoothstep(0.02,0.18,abs(fract(yb)-0.5));",
"  float paper=0.978+0.022*fbm2(vec2(uv.x*34.0+4.0,uv.y*53.0));",
"  float grain=0.972+0.028*fbm2(vec2(uv.x*92.0+3.0,uv.y*310.0+t*0.006));",
"  float ink=broad*exp(-above*1.5)*0.022;",
"  vec3 shade=mix(vec3(1.0),vec3(0.93,0.86,0.89),ink);",
"  return shade*paper*mix(vec3(1.0),vec3(grain),0.45);",
"}",
"float sunShafts(vec2 uv,float t){",
"  vec2 p=(uv-uSun)*vec2(uRes.x/uRes.y,1.0);",
"  float d=length(p);",
"  float a=atan(p.y,p.x);",
"  float s=0.0;",
"  for(int i=0;i<4;i++){",
"    float fi=float(i);",
"    float ang=hash11(fi*3.7+1.0)*6.2831+sin(t*0.035+fi*1.7)*0.10;",
"    float wdt=0.035+0.030*hash11(fi*5.1+2.0);",
"    s+=exp(-(((a-ang)/wdt)*((a-ang)/wdt)))*(0.55+0.45*hash11(fi*7.3+3.0));",
"  }",
"  float cut=1.0-smoothstep(uSunR*1.03,uSunR*1.48,d);",
"  return s*exp(-d*2.2)*cut;",
"}",
"vec3 airTraffic(vec2 uv,float t){",
"  vec3 c=vec3(0.0);",
"  float asp=uRes.x/uRes.y;",
"  for(int i=0;i<7;i++){",
"    float fi=float(i);",
"    float dir=i<4?1.0:-1.0;",
"    float speed=0.012+0.026*hash11(fi*5.3+2.0);",
"    float phase=fract(hash11(fi*8.1+4.0)+t*speed);",
"    float x=dir>0.0?mix(-0.08,1.08,phase):mix(1.08,-0.08,phase);",
"    float y=uHorizon+0.105+fi*0.040+0.006*sin(t*0.045+fi*2.7);",
"    y+=0.004*sin(x*9.0+t*0.12+fi);",
"    float sideW=0.0060+0.0016*hash11(fi*3.1+7.0);",
"    float sideH=0.00145+0.00025*hash11(fi*7.7+2.0);",
"    float edgeX=1.0-smoothstep(sideW-0.00020,sideW+0.00020,abs((uv.x-x)*asp));",
"    float edgeY=1.0-smoothstep(sideH-0.00018,sideH+0.00018,abs(uv.y-y));",
"    float lower=(1.0-smoothstep(0.42,0.92,abs(uv.y-(y-sideH))*uRes.y))*edgeX;",
"    float canopy=(1.0-smoothstep(0.42,0.92,abs(uv.y-(y+sideH*0.45))*uRes.y))",
"                *(1.0-smoothstep(sideW*0.50,sideW*0.55,abs((uv.x-x)*asp)));",
"    float back=(x-uv.x)*dir;",
"    float tailGate=step(0.0,back)*(1.0-smoothstep(0.012,0.078,back));",
"    float tailLine=(1.0-smoothstep(0.42,0.92,abs(uv.y-(y-sideH*0.72))*uRes.y))*tailGate;",
"    float tailDash=step(0.22,fract(back*68.0+t*0.08));",
"    vec3 tint=(i==0||i==3)?vec3(0.22,0.74,1.00):vec3(1.06,1.11,1.26);",
"    c+=tint*(edgeX*edgeY*0.18+lower*0.66+canopy*0.22+tailLine*tailDash*0.24);",
"  }",
"  for(int j=0;j<3;j++){",
"    float fj=float(j);",
"    float x=0.33+fj*0.19+0.010*sin(t*0.07+fj*2.0);",
"    float y=uHorizon+0.075+fj*0.022+0.004*sin(t*0.31+fj);",
"    float dw=1.0-smoothstep(0.0011,0.00145,abs((uv.x-x)*asp));",
"    float dh=1.0-smoothstep(0.00055,0.00085,abs(uv.y-y));",
"    float mast=(1.0-smoothstep(0.38,0.82,abs(uv.x-x)*uRes.x))",
"              *step(y-0.008,uv.y)*step(uv.y,y);",
"    float foot=(1.0-smoothstep(0.38,0.82,abs(uv.y-(y-0.008))*uRes.y))",
"              *step(abs((uv.x-x)*asp),0.0014);",
"    c+=vec3(1.06,1.11,1.26)*(dw*dh*0.34+dw*dh*0.08)+vec3(0.16,0.36,0.58)*(mast*0.20+foot*0.10);",
"  }",
"  for(int l=0;l<2;l++){",
"    float fl=float(l);",
"    float ly=uHorizon+0.175+fl*0.135+0.004*sin(uv.x*7.5+t*0.025+fl*2.0);",
"    float lane=1.0-smoothstep(0.45,0.95,abs(uv.y-ly)*uRes.y);",
"    float dash=step(0.60,fract(uv.x*(15.0+fl*5.0)+t*(0.020+fl*0.012)));",
"    float gate=smoothstep(0.18,0.23,uv.x)*(1.0-smoothstep(0.88,0.93,uv.x));",
"    vec3 laneC=fl<0.5?vec3(1.06,1.11,1.26):vec3(0.30,0.70,1.00);",
"    c+=laneC*lane*dash*gate*0.032;",
"  }",
"  return c;",
"}",
/* dark vehicle shells sit under the moving lights, so traffic reads as traffic */
"float airTrafficBody(vec2 uv,float t){",
"  float mask=0.0;",
"  float asp=uRes.x/uRes.y;",
"  for(int i=0;i<7;i++){",
"    float fi=float(i);",
"    float dir=i<4?1.0:-1.0;",
"    float speed=0.012+0.026*hash11(fi*5.3+2.0);",
"    float phase=fract(hash11(fi*8.1+4.0)+t*speed);",
"    float x=dir>0.0?mix(-0.08,1.08,phase):mix(1.08,-0.08,phase);",
"    float y=uHorizon+0.105+fi*0.040+0.006*sin(t*0.045+fi*2.7);",
"    y+=0.004*sin(x*9.0+t*0.12+fi);",
"    float sideW=0.0060+0.0016*hash11(fi*3.1+7.0);",
"    float sideH=0.00145+0.00025*hash11(fi*7.7+2.0);",
"    float shell=1.0-smoothstep(sideW-0.00028,sideW+0.00028,abs((uv.x-x)*asp));",
"    shell*=1.0-smoothstep(sideH-0.00024,sideH+0.00024,abs(uv.y-y));",
"    float canopy=1.0-smoothstep(sideW*0.54,sideW*0.58,abs((uv.x-x)*asp));",
"    canopy*=1.0-smoothstep(sideH*0.52,sideH*0.57,abs(uv.y-(y+sideH*0.46)));",
"    mask=max(mask,max(shell,canopy*0.72)*0.58);",
"  }",
"  for(int j=0;j<3;j++){",
"    float fj=float(j);",
"    float x=0.33+fj*0.19+0.010*sin(t*0.07+fj*2.0);",
"    float y=uHorizon+0.075+fj*0.022+0.004*sin(t*0.31+fj);",
"    float block=1.0-smoothstep(0.0010,0.00120,abs((uv.x-x)*asp));",
"    block*=1.0-smoothstep(0.00050,0.00075,abs(uv.y-y));",
"    mask=max(mask,block*0.42);",
"  }",
"  return mask;",
"}",
/* a lone patrol skiff gives the sea a believable scale cue.
   It crosses so slowly that you only catch it moving if you wait, and
   everything it disturbs is attached to it : the churn under the stern,
   the two arms of the wake, the rings running out of the hull, the last
   of the foam, and the spray still catching the low sun. */
"vec4 seaCraft(vec2 uv,float t){",
"  float asp=uRes.x/uRes.y;",
/* the crossing : one full pass takes a little under three minutes, and it
   starts where the old fixed mark stood */
"  float x=0.095+0.845*fract(0.8157+t*0.0056);",
"  float y=uHorizon-0.022+0.0008*sin(t*0.62)",
"         +waveShape(uv.x*22.0,t*1.15)*0.00055;",
"  float px0=(uv.x-x)*asp;",
"  float py0=uv.y-y;",
"  float back=-px0;",
"  float ahead=px0;",
"  float hull=step(abs(uv.x-x),0.0155)*step(abs(uv.y-y),0.0032);",
"  float deck=step(abs(uv.x-x+0.001),0.0105)*step(abs(uv.y-(y+0.0042)),0.0021);",
"  float cabin=step(abs(uv.x-x+0.0015),0.0042)*step(abs(uv.y-(y+0.0082)),0.0034);",
"  float body=max(hull,max(deck,cabin));",
"  vec3 col=mix(vec3(0.026,0.021,0.030),vec3(0.090,0.042,0.070),hull);",
"  float mast=step(abs(uv.x-(x-0.002)),0.00040)*step(y+0.009,uv.y)*step(uv.y,y+0.021);",
"  col=mix(col,vec3(0.20,0.12,0.18),mast);",
"  body=max(body,mast);",
"  vec2 redP=vec2((uv.x-(x-0.010))*asp,uv.y-y);",
"  vec2 cyanP=vec2((uv.x-(x+0.010))*asp,uv.y-y);",
"  float redBox=1.0-smoothstep(0.0011,0.00145,abs(redP.x));",
"  redBox*=1.0-smoothstep(0.00055,0.00080,abs(redP.y));",
"  float cyanBox=1.0-smoothstep(0.0011,0.00145,abs(cyanP.x));",
"  cyanBox*=1.0-smoothstep(0.00055,0.00080,abs(cyanP.y));",
"  float redLine=(1.0-smoothstep(0.38,0.82,abs(redP.y)*uRes.y))",
"               *step(abs(redP.x),0.00155);",
"  float cyanLine=(1.0-smoothstep(0.38,0.82,abs(cyanP.y)*uRes.y))",
"                *step(abs(cyanP.x),0.00155);",
"  float hullLine=(1.0-smoothstep(0.38,0.82,abs(uv.y-(y-0.0030))*uRes.y))",
"                 *step(abs(uv.x-x),0.0145);",
"  float wake=0.0,vArm=0.0,churn=0.0,rings=0.0,foam=0.0,sparkle=0.0;",
/* ---- the wake, in four parts. A skiff disturbs a patch of sea a couple
       of hundred pixels wide and nothing else in the frame, so most pixels
       leave here without touching any of it. ---- */
"  if(abs(px0)<0.26&&abs(py0)<0.075){",
"    float hzS=hzLine(uv.x,t);",
"    float onSea=1.0-smoothstep(hzS-0.0016,hzS+0.0022,uv.y);",
"    float wakeGate=step(0.0,back)*(1.0-smoothstep(0.006,0.072,back))*onSea;",
/* Everything the boat has touched lies astern of her.  The gate used to
   stand open in front as well, so the boil of the propeller was painted
   over the whole sheet of water ahead of the bow : a broad rectangle of
   noise with the boat at one end of it.  A wake is a trail, and a trail
   is behind the boat that made it. */
/* and nothing in the trail may end on a ruled edge : the whole wake dies
   out with the distance from the hull, never on a straight line */
"    float vEnv=1.0-smoothstep(0.020,0.068,abs(py0-0.003));",
/* the flat boil of water the propeller is still tearing up : a small
   patch right behind the stern, and nothing at all in front of it */
"    float stern=smoothstep(0.0012,0.0080,back)*(1.0-smoothstep(0.009,0.032,back));",
"    float boil=1.0-smoothstep(0.004,0.019,abs(py0-0.0014));",
"    float ch=stern*boil*(0.30+0.70*fbm2(vec2(uv.x*160.0+back*40.0,py0*300.0-t*1.20)))*onSea;",
/* the two arms of the V, opening astern */
"    float vw=0.0022+back*0.22;",
"    float va=(exp(-(((abs(py0-0.0042)-back*0.030)/vw)*((abs(py0-0.0042)-back*0.030)/vw)))",
"            +exp(-(((abs(py0-0.0042)-back*0.055)/(vw*1.7))*((abs(py0-0.0042)-back*0.055)/(vw*1.7))))*0.55)",
"            *wakeGate*vEnv*(0.26+0.74*fbm2(vec2(back*58.0,py0*190.0-t*0.80)));",
/* rings running outward from the hull, astern only */
"    float bd=length(vec2(px0,py0*2.1));",
"    float rg=0.0;",
"    for(int i=0;i<3;i++){",
"      float fi=float(i);",
"      float ph=fract(t*0.11+fi*0.334+hash11(fi*5.3+1.0));",
"      float rad=0.007+ph*0.086;",
"      float ring=1.0-smoothstep(0.0,0.0019+ph*0.0017,abs(bd-rad));",
"      rg+=ring*(1.0-ph)*(1.0-ph)*step(0.30,hash11(fi*3.7+2.0));",
"    }",
/* the arcs open behind the stern : the bow of a boat does not trail rings
   of its own, and the forward half of them only made the trail wider */
"    rg*=(1.0-smoothstep(-0.004,0.024,ahead))*onSea",
"          *(0.28+0.72*fbm2(vec2(uv.x*58.0-t*0.32,py0*145.0)));",
/* foam that has not gone under yet */
"    foam=wakeGate*vEnv*(1.0-smoothstep(0.010,0.055,back))",
"         *smoothstep(0.24,0.70,fbm2(vec2(uv.x*200.0,py0*440.0-t*1.70)));",
/* and the spray, one grain at a time */
"    vec2 sg=vec2(uv.x*250.0,py0*600.0-t*0.55);",
"    vec2 sid=floor(sg);",
"    vec2 sf=fract(sg)-0.5;",
"    float sh=hash21(sid+3.1);",
"    float sph=fract(t*0.30+sh*17.0);",
"    sparkle=(1.0-smoothstep(0.0,0.17,length(sf*vec2(1.0,1.4))))",
"            *step(0.970,sh)*smoothstep(0.0,0.05,sph)*(1.0-smoothstep(0.12,0.34,sph))",
"            *wakeGate*vEnv*(1.0-smoothstep(0.020,0.070,back));",
"    wake=wakeGate*vEnv*smoothstep(0.22,0.78,fbm2(vec2(uv.x*95.0,t*0.12)));",
"    vArm=va; churn=ch; rings=rg;",
"  }",
"  col+=vec3(1.06,1.11,1.26)*(redBox*0.76+redLine*0.92);",
"  col+=vec3(0.10,0.64,0.90)*(cyanBox*0.72+cyanLine*0.90);",
"  col+=vec3(0.34,0.50,0.76)*hullLine*0.26;",
"  col+=mix(vec3(0.30,0.15,0.24),vec3(1.06,1.11,1.26),0.35)",
"      *(wake*0.30+vArm*0.62+churn*0.38);",
"  col+=mix(vec3(0.22,0.34,0.52),vec3(1.06,1.11,1.26),0.30)*rings*(0.22+0.14*uSunUp);",
"  col+=mix(vec3(1.00,0.40,0.62),vec3(1.06,1.11,1.26),0.42)*foam*0.40;",
"  col+=vec3(1.00,0.92,0.97)*sparkle*1.00;",
"  float alpha=max(body*0.88,max(redBox,cyanBox)*0.70);",
"  alpha=max(alpha,max(redLine,cyanLine)*0.92);",
"  float wash=max(max(hullLine*0.26,wake*0.16),max(vArm*0.38,churn*0.28));",
"  alpha=max(alpha,max(max(rings*0.30,foam*0.42),sparkle*0.95));",
"  return vec4(col,clamp(max(alpha,wash),0.0,1.0));",
"}",
/* the four near landmarks carry a slow turning lamp : faint, but it is the
   only thing on this skyline with a direction of its own */
"vec3 landmarkSweep(vec2 uv,float t){",
"  vec3 c=vec3(0.0);",
"  for(int i=0;i<4;i++){",
"    float fi=float(i);",
"    float cx=fi<0.5?0.076:(fi<1.5?0.245:(fi<2.5?0.858:0.951));",
"    float oy=uHorizon+(fi<0.5?0.235:(fi<1.5?0.140:(fi<2.5?0.188:0.138)))+0.030;",
"    vec2 p=(uv-vec2(cx,oy))*vec2(1.0,0.80);",
"    float rad=length(p);",
"    if(rad<0.20){",
"      float ang=atan(p.y,p.x);",
"      float spin=t*(0.19+0.05*fi)+fi*1.73;",
"      float beam=max(exp(-((sin((ang-spin)*0.5)/0.040)*(sin((ang-spin)*0.5)/0.040))),",
"                    exp(-((sin((ang-spin-3.1416)*0.5)/0.062)*(sin((ang-spin-3.1416)*0.5)/0.062)))*0.45);",
"      c+=mix(vec3(0.30,0.68,1.00),vec3(1.00,0.44,0.72),hash11(fi*3.1+2.0))",
"          *beam*exp(-rad*13.0)*smoothstep(0.0,0.006,rad)*0.072;",
"    }",
"  }",
"  return c; }",
"vec3 searchLights(vec2 uv,float t){",
"  vec3 c=vec3(0.0);",
"  float asp=uRes.x/uRes.y;",
"  for(int i=0;i<2;i++){",
"    float fi=float(i);",
"    vec2 o=vec2(i==0?0.205:0.842,uHorizon-0.004);",
"    vec2 p=vec2((uv.x-o.x)*asp,uv.y-o.y);",
"    float a=(i==0?1.25:1.88)+sin(t*0.032+fi*2.2)*0.065;",
"    vec2 dir=vec2(cos(a),sin(a));",
"    float along=dot(p,dir);",
"    float across=abs(dot(p,vec2(-dir.y,dir.x)));",
"    float wdt=0.0045+max(along,0.0)*0.045;",
"    float beam=exp(-((across/wdt)*(across/wdt)));",
"    float body=smoothstep(0.0,0.025,along)*exp(-max(along,0.0)*12.0)",
"              *(1.0-smoothstep(0.085,0.210,along));",
"    float baseGlow=exp(-(((uv.x-o.x)*asp/0.025)*((uv.x-o.x)*asp/0.025))",
"                     -(((uv.y-o.y)/0.010)*((uv.y-o.y)/0.010)));",
"    vec3 tint=mix(vec3(1.06,1.11,1.26),vec3(0.30,0.70,1.00),coldAt(uv.x));",
"    c+=tint*(beam*body*(0.007+0.002*sin(t*0.12+fi))+baseGlow*0.010);",
"  }",
"  return c;",
"}",
,
"vec3 cloudStrata(vec2 uv,float t){",
"  vec3 c=vec3(0.0);",
"  float azx=exp(-(((uv.x-uSun.x)/0.45)*((uv.x-uSun.x)/0.45)));",
"  for(int L=0;L<2;L++){",
"    float fl=float(L);",
"    float yb=uHorizon+0.085+fl*0.185;",
"    float n=fbm3(vec2(uv.x*2.8+fl*9.0+t*0.010,fl*5.0+t*0.004));",
"    float band=smoothstep(0.44,0.86,n)*exp(-(((uv.y-yb)/(0.055+fl*0.03))*((uv.y-yb)/(0.055+fl*0.03))));",
"    vec3 cc=mix(vec3(0.022,0.015,0.026),vec3(0.070,0.046,0.048),azx)*(1.0-0.36*fl)+vec3(0.005,0.010,0.021)*fl;",
"    c+=cc*band*(1.0-fl*0.30)*0.82;",
"  }",
"  return c;",
"}",

/* ==================================================================
   THE SKYLINE : boxes with volume, setbacks, windows, neon and haze
   ================================================================== */
"vec4 heroTower(vec2 uv,float t,float id){",
"  float cx=id<0.5?0.082:(id<1.5?0.205:(id<2.5?0.862:0.955));",
"  float fw=id<0.5?0.030:(id<1.5?0.019:(id<2.5?0.037:0.024));",
"  float hgt=id<0.5?0.205:(id<1.5?0.115:(id<2.5?0.176:0.135));",
"  float sideW=fw*(0.34+0.12*hash11(id*6.3+4.0));",
"  float top=uHorizon+hgt;",
"  float aa=1.15/max(uRes.y,1.0);",
"  float frontL=cx-fw,frontR=cx+fw,sideR=frontR+sideW;",
/* keep the detailed facade work inside each landmark's coarse silhouette */
"  if(uv.x<frontL-0.010||uv.x>sideR+0.010||uv.y<uHorizon-aa||uv.y>top+0.070) return vec4(0.0);",
"  float frontMask=smoothstep(frontL-aa,frontL+aa,uv.x)*(1.0-smoothstep(frontR-aa,frontR+aa,uv.x))",
"                *smoothstep(uHorizon-aa,uHorizon+aa,uv.y)*(1.0-smoothstep(top-aa,top+aa,uv.y));",
"  float sideU=clamp((uv.x-frontR)/max(sideW,0.001),0.0,1.0);",
"  float sideTop=top-(0.003+0.012*hash11(id*7.1+3.0))*sideU;",
"  float sideMask=smoothstep(frontR-aa,frontR+aa,uv.x)*(1.0-smoothstep(sideR-aa,sideR+aa,uv.x))",
"               *smoothstep(uHorizon-aa,uHorizon+aa,uv.y)*(1.0-smoothstep(sideTop-aa,sideTop+aa,uv.y));",
"  float shoulderW=fw*(1.14+0.14*hash11(id*9.0+2.0));",
"  float shoulderTop=uHorizon+hgt*(0.18+0.08*hash11(id*4.0+8.0));",
"  float shoulderMask=smoothstep(cx-shoulderW-aa,cx-shoulderW+aa,uv.x)",
"                    *(1.0-smoothstep(cx+shoulderW-aa,cx+shoulderW+aa,uv.x))",
"                    *smoothstep(uHorizon-aa,uHorizon+aa,uv.y)*(1.0-smoothstep(shoulderTop-aa,shoulderTop+aa,uv.y));",
"  float crownW=fw*(0.48+0.16*hash11(id*3.6+1.0));",
"  float crownTop=top+(0.008+0.018*hash11(id*2.2+5.0));",
"  float crownMask=smoothstep(cx-crownW-aa,cx-crownW+aa,uv.x)",
"                  *(1.0-smoothstep(cx+crownW-aa,cx+crownW+aa,uv.x))",
"                  *smoothstep(top-aa,top+aa,uv.y)*(1.0-smoothstep(crownTop-aa,crownTop+aa,uv.y));",
"  float roofMask=smoothstep(frontL-0.002-aa,frontL-0.002+aa,uv.x)",
"                *(1.0-smoothstep(sideR+0.002-aa,sideR+0.002+aa,uv.x))",
"                *smoothstep(top-aa,top+aa,uv.y)*(1.0-smoothstep(top+0.0038-aa,top+0.0038+aa,uv.y));",
"  float m=max(max(frontMask,sideMask),max(shoulderMask,crownMask));",
"  m=max(m,roofMask);",
/* an early rejection prevents four full facade evaluations per screen pixel */
"  if(m<0.001) return vec4(0.0);",
"  float onSide=smoothstep(frontR-aa,frontR+aa,uv.x);",
"  float frontU=clamp((uv.x-frontL)/max(2.0*fw,0.001),0.0,1.0);",
"  float vertical=clamp((uv.y-uHorizon)/max(hgt,0.001),0.0,1.0);",
"  float rib=1.0-smoothstep(0.025,0.055,abs(fract(frontU*8.0+0.11)-0.5));",
"  float floorLine=1.0-smoothstep(0.035,0.075,abs(fract((top-uv.y)/0.0105)-0.5));",
"  vec3 front=vec3(0.0620,0.0530,0.1950)+vec3(0.0310,0.0240,0.0750)*frontU;",
"  front*=0.63+0.37*vertical;",
"  front*=0.82+0.18*rib;",
"  front*=0.88+0.12*floorLine;",
"  vec3 side=vec3(0.0780,0.0560,0.2300)+vec3(0.0350,0.0240,0.0840)*(1.0-sideU);",
"  side*=0.54+0.46*vertical;",
"  vec3 bc=mix(front,side,onSide);",
"  bc=mix(bc,vec3(0.015,0.008,0.022),roofMask*0.72);",
"  bc=mix(bc,front*0.76,shoulderMask*(1.0-onSide));",
"  bc=mix(bc,vec3(0.010,0.006,0.012),crownMask);",
"  vec3 em=vec3(0.0);",
"  vec2 wg=vec2(frontU*14.0,(top-uv.y)/0.0108);",
"  vec2 wc=floor(wg),wf=fract(wg);",
"  float glass=step(0.29,wf.x)*step(wf.x,0.73)*step(0.31,wf.y)*step(wf.y,0.70);",
"  float lit=smoothstep(0.73,0.83,hash21(wc+id*50.0+3.1));",
"  float wrh=hash21(wc+id*11.0);",
"  float warmZ=smoothstep(0.18,0.60,abs(uv.x-uSun.x));",
"  float coldT=mix(0.90,0.42,warmZ);",
"  vec3 winCol=mix(vec3(1.06,1.11,1.26),vec3(0.50,0.78,1.00),step(coldT,wrh)*step(wrh,0.86));",
"  winCol=mix(winCol,vec3(1.000,0.438,0.726),step(0.86,wrh));",
"  float pulse=0.72+0.28*sin(t*(0.34+0.28*hash11(wc.y+id))+hash11(wc.x+id)*5.0);",
"  em+=winCol*glass*lit*pulse*(1.0-onSide)*(0.15+0.13*vertical);",
"  vec2 swg=vec2(sideU*7.0,(sideTop-uv.y)/0.0125);",
"  vec2 swc=floor(swg),swf=fract(swg);",
"  float sideGlass=step(0.34,swf.x)*step(swf.x,0.68)*step(0.37,swf.y)*step(swf.y,0.68);",
"  em+=mix(vec3(1.06,1.11,1.26),vec3(1.06,1.11,1.26),step(0.48,hash21(swc+id*5.0)))",
"     *sideGlass*step(0.74,hash21(swc+id*23.0))*onSide*0.10;",
"  float leftEdge=1.0-smoothstep(0.0,0.0012,abs(uv.x-frontL))*step(uHorizon,uv.y)*step(uv.y,top);",
"  float rightEdge=1.0-smoothstep(0.0,0.0012,abs(uv.x-frontR))*step(uHorizon,uv.y)*step(sideTop,uv.y);",
"  float backEdge=1.0-smoothstep(0.0,0.0013,abs(uv.x-sideR))*step(uHorizon,uv.y)*step(sideTop,uv.y);",
"  float roofEdge=1.0-smoothstep(0.0,0.0014,abs(uv.y-top))*step(frontL,uv.x)*step(uv.x,sideR);",
"  em+=vec3(1.000,0.376,0.696)*leftEdge*0.115;",
"  em+=vec3(1.06,1.11,1.26)*rightEdge*0.055;",
"  em+=vec3(1.000,0.360,0.688)*backEdge*0.13;",
"  em+=vec3(0.16,0.52,0.92)*roofEdge*0.13;",
"  float bandY=uHorizon+hgt*(0.52+0.16*hash11(id*12.0+1.0));",
"  float band=exp(-(((uv.y-bandY)/0.0019)*((uv.y-bandY)/0.0019)))*step(frontL,uv.x)*step(uv.x,frontR);",
"  float bandBreak=0.45+0.55*smoothstep(0.30,0.72,fbm2(vec2(uv.x*27.0+id*9.0,t*0.035)));",
"  em+=mix(vec3(1.06,1.11,1.26),vec3(1.06,1.11,1.26),step(0.62,hash11(id*8.0+3.0)))*band*bandBreak*0.13;",
/* Holographic advertising is recessed into the facade, never a free-standing light column. */
"  float adOn=clamp(step(id,0.35)+step(1.65,id),0.0,1.0);",
"  float adW=fw*0.66,adH=0.020+0.006*hash11(id*5.0+2.0);",
"  float adX=cx+fw*(0.03+0.08*hash11(id*3.0+7.0));",
"  float adY=uHorizon+hgt*(0.44+0.13*hash11(id*4.0+4.0));",
"  vec2 ap=abs(vec2((uv.x-adX)/adW,(uv.y-adY)/adH));",
"  float adPanel=step(ap.x,1.0)*step(ap.y,1.0)*adOn;",
"  float adFrame=adPanel*(1.0-smoothstep(0.72,0.98,min(1.0-ap.x,1.0-ap.y)));",
"  float adScan=0.52+0.48*pow(0.5+0.5*sin((uv.y-adY)*290.0-t*4.2),8.0);",
"  float adBars=step(0.30,fract((uv.x-adX)/0.0042))*step(fract((uv.y-adY+adH)/0.0055),0.52);",
"  em+=mix(vec3(0.18,0.62,1.00),vec3(0.48,0.86,1.00),step(0.5,hash11(id*17.0)))",
"     *adPanel*(0.026+0.105*adScan*adBars);",
"  em+=vec3(0.18,0.62,1.00)*adFrame*0.22;",
"  float mastX=cx+fw*0.34;",
"  float mastH=0.018+0.026*hash11(id*2.7+6.0);",
"  float mast=step(0.58,hash11(id*5.1+9.0))*(1.0-smoothstep(0.00035,0.00075,abs(uv.x-mastX)))",
"             *step(crownTop-0.001,uv.y)*step(uv.y,crownTop+mastH);",
"  em+=vec3(0.44,0.22,0.30)*mast*0.38;",
"  float beacon=1.0-smoothstep(0.0,0.0015,length((uv-vec2(mastX,crownTop+mastH))*vec2(1.0,0.42)));",
"  em+=vec3(1.000,0.282,0.650)*beacon*step(0.58,hash11(id*5.1+9.0))",
"     *(0.20+0.80*step(0.52,sin(t*2.55+id*1.7)));",
"  return vec4(bc+em,m);",
"}",
"vec4 landmarkCity(vec2 uv,float t){",
"  vec3 body=vec3(0.0);",
"  float mask=0.0;",
"  for(int i=0;i<4;i++){",
"    vec4 h=heroTower(uv,t,float(i));",
"    body=mix(body,h.rgb,h.a);",
"    mask=max(mask,h.a);",
"  }",
"  return vec4(body,mask);",
"}",
"vec4 cityLayer(vec2 uv,float t){",
"  vec3 col=vec3(0.0);",
"  vec3 airLights=vec3(0.0);",
"  float has=0.0;",
"  float asp=uRes.x/uRes.y;",
"  float sunGap=(uSunR+0.014)/asp;",
"  float gapL=uSun.x-sunGap, gapR=uSun.x+sunGap;",
/* Far, middle and near fields use radically different scales. Reducing the
   field count is what restores negative space and makes the city legible. */
"  for(int i=0;i<3;i++){",
"    float fi=float(i);",
"    float nearness=fi*0.5;",
"    float dens=i==0?9.2:(i==1?5.9:4.0);",
"    float px=uv.x*dens;",
"    float cell=floor(px);",
"    float fx=fract(px);",
"    float r1=hash11(cell*7.7+fi*19.0+3.0);",
"    float r2=hash11(cell*2.3+fi*31.0+7.0);",
"    float r3=hash11(cell*13.7+fi*11.0+1.0);",
"    float r4=hash11(cell*31.1+fi*5.0+9.0);",
"    float present=step(i==0?0.16:0.26,hash11(cell*4.9+fi*23.0+2.0));",
"    float onT=hash21(vec2(cell*0.731+fi*2.117,3.0));",
"    float lightOn=smoothstep(onT*0.50,onT*0.50+0.24,uLit);",
"    float bw=i==0?(0.44+0.28*r3):(i==1?(0.36+0.22*r3):(0.40+0.22*r3));",
"    float bx=i==0?(0.07+0.11*r4):(i==1?(0.07+0.12*r4):(0.08+0.10*r4));",
"    float sideW=bw*(0.13+0.13*r2);",
"    float hgt=i==0?(0.014+pow(r1,1.7)*0.052):(i==1?(0.038+pow(r1,1.65)*0.090):(0.055+pow(r1,1.8)*0.108));",
"    hgt+=i>0&&r2>0.84?0.030+0.040*r3:0.0;",
"    float roof=uHorizon+hgt;",
"    float bL=(cell+bx)/dens, bR=(cell+bx+bw+sideW)/dens;",
"    float sunSkip=step(gapL,bR)*step(bL,gapR);",
"    float aa=1.2/max(uRes.y,1.0);",
"    float edgeL=smoothstep(bx-aa,bx+aa,fx);",
"    float edgeR=1.0-smoothstep(bx+bw-aa,bx+bw+aa,fx);",
"    float baseMask=edgeL*edgeR*step(uHorizon-0.002,uv.y)*(1.0-smoothstep(roof-aa,roof+aa,uv.y));",
"    float sideRoof=roof-(0.006+0.022*r2)*clamp((fx-(bx+bw))/max(sideW,0.001),0.0,1.0);",
"    float sideMask=smoothstep(bx+bw-aa,bx+bw+aa,fx)*(1.0-smoothstep(bx+bw+sideW-aa,bx+bw+sideW+aa,fx))*step(uHorizon-0.002,uv.y)*(1.0-smoothstep(sideRoof-aa,sideRoof+aa,uv.y));",
"    float capW=bw*(0.40+0.25*r2);",
"    float capX=bx+(bw-capW)*(0.25+0.50*r3);",
"    float capTop=roof+(0.006+0.024*r1)*step(0.58,r2);",
"    float capMask=smoothstep(capX-aa,capX+aa,fx)*(1.0-smoothstep(capX+capW-aa,capX+capW+aa,fx))*step(roof-aa,uv.y)*(1.0-smoothstep(capTop-aa,capTop+aa,uv.y));",
"    float ventW=bw*(0.10+0.11*r3);",
"    float ventX=bx+bw*(0.12+0.64*r1);",
"    float ventTop=capTop+(0.004+0.016*r3)*step(0.42,r2);",
"    float ventMask=smoothstep(ventX-aa,ventX+aa,fx)*(1.0-smoothstep(ventX+ventW-aa,ventX+ventW+aa,fx))*step(capTop-aa,uv.y)*(1.0-smoothstep(ventTop-aa,ventTop+aa,uv.y));",
"    float bodyMask=max(max(max(baseMask,capMask),ventMask),sideMask)*present*(1.0-sunSkip);",
"    if(bodyMask>0.01){",
"      float onSide=step(bx+bw,fx);",
"      float frontU=clamp((fx-bx)/max(bw,0.001),0.0,1.0);",
"      float sideU=clamp((fx-(bx+bw))/max(sideW,0.001),0.0,1.0);",
"      float u=mix(frontU,sideU,onSide);",
"      float side=smoothstep(0.70,0.97,u);",
"      vec3 base=mix(vec3(0.0660,0.0730,0.2300),vec3(0.0790,0.0730,0.2460),nearness);",
"      base+=mix(vec3(0.0790,0.0590,0.2300),vec3(0.0660,0.1060,0.2850),1.0-nearness)*0.60;",
"      base=mix(base,base*vec3(1.22,1.02,1.15),side*0.62);",
"      vec3 sideBase=mix(vec3(0.0790,0.0590,0.2400),vec3(0.0700,0.0660,0.2400),nearness);",
"      sideBase*=0.48+0.52*sideU;",
"      sideBase=mix(sideBase,sideBase*vec3(1.24,0.94,1.14),0.52);",
"      base=mix(base,sideBase,onSide);",
"      float rib=0.56+0.44*step(0.36,fract(u*(5.0+nearness*5.0)+0.18));",
"      float floorBand=0.76+0.24*step(0.34,fract((roof-uv.y)/0.0085));",
"      float sideFloor=0.88+0.12*step(0.28,fract((sideRoof-uv.y)/0.0090));",
"      float topShadow=0.50+0.50*smoothstep(0.0,0.065,roof-uv.y);",
"      float cornerRib=1.0-smoothstep(0.0,0.0021,abs(u-(onSide>0.5?0.04:0.96)));",
"      base*=rib*floorBand*topShadow*mix(1.0,sideFloor,onSide);",
"      vec3 localEm=vec3(0.0);",
"      float baseCanopy=1.0-smoothstep(0.0,0.0024,abs(uv.y-(uHorizon+0.010+0.008*r1)));",
"      localEm+=mix(vec3(1.06,1.11,1.26),vec3(0.30,0.70,1.00),coldAt(uv.x))*(0.70+0.30*step(0.86,r3))*baseCanopy*(0.10+0.12*nearness);",
/* Windows are a near/mid detail. Keeping the far band blank makes haze read as distance. */
"      if(i>0){",
"        vec2 wc=floor(vec2(u*9.0,(roof-uv.y)/0.0072));",
"        vec2 wf=fract(vec2(u*9.0,(roof-uv.y)/0.0072));",
"        float glass=step(0.27,wf.x)*step(wf.x,0.73)*step(0.27,wf.y)*step(wf.y,0.69);",
/* A room is on or off, and it changes without warning : each window keeps
   its own clock, is thrown on or thrown off on its own count, and settles
   at its own brightness. Nothing here breathes in step with anything else. */
"        float wh=hash21(wc+cell*37.0+fi*13.0);",
"        float lit=smoothstep(0.78,0.90,wh);",
"        float wk=hash11(wc.x*1.7+wc.y*2.3+cell*0.37+fi*9.0);",
"        float tick=floor(t*(0.12+0.22*wk)+wk*31.0);",
"        float fk=hash21(vec2(wk*13.7,tick*2.9+wk*7.0));",
"        float switchOn=step(0.30,fk);",
"        float lvl=0.46+0.54*hash21(vec2(tick*3.1+wk*5.0,wk*2.3));",
"        float pulse=switchOn*(0.40+0.60*lvl)*(0.92+0.08*sin(t*1.6+wk*6.28));",
"        float wrk=hash21(vec2(cell+0.5,fi*3.0+0.5));",
"        float warmZ=warmAt(uv.x);",
"        float coldMix=coldAt(uv.x);",
"",
"        vec3 wcCol=mix(vec3(1.06,1.11,1.26),vec3(0.50,0.78,1.00),coldMix);",
"        wcCol=mix(wcCol,vec3(1.06,1.11,1.26),step(0.80,wrk)*0.75);",
"        wcCol=mix(wcCol,vec3(1.000,0.438,0.726),step(0.92,wrk)*0.75*(1.0-smoothstep(0.08,0.55,warmZ)));",
"        localEm+=wcCol*glass*lit*pulse*(0.19+0.16*nearness)*(1.0-side*0.48);",
"      }else{",
/* the far band keeps only a few single windows, but they are rooms too :
   one of them somewhere turns over while you watch */
"        vec2 fwq=floor(vec2(u*7.0,(roof-uv.y)/0.0075));",
"        float farGrid=step(0.48,fract(u*7.0))*step(fract((roof-uv.y)/0.0075),0.24);",
"        float farWk=hash11(fwq.y*3.1+fwq.x*1.7+cell);",
"        float farTick=floor(t*(0.10+0.24*farWk)+farWk*17.0);",
"        float farOn=step(0.42,hash21(fwq+cell*17.0+farTick*3.7));",
"        localEm+=vec3(0.20,0.46,0.76)*farGrid*farOn*(0.026+0.030*farWk);",
"      }",
/* Sparse signage and structural neon create scale without turning every tower into a light wall. */
"      float strip=1.0-smoothstep(0.0,0.0012,abs(u-0.88));",
"      float stripOn=step(0.76,hash11(cell*3.7+fi*8.0));",
"      localEm+=mix(vec3(0.18,0.62,1.00),vec3(0.48,0.86,1.00),step(0.76,r3))*strip*stripOn*(0.26+0.20*nearness);",
"      float strip2=1.0-smoothstep(0.0,0.0010,abs(u-(0.08+0.14*r2)));",
"      localEm+=vec3(0.18,0.62,1.00)*strip2*step(0.90,r1)*nearness*0.34;",
"      float facadeRib=1.0-smoothstep(0.0,0.0009,abs(fract(u*(8.0+nearness*5.0)+0.18)-0.5));",
"      localEm+=mix(vec3(1.06,1.11,1.26),vec3(0.30,0.70,1.00),coldAt(uv.x))*(0.55+0.45*r2)*facadeRib*(1.0-onSide)*(0.003+0.008*nearness);",
"      float frontEdge=(1.0-smoothstep(0.0,0.0013,abs(fx-bx)))*(1.0-onSide);",
"      localEm+=vec3(1.06,1.11,1.26)*frontEdge*(0.06+0.12*nearness);",
"      localEm+=vec3(1.06,1.11,1.26)*cornerRib*(1.0-onSide)*(0.05+0.16*nearness);",
"      float backEdge=1.0-smoothstep(0.0,0.0012,abs(fx-(bx+bw+sideW)));",
"      localEm+=vec3(1.06,1.11,1.26)*backEdge*onSide*(0.08+0.11*nearness);",
"      float roofEdge=(1.0-smoothstep(0.0,0.0015,abs(uv.y-capTop)))*step(bx,fx)*step(fx,bx+bw);",
"      localEm+=mix(vec3(1.06,1.11,1.26),vec3(0.30,0.70,1.00),coldAt(uv.x))*(0.65+0.35*r4)*roofEdge*(0.10+0.13*nearness);",
"      float signOn=step(0.62,r4)*nearness*(1.0-onSide);",
"      float signHalfW=0.22+0.08*r2;",
"      float signY=abs(uv.y-(uHorizon+hgt*(0.28+0.30*r1)));",
"      float signX=abs(u-(0.26+0.18*r3));",
"      float sign=step(signX,signHalfW)*step(signY,0.011)*signOn;",
"      float signBar=step(abs(signY),0.0014)*step(signX,signHalfW*0.92)*signOn;",
"      localEm+=vec3(0.18,0.62,1.00)*sign*(0.13+0.10*(0.5+0.5*sin(t*1.7+cell)));",
"      localEm+=mix(vec3(0.18,0.62,1.00),vec3(0.48,0.86,1.00),r1)*signBar*0.38;",
"      vec3 shaded=base+localEm*lightOn;",
"      float baseSoft=0.56+0.44*smoothstep(0.0,0.027,uv.y-uHorizon);",
"      float bodyAlpha=bodyMask*baseSoft;",
"      col=mix(col,shaded,bodyAlpha);",
"      has=max(has,bodyAlpha);",
"    }",
"    /* --- roof structures : the vertical reach of the skyline, and the one",
"       place where the city is allowed to look unfinished --- */",
"    float bcx=(cell+bx+bw*0.5)/dens;",
"    float rS=hash21(vec2(cell*0.731+fi*2.117,3.0));",
"    float rTop=capTop;",
"    float mastH=0.014+0.030*r2;",
"    float hasMast=step(0.52,r2);",
"    float mast=hasMast*(1.0-smoothstep(0.00050,0.00120,abs(uv.x-bcx)))",
"              *step(rTop-0.001,uv.y)*step(uv.y,rTop+mastH);",
"    airLights+=mix(vec3(0.38,0.26,0.27),vec3(0.20,0.42,0.62),1.0-fi*0.5)*mast*(0.45+0.25*nearness)*lightOn;",
"    vec2 bo=vec2(bcx,rTop+mastH);",
"    float bdist=length((uv-bo)*vec2(1.0,0.34));",
"    float beacon=1.0-smoothstep(0.0,0.0018,bdist);",
"    float bhalo=exp(-bdist*40.0);",
"    vec3 bcn=mix(vec3(1.000,0.298,0.658),vec3(0.26,0.72,1.00),1.0-fi*0.5);",
/* an obstruction light is a real blink : a short hard flash, then dark.
   A soft sine never reads as a signal, only as a glow. */
"    float bph=fract(t*(0.13+0.05*hash11(cell*1.7))+hash11(cell*2.9+1.0));",
"    float blinkOn=smoothstep(0.0,0.035,bph)*(1.0-smoothstep(0.17,0.30,bph));",
"    airLights+=bcn*(beacon*1.20+bhalo*0.28)*hasMast*lightOn*(0.05+0.95*blinkOn);",
/* and two more climbing the same mast, each on its own count */
"    for(int k=1;k<3;k++){",
"      float fk2=float(k);",
"      float oy=rTop+mastH*(1.0-fk2*0.30);",
"      float kd=length((uv-vec2(bcx,oy))*vec2(1.0,0.80));",
"      float kdot=1.0-smoothstep(0.0,0.00090,kd);",
"      float kph=fract(t*(0.11+0.07*fk2)+hash11(cell*3.3+fk2));",
"      float kOn=smoothstep(0.0,0.04,kph)*(1.0-smoothstep(0.12,0.23,kph));",
"      airLights+=vec3(1.000,0.282,0.650)*(kdot+exp(-kd*70.0)*0.22)",
"          *hasMast*lightOn*(0.06+0.94*kOn)*0.60;",
"    }",
/* --- a slow lamp turning on a few roofs. The beam is faint, but it is the
       only thing on this skyline that has a direction of its own. --- */
"    vec2 so=vec2(bcx,rTop+0.0055);",
"    vec2 spo=uv-so;",
"    float srad=length(spo*vec2(1.0,0.80));",
"    float sang=atan(spo.y,spo.x);",
"    float sph=t*0.21+hash11(cell*3.9+2.0)*6.2831;",
"    float lobe=max(exp(-((sin((sang-sph)*0.5)/0.052)*(sin((sang-sph)*0.5)/0.052))),",
"                  exp(-((sin((sang-sph-3.1416)*0.5)/0.080)*(sin((sang-sph-3.1416)*0.5)/0.080)))*0.50);",
"    float sfall=exp(-srad*18.0)*smoothstep(0.0,0.005,srad);",
"    vec3 swTint=mix(vec3(0.30,0.66,1.00),vec3(1.00,0.46,0.74),hash11(cell*5.7+4.0));",
"    airLights+=swTint*lobe*sfall*step(0.72,rS)*lightOn*step(rTop-0.002,uv.y)*0.080;",
"    airLights+=swTint*exp(-srad*120.0)*step(0.72,rS)*lightOn*step(rTop-0.002,uv.y)*0.16;",
"    /* a water tank on a short stem */",
"    float tankOn=step(0.86,rS)*step(0.5,fi);",
"    float tankW=0.0022+0.0015*r1;",
"    float tankH=0.0040+0.0026*r3;",
"    float tankStem=(1.0-smoothstep(0.00035,0.00085,abs(uv.x-bcx)))*step(rTop,uv.y)*step(uv.y,rTop+0.0026);",
"    float tTank=step(abs(uv.x-bcx),tankW)*step(rTop+0.0026,uv.y)*step(uv.y,rTop+0.0026+tankH);",
"    float tankM=max(tankStem,tTank)*tankOn*present*(1.0-sunSkip);",
"    col=mix(col,vec3(0.0125,0.0120,0.0165),tankM*lightOn);",
"    has=max(has,tankM);",
"    /* a tower crane still standing over the block */",
"    float craneOn=step(0.90,rS)*step(1.5,fi);",
"    float crH=0.030+0.020*r1;",
"    float jibY=rTop+crH*0.84;",
"    float jibL=0.014+0.012*r2;",
"    float jib=step(abs(uv.y-jibY),0.00065)*step(abs(uv.x-bcx),jibL);",
"    float cjib=step(abs(uv.y-jibY+0.0018),0.00055)*step(abs(uv.x-(bcx-jibL*0.32)),jibL*0.30);",
"    float cmast=step(abs(uv.x-bcx),0.0013)*step(rTop,uv.y)*step(uv.y,jibY);",
"    float craneM=max(max(jib,cjib),cmast)*craneOn*present*(1.0-sunSkip);",
"    col=mix(col,vec3(0.0140,0.0175,0.0290),craneM*lightOn);",
"    has=max(has,craneM);",
"    /* the crane's warning light and the hook lamp below the jib */",
"    float crTip=1.0-smoothstep(0.0,0.0018,length((uv-vec2(bcx,rTop+crH))*vec2(1.0,0.42)));",
"    float crHalo=exp(-length((uv-vec2(bcx,rTop+crH))*vec2(1.0,0.42))*46.0);",
"    float crPh=fract(t*0.17+hash11(cell*6.1)*1.0);",
"    float crOn=smoothstep(0.0,0.04,crPh)*(1.0-smoothstep(0.15,0.27,crPh));",
"    airLights+=vec3(1.000,0.298,0.658)*(crTip*1.1+crHalo*0.26)*craneOn*lightOn*(0.05+0.95*crOn);",
"    float hook=1.0-smoothstep(0.0,0.0013,length((uv-vec2(bcx+jibL*0.55,jibY-0.0048))*vec2(1.0,0.55)));",
"    airLights+=vec3(1.00,1.00,1.00)*hook*craneOn*lightOn*0.26;",
"  }",
"  return vec4(col+airLights,max(has,0.0));",
"}",
/* Sparse elevated transit decks add a second architectural direction without
   filling the skyline with more towers. */
"vec4 cityBridge(vec2 uv,float t){",
"  float mask=0.0;",
"  vec3 em=vec3(0.0);",
"  for(int i=0;i<2;i++){",
"    float fi=float(i);",
"    float lampOn=smoothstep(0.12+fi*0.44,0.12+fi*0.44+0.22,uLit);",
"    float start=i==0?0.19:0.76;",
"    float finish=i==0?0.46:0.965;",
"    float y=uHorizon+0.082+fi*0.042+sin(uv.x*12.0+fi*3.0)*0.0013;",
"    float span=smoothstep(start,start+0.012,uv.x)*(1.0-smoothstep(finish-0.012,finish,uv.x));",
"    float deck=1.0-smoothstep(0.0,0.0022,abs(uv.y-y));",
"    float underside=1.0-smoothstep(0.0,0.0042,abs(uv.y-y+0.0048));",
"    float pylonPhase=abs(fract((uv.x-start)*8.0)-0.5);",
"    float pylon=(1.0-smoothstep(0.012,0.040,pylonPhase))*step(y-0.042,uv.y)*step(uv.y,y)*span;",
"    mask=max(mask,span*(deck+underside*0.32)+pylon*0.76);",
"    float lampPhase=fract((uv.x-start)*21.0);",
"    float lamps=(1.0-smoothstep(0.06,0.19,abs(lampPhase-0.5)))*exp(-abs(uv.y-y)/0.0023);",
"    em+=vec3(1.06,1.11,1.26)*lamps*span*0.085*lampOn;",
"    float rail=(1.0-smoothstep(0.0,0.0011,abs(uv.y-y-0.0017)))*span;",
"    em+=vec3(1.10,1.14,1.28)*rail*0.095*lampOn;",
"    em+=vec3(0.13,0.24,0.38)*pylon*0.034*lampOn;",
"    float trainX=mix(start,finish,fract(t*0.014+fi*0.53+0.11));",
"    float train=exp(-(((uv.x-trainX)/0.024)*((uv.x-trainX)/0.024)))*exp(-abs(uv.y-y+0.002)/0.0018)*span;",
"    em+=vec3(1.06,1.11,1.26)*train*0.115*lampOn;",
"    /* the lamp string spills a thin warm haze along the deck */",
"    em+=vec3(1.04,1.09,1.24)*exp(-abs(uv.y-y-0.0022)/0.0090)*span*0.0070*lampOn;",
"  }",
"  return vec4(vec3(0.0008,0.0011,0.0024)+em,mask);",
"}",
/* ---- sand : albedo only, lit later ---- */
"vec3 sandAt(vec2 uv,float wet){",
"  float d=uShore-uv.y;",
"  float depth=clamp(d/0.48,0.0,1.0);",
"  vec3 dry=mix(vec3(0.150,0.330,0.560),vec3(0.080,0.175,0.330),smoothstep(0.0,0.50,d));",
"  vec3 wetc=mix(vec3(0.080,0.175,0.290),vec3(0.030,0.065,0.115),smoothstep(0.0,0.50,d));",
"  vec3 c=mix(dry,wetc,wet);",
"  vec2 sg=uv*vec2(uRes.x/uRes.y,1.0)*(34.0+depth*92.0);",
"  float n=fbm3(sg);",
"  float dune=fbm3(sg*0.19+vec2(7.3,2.1));",
"  c+=(n-0.5)*(0.032+depth*0.030);",
"  c*=0.78+0.32*dune;",
"  c+=(hash21(floor(uv*uRes*0.82))-0.5)*0.014;",
/* wind ripples : the same wave rhythm, in perspective */
"  /* the divisor is allowed to change sign as the field runs out past the",
"     shore, but it must never reach zero : at d = -0.088 it went to infinity,",
"     the ripple frequency built on it went with it, and the sea grew a band",
"     of aliased static in the middle of the water.  The sign is kept, because",
"     the ripple has to keep turning the same way, and the magnitude is capped",
"     so the frequency stays under the sampling rate. */",
"  float pden=0.30+d*3.4;",
"  float persp=sign(pden)/max(abs(pden),0.04);",
"  /* the ripple field must not read as a grating : a slow lateral bend",
"     and a drifting spacing keep the crests from running dead straight */",
"  float bend=(fbm2(vec2(uv.x*2.05+4.7,1.3))-0.5)*9.0;",
"  float bend2=(fbm2(vec2(uv.x*6.30+2.3,1.3))-0.5)*2.6;",
"  float bendT=bend+bend2;",
"  float spacing=1.0+0.20*sin(uv.x*1.62+0.6)+0.10*sin(uv.x*0.47+2.2);",
"  float pr=persp*spacing;",
"  float rip=sin(uv.y*pr*120.0+waveShape(uv.x*2.0,uv.y*40.0)*2.2+fbm2(uv*vec2(4.0,8.0))*9.0+bendT*0.55);",
"  float rip2=sin(uv.y*pr*61.0-uv.x*17.0+fbm2(uv*vec2(9.0,5.0))*7.0+bendT*0.40);",
"  float slantPh=(uv.x*2.7+uv.y*7.8)*pr*86.0+fbm2(uv*vec2(6.0,11.0))*5.0+bendT;",
"  /* a second set of ripples running a different way : the field stops",
"     reading as one machine-made ruling */",
"  float dirW=0.20+0.80*smoothstep(0.28,0.76,fbm2(vec2(uv.x*1.35+5.1,uv.y*1.1+2.9)));",
"  float slantPh2=(uv.x*6.6+uv.y*4.4)*pr*57.0+fbm2(uv*vec2(3.2,6.4)+7.7)*6.0+bendT*0.80;",
"  float slant=sin(slantPh)*(1.0-dirW)+sin(slantPh2)*dirW;",
"  float slantC=cos(slantPh)*(1.0-dirW)+cos(slantPh2)*dirW;",
"/* every ripple has two flanks : the far one turns into the low sun and",
"   is lit, the near one drops into its own shadow */",
"  float slopeLit=pow(max(0.0,slantC),1.6);",
"  float slopeDark=pow(max(0.0,-slantC),1.6);",
"  float sunReach=exp(-(((uv.x-uSun.x)/0.34)*((uv.x-uSun.x)/0.34)));",
"  vec3 ripLit=mix(vec3(0.34,0.52,0.92),vec3(0.95,0.72,0.95),sunReach);",
"  float ridge=pow(0.5+0.5*slant,9.0);",
"  float trough=pow(0.5-0.5*slant,6.0);",
"  vec2 sq=uv*vec2(uRes.x/uRes.y,1.0);",
"  vec2 sgr=vec2(sq.x*0.883+sq.y*0.469,-sq.x*0.469+sq.y*0.883);",
"  float sandFine=fbm2(vec2(sgr.x*(680.0+depth*520.0),sgr.y*330.0)+vec2(2.4,uTime*0.012));",
"  c*=1.0-(0.17*slopeDark+0.23*trough)*depth;",
"  c+=ripLit*ridge*0.058*(1.0-wet*0.62);",
"  c+=ripLit*slopeLit*0.033*depth*(1.0-wet*0.55);",
"  c+=vec3(0.26,0.40,0.62)*slopeDark*0.026*depth*(1.0-wet*0.55);",
"  float grainPatch=0.28+0.72*smoothstep(0.28,0.74,fbm2(vec2(uv.x*6.5+9.3,uv.y*3.2+3.1)));",
"  c+=(sandFine-0.5)*0.013*(1.0-wet*0.55)*grainPatch;",
"  float bandPatch=0.10+0.90*smoothstep(0.24,0.70,fbm2(vec2(uv.x*4.2+3.3,uv.y*2.4+1.7)));",
"  float bandN=23.0+1.6*sin(uv.x*1.15+0.7);",
"  float tideBand=fract(pow(depth,1.7)*bandN+fbm2(vec2(uv.x*2.4+0.7,uv.y*8.0))*1.6);",
"  c*=1.0-0.115*smoothstep(0.62,0.97,tideBand)*(1.0-wet*0.70)*bandPatch;",
"  c+=vec3(0.800,0.628,0.716)*smoothstep(0.58,0.99,rip)*0.040*(1.0-wet*0.62);",
"  c*=1.0-0.055*(1.0-smoothstep(-0.65,0.35,rip))*depth;",
"  c+=vec3(1.06,1.11,1.26)*smoothstep(0.82,1.0,rip2)*0.052*wet;",
"  c+=vec3(1.000,0.392,0.704)*smoothstep(0.92,1.0,rip)*0.065*wet;",
/* mica : a few grains catching the light */
"  float spk=step(0.9984,hash21(floor(uv*uRes*0.9)));",
"  c+=vec3(1.000,0.548,0.780)*spk*(0.22+0.18*(1.0-wet));",
"  float cspk=step(0.9972,hash21(floor(uv*uRes*0.9)+7.0));",
"  c+=vec3(0.40,0.66,1.00)*cspk*(0.10+0.17*depth);",
"  vec2 pc=floor(uv*uRes*0.07);",
"  float pOn=step(0.9958,hash21(pc+53.0));",
"  float pd=length((fract(uv*uRes*0.07)-0.5)*vec2(1.0,1.28));",
"  float peb=(1.0-smoothstep(0.09,0.19,pd))*pOn*(1.0-wet*0.55);",
/* a stone in wet sand is a shadow : it must never read as a white chip */
"  c*=1.0-0.34*peb;",
"  c+=vec3(0.16,0.19,0.26)*peb*(1.0-smoothstep(0.06,0.15,pd))*0.15;",
"  float shell=step(0.9975,hash21(floor(sg*1.6)+19.0));",
"  c+=mix(vec3(0.13,0.08,0.05),vec3(0.19,0.18,0.18),step(0.5,hash21(floor(sg*1.6))))*shell*0.19;",
"  return c; }",

/* ---- the hand written groove in the sand ---- */
"vec3 writeInk(vec3 sand,vec2 uv,vec2 L,out float bloom){",
"  float g=inkE(uv);",
"/* the sun decides every shadow in the sand : the light direction is read",
"   from where the sun actually is, so it tilts across the frame */",
"  vec2 toSun=uSun-uv;",
"  vec2 Ls=normalize(vec2(toSun.x,toSun.y*0.34+0.02))*0.00216;",
"/* the lip of sand the mark threw up catches the sun on the far side */",
"  float lipFar=max(inkE(uv-Ls*1.30)-g,0.0);",
"/* the shadow the groove throws on the sand beside it, away from the sun */",
"  float castA=inkE(uv+Ls*2.0);",
"  float castB=inkE(uv+Ls*4.2);",
"  float castSoft=smoothstep(0.05,0.52,clamp(castA*0.55+castB*0.45,0.0,1.0));",
"  if(g<0.001){",
"    bloom=0.0;",
"    sand*=1.0-0.16*castSoft;",
"    sand*=1.0+1.45*lipFar;",
"    sand+=vec3(1.0,0.56,0.74)*lipFar*0.016;",
"    return sand; }",
"/* the groove has three bands : the wall that faces the sun, the wall",
"   that only sees the cold sky, and the floor of the groove */",
"  float s1=inkE(uv+Ls*0.0026);",
"  float s2=inkE(uv+Ls*0.0056);",
"  float a1=inkE(uv-Ls*0.0026);",
"  float a2=inkE(uv-Ls*0.0056);",
"  float toward=(0.0026*s1+0.0056*s2)-(0.0026*a1+0.0056*a2);",
"  float litWall=g*smoothstep(0.0006,0.0032,toward);",
"  float coldWall=g*smoothstep(0.0006,0.0032,-toward);",
"  float deep=g*(1.0-smoothstep(0.0006,0.0032,abs(toward)));",
"  float litRidge=inkE(uv+Ls*1.25);",
"  float backRidge=inkE(uv-Ls*1.55);",
"  float sideRidge=inkE(uv+vec2(Ls.y*1.05,-Ls.x*0.62));",
"  float skirt=(inkE(uv+Ls*4.2)+inkE(uv-Ls*4.2)+inkE(uv+vec2(Ls.x*5.2,0.0))+inkE(uv-vec2(Ls.x*5.2,0.0)))*0.25;",
"  float grain=fbm2(uv*vec2(360.0,245.0)+vec2(0.0,uTime*0.020));",
"  float fiber=fbm2(uv*vec2(760.0,520.0)+vec2(3.7,uTime*0.045));",
"  float fleck=fbm2(uv*vec2(1180.0,820.0)+vec2(9.1,-uTime*0.032));",
"  float grooveVar=fbm2(uv*vec2(470.0,315.0)+vec2(7.0,uTime*0.028));",
"  float pressure=0.76+0.24*fbm2(uv*vec2(125.0,92.0)+vec2(1.4,-uTime*0.018));",
"  float ink=smoothstep(0.030,0.60,g*(0.91+0.09*grooveVar));",
"  float broken=ink*(0.93+0.07*smoothstep(0.12,0.86,fiber));",
"  float ridge=max(litRidge-g,0.0)*smoothstep(0.30,0.92,1.0-fiber);",
"  float cavity=max(g-(litRidge+backRidge)*0.5,0.0);",
"  float lipCool=max(sideRidge-g,0.0)*(0.40+0.60*fiber);",
"  float reliefEdge=clamp((g-max(litRidge,backRidge))*4.2,0.0,1.0);",
"  bloom=skirt*(0.085+0.24*uCharge);",
/* The groove is a scratch in a beach, not a crater. It keeps its walls and
   its lit lip, but every weight on it is far lower : the pit reading came
   from the floor, the cavity and the shadow band all darkening at once. */
"  sand*=1.0-(0.22+0.07*grooveVar)*broken*pressure;",
"  sand*=1.0-0.032*broken*smoothstep(0.54,0.86,fiber);",
"  sand*=1.0-0.045*broken*smoothstep(0.67,0.88,fleck);",
"  sand*=1.0-0.11*deep*pressure;",
"  sand*=1.0-0.12*castSoft;",
"  sand*=1.0-0.07*cavity*pressure;",
"  sand+=vec3(1.0,0.64,0.80)*litWall*0.52*pressure;",
"  sand+=vec3(0.26,0.38,0.72)*coldWall*0.100*pressure;",
"  sand+=vec3(1.0,0.88,0.95)*ridge*0.16*pressure;",
"  sand+=vec3(1.0,0.55,0.50)*lipCool*0.115*pressure;",
"  sand+=vec3(1.0,0.88,0.95)*reliefEdge*(0.10+0.10*fiber)*pressure;",
"  sand+=vec3(0.028,0.044,0.066)*broken*(0.55+0.45*fiber)*pressure;",
"  sand+=vec3(1.0,0.58,0.48)*cavity*0.098*(1.0-g);",
"  sand+=vec3(1.0,0.86,0.94)*broken*smoothstep(0.76,0.94,fleck)*0.024*pressure;",
"  sand+=vec3(1.0,0.30,0.56)*bloom*(0.040+0.185*uCharge);",
"  return sand; }",

/* ==================================================================
   THE NEON IN THE SAND
   The mark is no longer read as a groove : it is a tube of light lying in
   one.  Three scales, because one is never enough to read at night - the
   white-hot core, the gas glowing around it, and the pool of light the
   tube throws on the sand beside the stroke.
   ================================================================== */
"vec3 neonInk(vec2 uv,float wet){",
/* nothing within reach of the tube : one test instead of thirteen */
"  vec2 bx=boxUv(uv);",
"  if(bx.x<-0.055||bx.x>1.055||bx.y<-0.090||bx.y>1.090) return vec3(0.0);",
/* the tube takes the side of the beach it lies on : the pink of the sun,
   or the cold blue the city throws down the sand */
"  vec3 hue=mix(vec3(1.000,0.404,0.706),vec3(0.320,0.760,1.000),coldAt(uv.x));",
/* a neon core is never its own colour : the gas is so saturated that the
   middle of the tube burns white and only the collar carries the hue */
"  vec3 coreC=mix(hue,vec3(1.000,0.965,0.980),0.58);",
"  float g=inkE(uv);",
/* the pool of light the tube throws on the sand : it is the writing, spread
   out.  A ring of samples around the pixel can only say how much ink sits in
   the ring, and a straight stroke makes that answer jump at fixed distances
   from the stroke : the pool came out as a set of parallel lines lying beside
   the word, as if the word had been written twice.  A blur has no such
   structure in it - it is the writing itself, let go. */
"  float gb=inkBlurAt(uv);",
"/* The pool of light is a cast of the tube.  The sea that took the tube away",
"   takes the light it threw on the sand with it : otherwise the word goes and",
"   its glow stays, and the sand keeps saying the word in a voice that is no",
"   longer there.  The mark and everything it casts leave together. */",
"  gb*=1.0-eroAt(uv);",
"  if(g<0.0004&&gb<=0.0) return vec3(0.0);",
/* salt air on a beach : the tube breathes on two beats that never line up,
   so the light never pulses the way a sign does */
"  float hum=0.90+0.10*sin(uTime*1.7+uv.x*4.1)*sin(uTime*0.63+uv.y*2.7);",
"  float surge=1.0+0.42*uCharge;",
/* sand is not glass : the grain eats a little of the light unevenly */
"  float grit=0.88+0.12*fbm2(uv*vec2(320.0,220.0)+vec2(0.0,uTime*0.030));",
"  vec3 c=vec3(0.0);",
/* --- the gas collar hugging the tube --- */
"  c+=hue*smoothstep(0.16,0.62,g)*(0.55+0.70*uCharge)*hum*surge*grit;",
/* --- the tube : white, hard edged, the brightest thing in the frame --- */
"  c+=coreC*smoothstep(0.86,0.995,g)*(2.70+2.50*uCharge)*hum*surge*grit;",
/* --- the pool it throws on the sand : the two shoulders of one falloff --- */
"  c+=hue*smoothstep(0.030,0.42,gb)*(0.130+0.180*uCharge)*(0.72+0.60*wet);",
/* wet sand is a poor mirror, but it stretches the tube down the slope */
"  float smear=inkE(uv-vec2(0.0,0.0094))*wet;",
"  c+=coreC*smoothstep(0.02,0.55,smear)*(0.30+0.70*uCharge)*0.20;",
"  return c; }",

/* ---- lighting helpers ---- */
"vec3 sandLight(vec3 albedo,float lit,float wet){",
"  vec3 amb=vec3(0.600,0.620,0.930)*(0.86+wet*0.48);",
"  vec3 skyBounce=vec3(0.190,0.210,0.400)*(1.0-wet*0.40);",
"  vec3 dir=vec3(5.60,1.30,3.20)*lit;",
"  vec3 cool=vec3(0.40,0.50,0.92)*lit*0.28;",
"  return albedo*(amb+skyBounce+dir+cool); }",

/* ==================================================================
   SMALL LIFE ON THE SAND : crabs, with soft shadows and motion smear
   ================================================================== */



/* ==================================================================
   FRAME
   ================================================================== */
"void main(){",
"  vec2 uv=vUv;",
"  float px=uRes.x/uRes.y;",
  "  vec3 c;",
/* ---------- SKY ---------- */
  "  float above=clamp((uv.y-uHorizon)/0.45,0.0,1.0);",
  "  vec3 sky=mix(mix(vec3(0.0400,0.0350,0.1300),vec3(0.1050,0.0850,0.2800),uSunUp),vec3(0.0380,0.0660,0.2350),pow(above,0.60));",
  "  float az=exp(-(((uv.x-uSun.x)/0.21)*((uv.x-uSun.x)/0.21)));",
  "  sky+=vec3(2.45,0.50,5.95)*exp(-max(uv.y-uHorizon,0.0)*23.0)*az*uSunUp;",
  "  float sunH=max(uSun.y-uHorizon,0.001);",
  "  float asp=uRes.x/uRes.y;",
  "  float barX=exp(-pow((uv.x-uSun.x)*asp/(3.45*uSunR),4.0));",
  "  float barY=exp(-pow(max(uv.y-uHorizon,0.0)/(0.82*sunH),2.0));",
  "  sky+=vec3(2.45,0.50,5.95)*barX*barY*uSunUp;",
/* The sun's warmth does not stop at a band.  It spreads up into the sky as a
   broad pool, and that pool is what carries the pink across to the violet :
   a gradient is a path, not a step.  The broad term carries about as much
   chroma over its whole height as the tight band carries over its own, so
   the frame does not get brighter - it gets a way from one colour to the
   other. */
  "  float azTight=exp(-(((uv.x-uSun.x)/0.115)*((uv.x-uSun.x)/0.115)));",
  "  sky+=vec3(0.330,0.520,0.700)*exp(-max(uv.y-uHorizon,0.0)*13.0)*(1.0-az*0.55);",
  "  sky+=vec3(0.095,0.075,0.200)*exp(-max(uv.y-uHorizon,0.0)*6.5)*azTight*uSunUp;",
"  float fogB=exp(-(((uv.y-uHorizon)/0.040)*((uv.y-uHorizon)/0.040)));",
"  sky+=mix(vec3(0.240,0.200,0.450),vec3(2.40,0.70,2.85),az*uSunUp)*fogB*0.45;",
"  float cloud=fbm3(vec2(uv.x*5.2+uTime*0.004,uv.y*22.0-uTime*0.003));",
"  float cloudBand=smoothstep(0.50,0.72,cloud)",
"                 *smoothstep(uHorizon+0.035,uHorizon+0.12,uv.y)",
"                 *(1.0-smoothstep(uHorizon+0.31,uHorizon+0.44,uv.y));",
"  sky+=mix(vec3(0.095,0.075,0.200),vec3(0.280,0.180,0.380),az*uSunUp)*cloudBand*0.20;",
"  vec3 skyPure=sky;",
"  sky*=skyStrata(uv,uTime);",
/* the stars sit behind the city : they are read through the gaps in it */
"  sky+=vec3(0.68,0.82,1.0)*starField(uv,uTime)*0.90*mix(1.85,1.00,uDawn)",
"       *smoothstep(uHorizon+0.015,uHorizon+0.42,uv.y);",
"  /* the cold landmark breathes a soft halo into the night air */",
"  vec2 lmP=vec2(0.076,0.912);",
"  float lmD=length((uv-lmP)*vec2(1.0,0.85));",
"  sky+=vec3(0.16,0.44,1.00)*exp(-lmD*12.0)*0.070;",
"  vec4 cc=cityLayer(uv,uTime);",
"  vec4 bridge=cityBridge(uv,uTime);",
"  float cityCover=max(cc.a,bridge.a);",
"  float airDepth=step(uHorizon,uv.y)*mix(1.0,0.54,smoothstep(0.04,0.62,cityCover));",
"  sky=sky*(1.0-cc.a)+cc.rgb;",
"  sky=sky*(1.0-bridge.a)+bridge.rgb;",
"  sky+=landmarkSweep(uv,uTime);",
"  float trafficBody=airTrafficBody(uv,uTime);",
"  sky=mix(sky,vec3(0.015,0.009,0.017),trafficBody);",
"  sky+=airTraffic(uv,uTime);",
/* the sun stands in front of the city : it is the nearest thing in the sky */
"  vec4 sn=sunBody(uv,uTime);",
"  airDepth*=1.0-0.22*sn.a;",
"  vec3 discC=min(sn.rgb/max(sn.a,0.08),vec3(12.0));",
"  sky=mix(sky,discC,sn.a);",
"  sky+=sn.rgb-discC*sn.a;",
/* the light of the sun bleeds through the haze in front of the city */
"  sky+=sunGlow(uv,uTime)*uSunUp;",
"  float flareX=abs(uv.x-uSun.x);",
"  float flare=exp(-(((uv.y-uSun.y-0.0015)/0.0018)*((uv.y-uSun.y-0.0015)/0.0018)))*exp(-flareX*4.2);",
"  sky+=mix(vec3(1.06,1.11,1.26),vec3(1.000,0.407,0.711),exp(-flareX*9.0))*flare*0.020*uSunUp;",

"  c=sky;",
/* ---------- THE WAVE FIELD ---------- */
"  float wbase=mix(uShore,uMax,uTide);",
"  float wy=waveY(uv.x,wbase,uWave*0.035,uTime);",
"  float shoreAA=max(sceneAA(uv.y-wy)*0.55,0.55/uRes.y);",
"  float beachM=1.0-smoothstep(-shoreAA,shoreAA,uv.y-wy);",
"  float hw=mix(uShore,uMax,1.0);",
/* the wedge of low sun on the ground : the world is in shadow away from it */
"  float groundT=max(uHorizon-uv.y,0.0);",
"  float litW=0.014+groundT*0.235;",
"  float lit=exp(-(((uv.x-uSun.x)/litW)*((uv.x-uSun.x)/litW)))*uSunUp;",
/* ---------- BEACH ---------- */
"  if(beachM>0.002){",
"    float wet=clamp(uWet,0.0,1.0)*(1.0-smoothstep(hw-0.12,hw+0.03,uv.y));",
"    wet=max(wet,clamp(uWet,0.0,1.0)*(1.0-smoothstep(0.0,0.13,uv.y-wy))*0.75);",
"    vec3 sand=sandLight(sandAt(uv,wet),lit,wet);",
"    /* the cold city and the cold landmark throw a little light back",
"       onto the sand : the left beach is lit by the city, not the sun */",
"    sand*=1.0+vec3(0.62,0.80,1.18)*coldAt(uv.x)*0.42;",
"    float shoreSheen=exp(-max(wy-uv.y,0.0)*13.0);",
"    sand+=vec3(0.085,0.150,0.290)*shoreSheen*0.15;",
"    float bl;",
"    sand=writeInk(sand,uv,vec2(0.0018,0.0012),bl);",
/* the tube laid in the groove : this, and not the groove, is what is read */
"    sand+=neonInk(uv,wet);",
/* the rain hitting the sand : small dark splashes and a damp ring */
/* the wet sand mirrors the city : broken neon lying on the shore */
"    float wr=exp(-max(wy-uv.y,0.0)*18.0)*wet;",
"    float rn=fbm2(vec2(uv.x*24.0,uv.y*70.0-uTime*0.5));",
"    float rcMix=smoothstep(0.28,0.72,fbm2(vec2(uv.x*5.6+2.0,uv.y*18.0-uTime*0.08)));",
"    vec3 rc2=mix(vec3(1.06,1.11,1.26),vec3(0.24,0.64,1.00),coldAt(uv.x));",
"    float reflShard=smoothstep(0.42,0.72,fbm3(vec2(uv.x*38.0,uv.y*150.0-uTime*0.55)));",
"    sand+=rc2*wr*rn*reflShard*(0.052+0.058*rcMix);",
"    /* the beach keeps a damp band under the water line : it mirrors the city */",
"    float dampBand=exp(-max(wy-uv.y,0.0)*3.4);",
"    vec3 mirrorCol=mix(vec3(1.0,0.20,0.55),vec3(0.18,0.56,1.00),coldAt(uv.x));",
"    float streak=smoothstep(0.44,0.86,fbm2(vec2(uv.x*78.0,uv.y*9.0+uTime*0.04)));",
"    float spark=smoothstep(0.62,0.95,fbm2(vec2(uv.x*92.0,uv.y*38.0-uTime*0.22)));",
"    sand+=mirrorCol*dampBand*(0.012+0.052*streak+0.068*spark);",
/* the wave throws a soft shadow forward onto the dry sand */
"    float ahead=1.0-smoothstep(0.0,0.075,wy-uv.y);",
"    sand*=1.0-0.42*ahead*uWave;",
/* --- the tide gives a warning before it lands --- */
/* the shadow the incoming swell throws on the dry sand */
"    float shBand=exp(-(((wy-uv.y-0.016)/0.026)*((wy-uv.y-0.016)/0.026)));",
"    sand*=1.0-0.40*shBand*uWave;",
/* the sand just ahead of the front turns wet and dark */
"    float surge=0.014+0.060*uTide;",
"    float front=clamp((wy-uv.y)/max(surge,0.0001),0.0,1.0);",
"    sand=mix(sand,sand*0.58,front*0.80*uWave);",
"    sand+=vec3(1.06,1.11,1.26)*front*0.060*uWave;",
/* the light on the crest is a glow on the sand : never a second line */
"    float crestGlow=exp(-(((wy-uv.y-0.0050)/0.0340)*((wy-uv.y-0.0050)/0.0340)));",
"    sand+=vec3(1.00,0.74,0.82)*crestGlow*0.20*uWave;",
"    /* the light standing in the air in front of the front : a wide weak bloom",
"       that gives the arrival a body instead of a ruled edge */",
"    float crestAir=exp(-(((wy-uv.y-0.0180)/0.0620)*((wy-uv.y-0.0180)/0.0620)));",
"    sand+=vec3(0.94,0.66,0.84)*crestAir*0.055*uWave;",
/* --- the tide arrives as a line of light, not as a wall -----------------
   The first version laid the front down in white blocks : the water came
   in as a row of cards, and the sea read as a paper cut-out.  A real
   arrival is not a wall.  It is a thin bright seam along the water line,
   scalloped by the swell, a broken halo of foam behind it, and a scatter
   of spray grains that come and go.  The front still travels and the sand
   still goes dark ahead of it, so the arrival stays unmistakable - but the
   sea stays a sea. */
"    float edgeD=wy-uv.y;",
/* the seam : thin, soft-edged, scalloped by the swell */
"    float lobe=0.0012+0.0060*fbm2(vec2(uv.x*6.5-uTime*0.42,3.1))",
"                +0.0026*fbm2(vec2(uv.x*23.0-uTime*0.90,8.4));",
"    float seam=exp(-(((edgeD-lobe)/0.0030)*((edgeD-lobe)/0.0030)));",
"    float seamN=0.14+0.86*smoothstep(0.14,0.74,fbm2(vec2(uv.x*11.0-uTime*0.62,2.7)));",
/* the foam behind the seam : a broken halo, never a slab */
"    float foam=exp(-(((edgeD-lobe-0.0054)/0.0150)*((edgeD-lobe-0.0054)/0.0150)));",
"    float foamN=smoothstep(0.20,0.74,fbm2(vec2(uv.x*19.0-uTime*0.95,5.3)));",
/* the spray : small soft grains, only along the front */
"    vec2 sg=vec2(uv.x*140.0,uv.y*360.0-uTime*0.40);",
"    vec2 sid=floor(sg); vec2 sf=fract(sg)-0.5;",
"    float spray=(1.0-smoothstep(0.0,0.24,length(sf)))*step(0.950,hash21(sid+9.3))",
"               *exp(-(((edgeD-lobe)/0.0086)*((edgeD-lobe)/0.0086)));",
/* the foam is lit by the light that falls on it : warm near the sun, cold
   away from it, so it belongs to the picture instead of sitting on it */
"    vec3 foamC=mix(vec3(1.30,0.58,1.58),vec3(1.70,0.44,1.06),min(1.0,lit*0.70+az*0.40));",
/* the swell decides how much of it is laid down : at rest the foam is gone,
   so the calm sea keeps no scar of the last tide */
"    float edgeLit=smoothstep(0.16,0.50,uWave);",
"    sand+=foamC*seam*seamN*0.40*edgeLit;",
"    sand+=foamC*foam*foamN*0.15*edgeLit;",
"    sand+=foamC*spray*0.55*edgeLit;",
/* --- the sand the tide has just left : still dark and glossy --- */
"    float damp=clamp((uMark-uv.y)/0.055,0.0,1.0)*(1.0-smoothstep(uMark-0.022,uMark+0.010,uv.y));",
"    sand=mix(sand,sand*0.62,damp*0.85);",
"    sand+=vec3(0.38,0.17,0.28)*damp*0.055;",
/* the wash left by the previous wave */
"    float wash=1.0-smoothstep(0.0,0.055,abs(uv.y-(wy-0.075)));",
"    sand=mix(sand,sand*vec3(0.72,0.80,1.0),wash*0.45*(0.35+0.65*uWave));",
"    float washEdge=exp(-(((uv.y-(wy-0.095))/0.0260)*((uv.y-(wy-0.095))/0.0260)));",
"    float washLace=smoothstep(0.34,0.86,fbm2(vec2(uv.x*44.0,uv.y*130.0)));",
"    sand+=mix(vec3(0.42,0.52,0.66),vec3(1.0,0.42,0.60),az)*washEdge*washLace*0.050*(0.42+0.58*uWave);",

"    c=mix(c,sand,beachM);",
"  }",
/* ---------- THE SEA ---------- */
"/* the sea does not begin on a ruled edge : it begins on the divide */",
"  float hzY=hzLine(uv.x,uTime);",
"  float hzAA=max(1.05/uRes.y,0.0010);",
"  float waterM=(1.0-beachM)*(1.0-smoothstep(hzY+0.0038-hzAA*1.5,hzY+0.0038+hzAA*1.5,uv.y));",
/* The sea is not white. Everything that stands up out of the water - the
   crest lines, the capillary ripple, the broken sheets, the drifting
   filaments, the spray at the edge - wears the colour of the water it
   stands in : the cold blue the city throws down on the left, the pink of
   the sun on the right.
   The sea-surface line at the divide keeps its white thread. A structure
   and its texture cannot be the same colour : paint that line the sea's
   colour as well and the sea becomes a stack of parallel lines with
   nothing to read them against. */
"  ",

"/* How much of the swell the sea is allowed to show. The surface is a",
"   plane : the wave lines are painted in the colour of the water they",
"   stand in, so they do not read as lines ruled across the surface.",
"   At zero the sea is one straight plane, and the only edges left in the",
"   picture are the white thread at the divide and the edge of the shore.",
"   Raise this to bring the swell back. */",
"  float seaFlat=smoothstep(0.16,0.55,uWave)*0.45;",
"  ",
"/* the colour the swell is painted in : the same indigo and the same plum,",
"   but without the neon in them.  A saturated line ruled across a surface",
"   reads as a drawn line, and the sea stops being a sea. */",
"  ",
"  ",
"  if(waterM>0.002){",
"    float dep=uv.y-wy;",
"    float seaDep=uv.y-uShore;",
"    float dn=clamp(seaDep*3.6,0.0,1.0);",
"    float grazing=1.0-smoothstep(0.0,0.19,uHorizon-uv.y);",
"    float fresnel=0.035+0.965*pow(grazing,2.15);",
"    float facing=0.45+0.55*smoothstep(-0.45,0.55,sin(uv.x*18.0+uv.y*85.0-uTime*0.72));",
"    vec3 w=mix(vec3(0.2050,0.2450,0.4900),vec3(0.2500,0.3000,1.0500),pow(dn,0.52));",
"    w*=0.87+0.20*facing;",
/* Fresnel: a dark, steep near-water view gives way to a mirror at the horizon. */
"    vec3 fresnelSky=skyPure*vec3(0.34,0.26,0.32)+vec3(0.010,0.007,0.012);",
"    w=mix(w,fresnelSky,fresnel*0.34);",
/* the horizon glow, reflected */
"    w+=vec3(0.60,0.24,0.40)*exp(-max(uHorizon-uv.y,0.0)*15.0)*az*0.30*uSunUp;",
/* the bed, seen through the shallow water */
"    vec2 ruv=uv+vec2(sin(uv.x*38.0+uTime*1.9)*0.006*dn,0.006*dn);",
"    vec3 bed=sandLight(sandAt(ruv,1.0),lit*0.70,1.0)*1.05;",
"    w=mix(w,bed,0.43*(1.0-dn));",
/* surface caustics and wind streaks */
"    float ca=fbm3(vec2(uv.x*22.0,uv.y*40.0-uTime*1.7));",
"    w+=vec3(0.20,0.10,0.17)*pow(ca,3.0)*0.17*dn*(1.0-dn*0.5);",
"    float streak=fbm2(vec2(uv.x*7.0+uv.y*1.8,uv.y*110.0-uTime*0.35));",
"    w*=1.0+0.10*(streak-0.5)*dn;",
/* the city, broken up and reflected in the water */
"    float reflSway=waveShape(uv.x*4.3,uTime*0.65)*0.0065*(0.25+dn);",
"    float reflY=uHorizon+clamp(uHorizon-uv.y,0.0,0.20)*0.46;",
"    float reflBreak=0.34+0.66*fbm2(vec2(uv.x*36.0,uv.y*165.0-uTime*1.2));",
"    float reflFade=(1.0-smoothstep(0.0,0.21,uHorizon-uv.y))*0.36+0.07;",
"    float reflMix=smoothstep(0.18,0.82,fbm2(vec2(uv.x*8.0+reflSway*80.0,uv.y*31.0-uTime*0.15)));",
"    vec3 reflTint=mix(vec3(1.06,1.11,1.26),vec3(0.26,0.66,1.00),coldAt(uv.x));",
"    w+=reflTint*pow(reflBreak,2.15)*reflFade*(0.034+0.055*dn);",
"    float bleed=exp(-max(uHorizon-uv.y,0.0)*7.5);",
"    w+=reflTint*bleed*(0.011+0.016*dn);",
"/* the cold city throws a column of its own into the water : the left",
"   half of the frame gets a vertical axis, so the picture stops being",
"   a single point of light standing at the sun */",
"    float coldCx=0.105+0.018*sin(uTime*0.47)+0.030*(fbm2(vec2(seaDep*6.0,uTime*0.05))-0.5);",
"    float coldCw=0.017+seaDep*0.058;",
"    float coldCol=exp(-(((uv.x-coldCx)/coldCw)*((uv.x-coldCx)/coldCw)));",
"    float coldFil=fbm2(vec2(uv.x*44.0+seaDep*1.0,seaDep*4.5-uTime*0.13));",
"    coldCol*=0.06+1.85*pow(coldFil,2.3);",
"    coldCol*=exp(-max(uHorizon-uv.y,0.0)*1.55)*(0.55+0.45*dn);",
"    w+=vec3(0.30,0.64,1.00)*coldCol*0.130;",
"/* the cold bank smears wider than the tower : a low cold haze under",
"   the whole left side of the water, so the column has ground to stand on */",
"    float coldBank=(1.0-smoothstep(0.04,0.50,uv.x))*exp(-max(uHorizon-uv.y,0.0)*2.8);",
"    w+=vec3(0.26,0.56,1.00)*coldBank*(0.10+0.90*pow(reflBreak,1.6))*0.020;",
"    float reflNeedle=1.0-smoothstep(0.002,0.010,abs(fract(uv.x*37.0+sin(uv.y*80.0+uTime))*0.5-0.25));",
"    w+=mix(vec3(1.06,1.11,1.26),vec3(1.000,0.360,0.688),az)*reflNeedle*dn*0.014;",
"    float chop=fbm3(vec2(uv.x*16.0+uv.y*3.0,uv.y*92.0-uTime*0.88));",
"    float trough=smoothstep(0.34,0.62,chop);",
"    w*=0.78+0.34*trough*dn;",
"/* The large shape of the swell.  This is what makes a surface read as a",
"   surface : big soft bands of light and shade that move slowly across the",
"   water.  The small break-up below is only the edge of them.  At rest the",
"   water is a plane, so the form is only there while the tide is up. */",
"    float swellForm=fbm2(vec2(uv.x*3.1+uTime*0.045,seaDep*9.0-uTime*0.10));",
"    w*=1.0+0.46*(swellForm-0.5)*dn*max(0.0,uWave-0.16);",
"    w+=vec3(0.13,0.14,0.19)*pow(swellForm,3.0)*dn*0.42*uWave;",
"    float cap=smoothstep(0.67,0.83,fbm3(vec2(uv.x*49.0,uv.y*148.0-uTime*1.15)));",
"    w+=mix(vec3(1.06,1.11,1.26),vec3(1.000,0.407,0.711),az)*cap*dn*0.022;",
"    float spark=fbm3(vec2(uv.x*96.0+uTime*0.23,uv.y*410.0-uTime*2.2));",
"    float glint=smoothstep(0.73,0.86,spark)*pow(fbm2(vec2(uv.x*210.0,uv.y*84.0-uTime*1.4)),3.0);",
"    w+=mix(vec3(1.06,1.11,1.26),vec3(1.000,0.423,0.719),az)*glint*dn*0.11;",

/* the city lies in shadow on the far side of the light */
"    float sh=1.0-exp(-(((uv.x-uSun.x)/0.50)*((uv.x-uSun.x)/0.50)));",
"    w*=1.0-0.26*sh*dn;",
/* the glitter path of the sun, broken by the same swell */
"    float gp=sunPath(uv,uTime,seaDep)*uSunUp;",
"    w+=vec3(1.0,0.34,0.60)*gp*5.20;",
"    w+=vec3(1.06,1.11,1.26)*gp*gp*0.22;",
"/* the risen water is a wet mirror : it carries the wedge of low light that",
"   the sand used to carry, so the tide brings light with it instead of",
"   taking the light away.  At rest it is nothing at all. */",
"    float mirrorFall=exp(-max(uHorizon-uv.y,0.0)*1.35);",
"    w+=vec3(1.0,0.40,0.62)*lit*mirrorFall*(0.255*uWave*uWave);",
"    float sw=(0.032+0.58*max(uHorizon-uv.y,0.0))*(0.82+0.24*sin(seaDep*46.0-uTime*0.38));",
"    float sunRefX=uSun.x+sin(seaDep*24.0-uTime*0.46)*0.011*(0.25+seaDep*2.5)-seaDep*seaDep*0.012;",
"    w+=vec3(1.0,0.32,0.54)*exp(-(((uv.x-sunRefX)/sw)*((uv.x-sunRefX)/sw)))*0.060*uSunUp*(0.55+0.75*swellPulse(uv,uTime,seaDep));",
/* the receding swell : the sea is a stack of thin broken lines,
   and the nearer the shore the bigger the swell */
"    float crests=0.0;",
"    float crestNear=0.0;",
"    for(int k=1;k<5;k++){",
"      float fk=float(k);",
"      float off=0.074-0.0190*(fk-1.0);",
"      float amp=(1.25-fk*0.16)*uWave*0.030+0.0022;",
"      float frq=1.0+fk*0.55;",
"      float rt=0.80+fk*0.22;",
"      float yk=wy+off+waveShape(uv.x*frq+fk*3.1,rt*uTime)*amp;",
"      float bw2=(0.0044-fk*0.00080)*(0.72+0.42*dn);",
"      float b=1.0-smoothstep(0.0,max(bw2,0.0006),abs(uv.y-yk));",
/* the crest is not a solid line : it breaks into separate glints */
"      float brk=smoothstep(0.36,0.74,fbm3(vec2(uv.x*30.0+fk*7.0,uv.y*70.0-uTime*0.9)));",
"      float w=(1.0-fk*0.14);",
"      crests=max(crests,b*brk*w);",
/* the swell closest to the shore throws a crest of its own */
"      if(k==1) crestNear=max(crestNear,b*brk*brk);",
"    }",
"    float ccol=floor(uv.x*22.0);",
"    float ch=hash11(ccol*2.7+9.0);",
"    float ch2=hash11(ccol*5.3+1.0);",
"    vec3 cityC=mix(vec3(1.06,1.11,1.26),vec3(0.26,0.66,1.00),coldAt(uv.x)*(0.55+0.45*step(0.42,ch)));",
"    w+=mix(vec3(0.48,0.17,0.31),cityC,0.28+0.72*ch2)*crests*0.25*(1.0-dn*0.25);",
"    w+=mix(vec3(1.06,1.11,1.26),vec3(0.26,0.66,1.00),coldAt(uv.x))*crestNear*0.16;",
/* capillary ripples : a very fine, barely there texture */
"    float fine=0.0;",
"    for(int k=0;k<2;k++){",
"      float fk=float(k);",
"      float yk2=wy+0.007+fk*0.015+sin(uv.x*46.0+uTime*1.3+fk)*0.0016",
"                 +waveShape(uv.x*9.0+fk*5.0,uTime*0.9)*0.0035;",
"      float b2=1.0-smoothstep(0.0,0.0010,abs(uv.y-yk2));",
"      fine=max(fine,b2*(0.45+0.55*fbm2(vec2(uv.x*64.0,uv.y*24.0-uTime*0.7))));",
"    }",
"    w+=mix(vec3(1.06,1.11,1.26),vec3(1.000,0.407,0.711),az)*fine*0.072*(1.0-dn*0.45);",
/* the sky lies on the water as thin broken sheets */
"    float sheets=0.0;",
"    for(int k=0;k<2;k++){",
"      float fk=float(k);",
"      float yk3=wy+0.018+fk*0.026+waveShape(uv.x*5.2+fk*7.0,uTime*0.7)*0.0055;",
"      sheets+=1.0-smoothstep(0.0,0.0016,abs(uv.y-yk3));",
"    }",
"    w+=mix(vec3(1.06,1.11,1.26),vec3(1.000,0.407,0.711),az)*sheets*0.028*(1.0-dn*0.5);",
"    /* the rain landing on the water : rings that open, and a small flash */",
"    float rings=0.0;",
"    for(int i=0;i<2;i++){",
"      float fi=float(i);",
"      float sc=38.0+fi*34.0;",
"      vec2 g=vec2(uv.x*uRes.x/uRes.y,uv.y)*sc;",
"      vec2 id=floor(g);",
"      vec2 fp=fract(g)-0.5;",
"      float h=hash21(id+fi*17.0);",
"      float ph=fract(uTime*0.34+h);",
"      float rr=ph*0.44;",
"      float ring=1.0-smoothstep(0.0,0.060,abs(length(fp)-rr));",
"      rings+=ring*step(0.90,h)*(1.0-ph)*(1.0-ph);",
"    }",
"    w+=vec3(0.32,0.74,1.00)*rings*0.052*(1.0-dn*0.40);",
"    float buoy=0.0;",
"    for(int i=0;i<3;i++){",
"      float fi=float(i);",
"      float bx=0.120+fi*0.365+0.0035*sin(uTime*0.07+fi*2.3);",
"      float by=uHorizon-0.052-fi*0.030;",
"      float bd=length((uv-vec2(bx,by))*vec2(uRes.x/uRes.y,1.0));",
"      float bl=0.35+0.65*step(0.42,sin(uTime*1.05+fi*2.1));",
"      buoy+=exp(-bd*300.0)*bl;",
"      buoy+=exp(-bd*30.0)*bl*0.10;",
"    }",
"    w+=vec3(0.24,0.68,1.00)*buoy*0.38;",
/* thin filaments drifting over the water : the contour of the swell */
"    float fil=0.0;",
"    for(int i=0;i<3;i++){",
"      float fi=float(i);",
"      float ly2=wy+0.010+fi*0.052+sin(uTime*0.09+fi*2.0)*0.004;",
"      float wob=waveShape(uv.x*2.4+fi*3.0,uTime*0.4)*0.0055;",
"      if(abs(uv.y-ly2-wob)<0.004) fil+=exp(-(((uv.y-ly2-wob)/0.00045)*((uv.y-ly2-wob)/0.00045)))*(1.0-fi*0.22);",
"    }",
"    w+=mix(vec3(1.06,1.11,1.26),vec3(0.26,0.66,1.00),coldAt(uv.x))*fil*0.066;",
/* the breaking edge at the shore : a thin hard shell of foam broken into
   angular shards ; the softness is transparency, never blur */
"    float fn=fbm3(vec2(uv.x*54.0,dep*210.0-uTime*2.4));",
"    float foamFine=fbm3(vec2(uv.x*260.0,dep*620.0-uTime*2.8));",
"    float shard=smoothstep(0.26,0.58,fn)*(0.54+0.46*foamFine);",
"    float crest=smoothstep(-0.15,0.55,waveShape(uv.x,uTime*0.8));",
/* the shell is the height of the wave, not a fixed width of paint : it
   thickens where the water runs up and thins where it falls back */
"    float shellW=0.0022+0.0036*fn+0.0026*crest;",
"    float shell=1.0-smoothstep(0.0,shellW,abs(dep));",
"    float skirt=(1.0-smoothstep(0.0,0.010,abs(dep+0.007)))*smoothstep(0.18,0.68,foamFine);",
"    float backWash=(1.0-smoothstep(0.0,0.0028,abs(dep-0.012-waveShape(uv.x*3.8,uTime*1.3)*0.0028)));",
"    vec3 foamC=mix(vec3(1.30,0.58,1.58),vec3(1.70,0.44,1.06),min(1.0,lit*0.70+az*0.40));",
"    float amt=(0.26+0.85*crest)*shard;",
"    w=mix(w,foamC,clamp(shell*amt*(0.44+0.50*foamFine),0.0,0.92));",
"    w+=foamC*skirt*amt*0.14;",
"    w+=vec3(1.48,0.46,0.88)*shell*amt*0.23;",
"    w+=foamC*backWash*foamFine*0.12*uWave*(0.4+0.6*dn);",
/* the far water dissolves into the sky : aerial perspective */
"    float hzD=uv.y-hzY;",
"    float hz=smoothstep(-0.090,0.0030,hzD);",
"    w=mix(w,skyPure*0.30+vec3(0.013,0.024,0.044),hz*hz*0.60);",
/* --- the seam refracts : a short band of water is folded up into the air,
       and the slope of the divide drags it sideways while it does so --- */
"/* The divide does not get a line of its own. The datum line in the",
"   overlay is the one ruled white line in the frame, and a second,",
"   wandering white line under it reads as a wave drawn on the picture",
"   rather than as the edge of the water. */",
/* the wet rim itself : light scattering along the grazing surface, broken
   into arcs so it never reads as a drawn line */

"    c=mix(c,w,waterM);",
"  }",
/* A low marine haze softens the physical seam between water and dry sand. */
"  float shoreMist=exp(-(((uv.y-(uShore+0.006))/0.016)*((uv.y-(uShore+0.006))/0.016)));",
"  float mistBreak=0.62+0.38*fbm2(vec2(uv.x*3.2-uTime*0.012,uv.y*42.0));",
"  vec3 mistC=mix(vec3(0.050,0.036,0.048),skyPure*0.30,0.42);",
"  c=mix(c,mistC,shoreMist*mistBreak*0.050);",
/* --- the other half of the refraction : the air immediately above the
       divide carries a thin, wavering echo of the wet edge --- */
"  float airD=hzY-uv.y;",
"  float airSm=exp(-((airD/0.0042)*(airD/0.0042)))*(1.0-waterM);",
"  float airGate=smoothstep(0.24,0.72,fbm2(vec2(uv.x*15.0+2.0,uTime*0.045)));",
"  c+=mix(vec3(1.00,0.40,0.62),vec3(0.26,0.66,1.00),coldAt(uv.x))",
"      *airSm*airGate*(0.030+0.055*uSunUp)*(0.55+0.45*az);",
"  vec4 craft=seaCraft(uv,uTime);",
"  c=mix(c,craft.rgb,craft.a);",
/* one-pixel crest : a hard bright edge plus a small broken foam shelf.
   The edge is not a drawn line either : a fine chop rides on the swell,
   arriving in drifting patches, so the foam itself is never a ruled
   line, but it stays one thin break rather than a bank of lace. */
"  float chopGate=0.20+0.80*smoothstep(0.30,0.76,fbm2(vec2(uv.x*9.0+uTime*0.05,2.7)));",
"  float fineWave=wy+0.0018*chopGate*(sin(uv.x*143.0-uTime*2.60)+0.55*sin(uv.x*271.0+uTime*3.90));",
"  float edgeDist=abs(uv.y-fineWave);",
"  float edgeAA=max(min(sceneAA(uv.y-fineWave),0.0035),1.1/uRes.y);",
"  float edgeShell=1.0-smoothstep(edgeAA*0.55,edgeAA*3.2,edgeDist);",
"  float edgeBreak=fbm3(vec2(uv.x*160.0,uv.y*44.0-uTime*1.25));",
/* Foam gathers : the thread along the water line comes and goes in slow
   drifting lobes instead of running dead straight from one side to the
   other, and it is soft at its edges because water has no edge of its own. */
"  float edgeLobe=0.34+0.66*smoothstep(0.16,0.64,fbm2(vec2(uv.x*12.5-uTime*0.065,uv.y*8.0+1.7)));",
"  float foamLine=edgeShell*smoothstep(0.28,0.76,edgeBreak)*edgeLobe;",
"  vec3 foamEdge=mix(vec3(1.08,0.90,1.48),vec3(1.46,0.68,1.14),smoothstep(0.58,0.86,az));",
"  c=mix(c,foamEdge,foamLine*(0.22+0.34*uWave));",
"  c+=foamEdge*foamLine*0.060;",
/* ==================================================================
   THE TIDE LINE, IN COLOURS
   The edge of the water is not one colour.  It is the white of the crest
   that breaks on it, the cold blue the city lays along the wet lip, the
   pink of the god lying in the water like a lamp put under the sand, and
   the violet where the two of them touch.  None of them is a ruled line :
   every layer has its own noise, its own thickness and its own way of
   coming and going, so what crosses the frame is a bank of wet light and
   not an edge of paint.  The sea has two lights in it, and the line
   between them is where they are both present.
   ================================================================== */
"  float dUp=uv.y-fineWave;",
"  float dDn=fineWave-uv.y;",
"  float laceN=fbm2(vec2(uv.x*19.0-uTime*0.07,uv.y*11.0+2.2));",
"  float laceGate=smoothstep(0.26,0.70,laceN);",
/* 1 : the white of the breaking crest.  The thinnest and the hardest thing
       on the line, and it is only there where the foam is really breaking :
       a thread of light that arrives in patches and is gone again. */
"  float crestN=fbm3(vec2(uv.x*330.0,uv.y*70.0-uTime*2.6));",
"  float whiteCore=(1.0-smoothstep(edgeAA*0.05,edgeAA*1.15,edgeDist))",
"      *smoothstep(0.48,0.88,crestN*0.62+edgeBreak*0.38)*edgeLobe;",
"  c+=mix(vec3(1.08,0.95,1.52),vec3(1.48,0.74,1.24),0.18+0.70*az)*whiteCore*(0.34+0.58*uWave);",
/* 2 : the violet.  The pink of the god and the blue of the city, mixed in
       the few millimetres where they touch. */
"  float violW=0.0021+0.0030*laceN;",
"  float violet=(1.0-smoothstep(0.0,violW,edgeDist))*laceGate;",
"  c+=mix(vec3(1.000,0.404,0.706),vec3(0.320,0.760,1.000),0.40+0.22*laceN)",
"      *violet*(0.070+0.130*uWave);",
/* 3 : the cold blue.  The city on the lip of the wave, on the water side
       of the line, where the wave is still standing up. */
"  float blueW=0.0022+0.0032*laceN;",
"  float blueLip=smoothstep(0.0,0.0010,dUp)*(1.0-smoothstep(0.0,blueW,dUp))*laceGate;",
"  c+=vec3(1.06,1.11,1.26)*blueLip*(0.050+0.090*uWave);",
/* 4 : the pink.  The god lying in the wet sand under the water, on the sand
       side of the line, where the water is already pulling back. */
"  float pinkW=0.0032+0.0044*laceN;",
"  float pinkWet=smoothstep(0.0,0.0012,dDn)*(1.0-smoothstep(0.0,pinkW,dDn))*laceGate;",
"  c+=vec3(1.000,0.404,0.706)*pinkWet*(0.045+0.095*uWave)*(0.40+0.60*az);",
/* 4b : the thread the water leaves behind as it draws back.  It is a second
        edge, broken into dashes and lying a little lower, and it is what
        says that the line is moving and not ruled. */
"  float backN=fbm2(vec2(uv.x*88.0+1.7,uv.y*26.0-uTime*0.85));",
"  float backD=0.0034+0.0032*laceN;",
"  float backThread=(1.0-smoothstep(0.0,0.0018,abs(dDn-backD)))",
"      *smoothstep(0.46,0.90,backN);",
"  c+=mix(vec3(1.000,0.404,0.706),vec3(0.320,0.760,1.000),coldAt(uv.x))",
"      *backThread*(0.034+0.060*uWave);",
/* 5 : the spray.  What the break throws into the air : a scatter of specks
       that catch the pink on one side of the frame and the blue on the
       other, and that are gone the moment the wave is not breaking. */
"  float sprayN=fbm2(vec2(uv.x*190.0+uTime*0.30,uv.y*330.0-uTime*2.2));",
"  float spray=smoothstep(0.72,0.96,sprayN)*smoothstep(0.0,0.0007,dUp)",
"      *(1.0-smoothstep(0.0,0.0060,dUp));",
"  c+=mix(vec3(1.000,0.404,0.706),vec3(0.320,0.760,1.000),coldAt(uv.x))",
"      *spray*(0.090+0.150*uWave);",
/* 6 : the glow the edge lays on the wet sand.  A wide and very soft wash
       of violet and pink, and the reason the sand under a wave is never
       the same colour as the sand further down the beach. */
"  float washW=0.009+0.013*laceN;",
"  float washGlow=exp(-(dDn/washW)*(dDn/washW))*smoothstep(-0.0004,0.0022,dDn);",
"  c+=mix(vec3(0.640,0.420,0.880),vec3(1.000,0.404,0.706),0.32+0.46*az)",
"      *washGlow*(0.026+0.055*uWave);",
/* mouse halo */
"  if(uMouseOn>0.5){",
"    float r=length((uv-uMouse)*vec2(px,1.0));",
"    c+=vec3(0.32,0.64,1.00)*exp(-r*10.0)*0.135;",
"  }",
"  c+=mix(vec3(1.00,0.360,0.640),vec3(0.30,0.62,1.00),smoothstep(0.02,0.98,uv.y))*uFlash*0.17*(0.42+0.58*smoothstep(1.00,0.12,uv.y));",
"/* The darks are tinted, not dyed.  Two thirds of this frame is under a",
"   quarter of the light, and a shadow at full saturation reads as coloured",
"   paper rather than as night.  So the chroma is pulled back where the frame",
"   is dark and left alone where the light is.  Mixing a colour towards its",
"   own luminance leaves the luminance exactly where it was : the blacks stay",
"   black, only the dye comes out. */",
"  gl_FragColor=vec4(c,airDepth);",
"}"
].join("\n");

/* ---------- EROSION (ping-pong) : the tide takes the writing back ---------- */
var ERO_SRC = LIB + [
"varying vec2 vUv;",
"uniform sampler2D uEro;",
"uniform float uTime,uTide,uWave,uShore,uMax;",
"uniform vec4 uBox;",
"void main(){",
"  float prev=texture2D(uEro,vUv).r;",
"  vec2 st=uBox.xy+vUv*uBox.zw;",
"  float wy=waveY(st.x,mix(uShore,uMax,uTide),uWave*0.035,uTime);",
"  float gap=wy-st.y;",
/* The sea does not wait for the sand to dry. The mark is washed away in
   the band the water is about to reach, and because the record is kept
   as a maximum it can never come back when the tide goes out again. */
"  float n=hash21(floor(vUv*256.0)*1.7);",
"  float band=0.034*(0.78+0.50*n);",
"  float wash=1.0-smoothstep(0.0,band,gap);",
"  float p=max(prev,wash);",
"  gl_FragColor=vec4(p,p,p,1.0);",
"}"
].join("\n");

/* ---------- BLOOM : bright pass + separable blur ---------- */
var BRIGHT_SRC = LIB + [
"varying vec2 vUv;",
"uniform sampler2D uTex;",
"uniform float uThresh;",
"void main(){",
"  vec3 c=texture2D(uTex,vUv).rgb;",
"  float l=max(max(c.r,c.g),c.b);",
"  float k=max(l-uThresh,0.0)/max(l,1e-4);",
"  gl_FragColor=vec4(c*k,1.0);",
"}"
].join("\n");

var BLUR_SRC = LIB + [
"varying vec2 vUv;",
"uniform sampler2D uTex;",
"uniform vec2 uDir;",
"void main(){",
"  vec3 s=texture2D(uTex,vUv).rgb*0.227027;",
"  s+=texture2D(uTex,vUv+uDir*1.3846).rgb*0.316216;",
"  s+=texture2D(uTex,vUv-uDir*1.3846).rgb*0.316216;",
"  s+=texture2D(uTex,vUv+uDir*3.2308).rgb*0.070270;",
"  s+=texture2D(uTex,vUv-uDir*3.2308).rgb*0.070270;",
"  gl_FragColor=vec4(s,1.0);",
"}"
].join("\n");

/* ---------- POST : tonemap, bloom, vignette, grain ---------- */
var POST_SRC = LIB + [
"varying vec2 vUv;",
"uniform sampler2D uTex,uBloom;",
"uniform vec2 uRes;",
"uniform float uTime,uBloomK,uHorizon,uShore;",
"vec3 aces(vec3 x){ return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14),0.0,1.0); }",
/* slanted rain : two parallax layers of streaks, over the whole frame */
/* rain : sparse, uneven, each drop a different length and speed */
"float rainLayer(vec2 uv,float speed,float density,float seed){",
"  float asp=uRes.x/uRes.y;",
"  vec2 p=uv;",
"  p.x+=p.y*0.075;",
"  vec2 q=vec2(p.x*asp*84.0,p.y*11.5-uTime*speed);",
"  vec2 id=floor(q);",
"  vec2 f=fract(q);",
"  float present=step(1.0-density,hash21(id+seed));",
"  float thin=1.0-smoothstep(0.010,0.080,abs(f.x-0.5));",
"  float run=1.0-smoothstep(0.06,0.48,abs(f.y-0.45));",
"  return present*thin*run*(0.60+0.40*hash21(id+seed+9.1));",
"}",
"float skyRuling(vec2 uv){",
"  float py=uv.y*uRes.y;",
"  float warp=(fbm2(vec2(uv.x*1.8,uv.y*2.1))-0.5)*2.6;",
"  float rowFine=py/9.5+warp;",
"  float rowBroad=py/54.0+warp*0.25;",
"  float rowId=floor(rowFine);",
"  float fineDist=abs(fract(rowFine)-0.5)*9.5;",
"  float broadDist=abs(fract(rowBroad)-0.5)*54.0;",
"  float fine=1.0-smoothstep(0.16,0.62,fineDist);",
"  float core=1.0-smoothstep(0.0,0.16,fineDist);",
"  float broad=1.0-smoothstep(0.35,1.35,broadDist);",
"  float dash=0.62+0.38*smoothstep(0.18,0.75,fbm2(vec2(uv.x*11.0+rowId*1.3,rowId*0.37)));",
"  float grit=0.78+0.22*fbm2(vec2(uv.x*90.0,rowId*1.9+uTime*0.01));",
"  return (fine*(0.26+0.04*hash11(rowId))+core*0.07+broad*0.028)*dash*grit;",
"}",
"void main(){",
"  vec2 uv=vUv; vec2 d=uv-0.5;",
/* Only distant sky and the background skyline soften. The beach never does. */
"  float depthMask=texture2D(uTex,uv).a;",
"  float softBand=smoothstep(0.42,0.73,depthMask)*smoothstep(uHorizon+0.002,uHorizon+0.085,uv.y);",
"  float dofR=softBand*1.25;",
"  vec2 px=dofR/uRes;",
"  vec2 ca=d*0.00014*softBand;",
"  vec3 base=vec3(texture2D(uTex,uv+ca).r,texture2D(uTex,uv).g,texture2D(uTex,uv-ca).b);",
"  vec3 soft=texture2D(uTex,uv+vec2(px.x*1.7,0.0)).rgb*0.25;",
"  soft+=texture2D(uTex,uv-vec2(px.x*1.7,0.0)).rgb*0.25;",
"  soft+=texture2D(uTex,uv+vec2(0.0,px.y*0.75)).rgb*0.25;",
"  soft+=texture2D(uTex,uv-vec2(0.0,px.y*0.75)).rgb*0.25;",
"  vec3 c=mix(base,soft,softBand*0.42);",
"  vec2 tx=vec2(1.0/uRes.x,1.0/uRes.y);",
"  vec3 around=texture2D(uTex,uv+vec2(tx.x,0.0)).rgb;",
"  around+=texture2D(uTex,uv-vec2(tx.x,0.0)).rgb;",
"  around+=texture2D(uTex,uv+vec2(0.0,tx.y)).rgb;",
"  around+=texture2D(uTex,uv-vec2(0.0,tx.y)).rgb;",
"  vec3 crisp=max(base*1.14-around*0.035,vec3(0.0));",
"  float sandMask=1.0-smoothstep(uShore-0.006,uShore+0.006,uv.y);",
"  float foregroundMask=1.0-smoothstep(0.05,0.34,depthMask);",
"  c=mix(c,crisp,max(sandMask*0.44,foregroundMask*0.30));",
"  c+=texture2D(uBloom,uv).rgb*uBloomK;",
"  float rainAz=exp(-(((uv.x-0.66)/0.34)*((uv.x-0.66)/0.34)));",
"  vec3 rainC=mix(vec3(1.06,1.11,1.26),vec3(0.88,0.80,0.70),rainAz);",
"  float rain=rainLayer(uv,1.75,0.16,3.1)*0.034+rainLayer(uv+vec2(0.043,0.011),3.10,0.10,17.7)*0.020;",
"  c+=rainC*rain*smoothstep(0.01,0.16,uv.y);",
"  c=aces(c*vec3(1.014,0.996,1.014));",
"  float lum=dot(c,vec3(0.2126,0.7152,0.0722));",
"  c=mix(vec3(lum),c,1.050);",
"  c+=vec3(0.006,0.001,0.008)*(1.0-smoothstep(0.0,0.42,lum));",
"  c*=1.0-0.13*pow(length(d*vec2(1.0,1.08)),2.25);",
"  float skyMask=smoothstep(0.80,0.99,depthMask);",
"  float skyLine=skyRuling(uv)*smoothstep(uHorizon+0.002,uHorizon+0.035,uv.y);",
"  c=mix(c,c*vec3(0.76,0.62,0.68),clamp(skyLine,0.0,0.50)*skyMask);",
"  float g=hash21(uv*uRes+fract(uTime*0.7)*137.0);",
"  c+=(g-0.5)*0.0020;",
"  gl_FragColor=vec4(max(c,vec3(0.0)),1.0);",
"}"
].join("\n");

/* ---------- CRISP HERO SKYLINE : actual triangles, independent of the sky pass ---------- */
var BUILD_VS_SRC = [
"attribute vec2 aPos;",
"attribute vec2 aLocal;",
"attribute vec3 aColor;",
"attribute vec3 aStyle;",
"varying vec2 vLocal;",
"varying vec3 vColor;",
"varying vec3 vStyle;",
"varying vec2 vPos;",
"void main(){",
"  vLocal=aLocal;",
"  vColor=aColor;",
"  vStyle=aStyle;",
"  vPos=aPos;",
"  gl_Position=vec4(aPos*2.0-1.0,0.0,1.0);",
"}"
].join("\n");

var BUILD_FS_SRC = [
"precision highp float;",
"varying vec2 vLocal;",
"varying vec3 vColor;",
"varying vec3 vStyle;",
"varying vec2 vPos;",
"uniform float uTime;",
"uniform vec2 uSun;",
"uniform float uLit;",
"float hash11(float p){ p=fract(p*0.1031); p*=p+33.33; p*=p+p; return fract(p); }",
"float hash21(vec2 p){ vec3 q=fract(vec3(p.xyx)*0.1031); q+=dot(q,q.yzx+33.33); return fract((q.x+q.y)*q.z); }",
"void main(){",
"  float seed=vStyle.x,kind=vStyle.y,face=vStyle.z;",
"  float sOn=smoothstep(fract(seed*0.137+0.21)*0.50,fract(seed*0.137+0.21)*0.50+0.24,uLit);",
"  vec3 c=vColor;",
"  float alpha=1.0;",
"if(kind<0.5){",
"  float land=step(0.125,kind);",
  "    float cols=face>0.5?3.0:5.0;",
  "    vec2 g=vec2(vLocal.x*cols,vLocal.y*11.0);",
"    vec2 wf=fract(g);",
"    vec2 cell=floor(g);",
  "    float panes=step(0.14,wf.x)*step(wf.x,0.86)*step(0.20,wf.y)*step(wf.y,0.74);",
  "float columnOn=step(0.48-0.22*land,hash11(cell.x+seed*17.0+face*3.0));",
  "float cellOn=step(0.68-0.26*land,hash21(cell+seed*31.0+face*7.0));",
  "    float ribbon=step(0.88,hash11(cell.y+seed*5.0));",
  "    float occupied=max(columnOn*cellOn,ribbon);",
/* every room keeps its own clock and is switched on and off without
   warning, so no two windows are ever in step */
"    float rw=hash11(cell.x*1.7+cell.y*2.3+seed*0.7);",
"    float rtick=floor(uTime*(0.13+0.26*rw)+rw*31.0);",
"    float rfk=hash21(vec2(rw*13.7,rtick*2.9+rw*7.0));",
"    float rlvl=0.44+0.56*hash21(vec2(rtick*3.1+rw*5.0,rw));",
"    float breathe=step(0.30,rfk)*(0.40+0.60*rlvl)*(0.94+0.06*sin(uTime*1.6+rw*6.28));",
  "    vec3 warm=vec3(1.06,1.11,1.26);",
  "    vec3 cool=vec3(0.30,0.70,1.00);",
  "    vec3 pinkW=vec3(1.000,0.454,0.734);",
  "    float warmZ=smoothstep(0.18,0.60,abs(vPos.x-uSun.x));",
  "    float coldMix=smoothstep(0.30,0.60,warmZ);",
  "    float br=hash21(cell+seed*29.0+7.0);",
  "vec3 window=mix(mix(warm,cool,coldMix),cool,land);",
  "window=mix(window,warm,step(0.82,br)*0.40*(1.0-land));",
  "window=mix(window,pinkW,step(0.93,br)*0.75*(1.0-smoothstep(0.08,0.55,warmZ))*(1.0-land));",
  "    window=mix(window,window*vec3(0.74,0.82,1.06),step(0.92,hash21(cell+seed*11.0))*0.55);",
  "",
  "",
  "",
  "    float floorLedge=step(0.92,fract(vLocal.y*11.0));",
  "    c*=0.86+0.14*smoothstep(0.0,1.0,vLocal.y);",
  "    c*=1.0-0.12*floorLedge;",
  "    c*=1.0-0.08*step(0.82,fract(vLocal.x*5.0+seed));",
  "    c=mix(c,c*0.42,panes*0.62);",
  "  c+=window*panes*occupied*breathe*(face>0.5?0.10:0.17)*(1.0+0.95*land)*sOn;",
  "  /* the sun rakes the blocks : the corner that faces it takes a thin line */",
  "  float sdx=uSun.x-vPos.x;",
  "  float graze=exp(-abs(sdx)*1.7);",
  "  float edgeP=face<0.5 ? (sdx>0.0 ? vLocal.x : 1.0-vLocal.x) : 1.0;",
  "  float litEdge=face<0.5 ? smoothstep(0.945,1.0,edgeP)*graze : (sdx>0.0?graze*0.50:0.0);",
  "  c+=mix(vec3(0.30,0.58,1.00),vec3(1.0,0.42,0.64),graze)*litEdge*0.28;",
  "    float edge=min(vLocal.x,1.0-vLocal.x);",
  "    c*=0.88+0.12*smoothstep(0.0,0.035,edge);",
  "    c*=face>0.5?0.86:1.0;",
  "    alpha=face>0.5?0.92:0.985;",
"  }else if(kind<1.5){",
  "    c*=(0.90+0.06*sin(uTime*(0.20+0.13*hash11(seed*3.0))+seed*4.0))*sOn;",
  "    alpha=0.98;",
"  }else if(kind<2.5){",
  "    float panel=step(0.88,fract(vLocal.y*6.0+seed));",
  "    c*=0.88+0.12*smoothstep(0.0,1.0,vLocal.y);",
  "    c*=1.0-0.10*panel;",
  "    if(face>2.5){",
  "      float scan=pow(0.5+0.5*sin(vLocal.y*21.0-uTime*4.2),16.0);",
  "      float glitch=step(0.93,hash11(floor(vLocal.y*17.0)+floor(uTime*5.0)));",
  "      c*=0.92+0.20*scan+0.06*glitch;",
  "    }",
  "    alpha=0.97;",
"  }else if(kind<3.5){",
  "    c*=0.88+0.12*smoothstep(0.0,1.0,vLocal.y);",
  "    alpha=0.46;",
"}else{",
"  float blink=step(0.45,sin(uTime*0.62+seed*2.7));",
"  c*=mix(1.0,0.26+0.74*blink,step(4.5,kind));",
"  c*=(0.96+0.04*sin(uTime*1.7+seed*3.1))*sOn;",
"  alpha=0.98;",
"  }",
"  gl_FragColor=vec4(c,alpha);",
"}"
].join("\n");

/* ==================================================================
   2. WEBGL RUNTIME
   ================================================================== */
function compile(type,src){
  var s=gl.createShader(type);
  gl.shaderSource(s,src); gl.compileShader(s);
  if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)+"\n"+src);
  return s;
}
function program(vs,fs){
  var p=gl.createProgram();
  gl.attachShader(p,compile(gl.VERTEX_SHADER,vs));
  gl.attachShader(p,compile(gl.FRAGMENT_SHADER,fs));
  gl.bindAttribLocation(p,0,'aPos');
  gl.linkProgram(p);
  if(!gl.getProgramParameter(p,gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  return p;
}
function uniforms(p,names){
  var o={}; for(var i=0;i<names.length;i++) o[names[i]]=gl.getUniformLocation(p,names[i]);
  return o;
}

var progScene,progEro,progPost,progBright,progBlur,progBuild,U={},UE={},UP={},UB={},UBLUR={},BU={};
var quad=null,skylineBuf=null,BUILD_COUNT=0,BA={pos:0,local:1,color:2,style:3};
function makeQuad(){
  quad=gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER,quad);
  gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
  gl.enableVertexAttribArray(0);
  gl.vertexAttribPointer(0,2,gl.FLOAT,false,0,0);
}
function drawQuad(){
  gl.bindBuffer(gl.ARRAY_BUFFER,quad);
  gl.enableVertexAttribArray(0);
  gl.vertexAttribPointer(0,2,gl.FLOAT,false,0,0);
  gl.drawArrays(gl.TRIANGLES,0,3);
}

function newTex(w,h,filter){
  var t=gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D,t);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,w,h,0,gl.RGBA,gl.UNSIGNED_BYTE,null);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,filter||gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,filter||gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
  return t;
}
function newTexF(w,h,filter){
  var t=gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D,t);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,w,h,0,gl.RGBA,FLOAT_TYPE,null);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,filter||gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,filter||gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
  return t;
}
function newFBO(tex){
  var f=gl.createFramebuffer();
  gl.bindFramebuffer(gl.FRAMEBUFFER,f);
  gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,tex,0);
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  return f;
}
function bindTex(unit,tex,loc){
  gl.activeTexture(gl.TEXTURE0+unit);
  gl.bindTexture(gl.TEXTURE_2D,tex);
  gl.uniform1i(loc,unit);
}

function skylineHash(n){
  var v=Math.sin(n*12.9898)*43758.5453;
  return v-Math.floor(v);
}
function addSkyQuad(data,p0,p1,p2,p3,color,seed,kind,face){
  var uv=[[0,0],[1,0],[1,1],[0,1]],order=[0,1,2,0,2,3];
  for(var i=0;i<order.length;i++){
    var k=order[i],p=[p0,p1,p2,p3][k],t=uv[k];
    data.push(p[0],p[1],t[0],t[1],color[0],color[1],color[2],seed,kind,face);
  }
}
function buildSkyline(){
  var data=[];
  var specs=[
    {cx:0.076,hw:0.037,h:0.235,side:0.023,drop:0.010,seed:1.7,waist:0.70,upper:0.72,landmark:1},
    {cx:0.245,hw:0.020,h:0.140,side:0.012,drop:0.007,seed:3.9,waist:0.76,upper:0.82},
    {cx:0.858,hw:0.040,h:0.188,side:0.024,drop:0.009,seed:7.2,waist:0.72,upper:0.76},
    {cx:0.951,hw:0.023,h:0.138,side:0.014,drop:0.007,seed:9.4,waist:0.76,upper:0.82}
  ];
  var px=0.40/W,py=0.36/H;
  function q(p0,p1,p2,p3,color,seed,kind,face){
    addSkyQuad(data,p0,p1,p2,p3,color,seed,kind,face);
  }
  function vbar(x,y0,y1,color,seed,kind){
    q([x-px,y0],[x+px,y0],[x+px,y1],[x-px,y1],color,seed,kind||0.75,0.8);
  }
  function hbar(x0,x1,y,color,seed,kind){
    q([x0,y-py],[x1,y-py],[x1,y+py],[x0,y+py],color,seed,kind||0.75,0.8);
  }
  function lampBlock(x,y,color,seed){
    var hw=4.0/W,hh=5.0/H,lineH=0.32/H;
    var shell=[color[0]*0.16,color[1]*0.14,color[2]*0.18];
    q([x-hw/2,y-hh/2],[x+hw/2,y-hh/2],[x+hw/2,y+hh/2],[x-hw/2,y+hh/2],
      shell,seed,3,0);
    q([x-hw/2,y-hh/2-lineH],[x+hw/2,y-hh/2-lineH],
      [x+hw/2,y-hh/2+lineH],[x-hw/2,y-hh/2+lineH],color,seed+2.0,4,0);
  }
  function wire(x0,y0,x1,y1,sag,seed,glow,glowSeed){
    var n=22,wp=0.30/H;
    for(var w=0;w<n;w++){
      var t0=w/n,t1=(w+1)/n;
      var ax=x0+(x1-x0)*t0,bx=x0+(x1-x0)*t1;
      var ay=y0+(y1-y0)*t0-sag*4.0*t0*(1.0-t0);
      var by=y0+(y1-y0)*t1-sag*4.0*t1*(1.0-t1);
      q([ax,ay-wp],[bx,by-wp],[bx,by+wp],[ax,ay+wp],
        [0.150,0.140,0.168],seed+w*0.013,2,2);
    }
/* the line carries its own lights : a small box and a lamp, four times */
    var lamps=[0.11,0.34,0.60,0.84];
    for(var k=0;k<lamps.length;k++){
      var lt=lamps[k];
      var lx=x0+(x1-x0)*lt,ly=y0+(y1-y0)*lt-sag*4.0*lt*(1.0-lt);
      var sc=1.0-0.13*k;
      var gc=[glow[0]*sc,glow[1]*sc,glow[2]*sc];
      vbar(lx,ly-0.0044*sc,ly,[0.11,0.14,0.19],seed+30.0+k*7.0,2.0);
      lampBlock(lx,ly-0.0098*sc,gc,glowSeed+k*13.0);
    }
  }
  function farShore(){
/* the far side of the bay : a hairline of shore, a scatter of small
   lamps and three masts with a beacon.  it sits in the gap between the
   left towers, so the eye finally gets an edge to hold on to. */
    var y=0.6702,x0=0.118,x1=0.232;
    hbar(x0,x1,y,[0.075,0.090,0.120],77.0,2.0);
    var n=13,hw=1.15/W,hh=1.15/H;
    for(var i=0;i<n;i++){
      var t=(i+0.5)/n;
      var x=x0+(x1-x0)*t+(i%2?0.0022:-0.0018);
      var warm=(i===8);
      var col=warm?[1.00,1.04,1.16]:[0.26,0.54,0.98];
      var sc=(i%3===0)?0.62:0.42;
      q([x-hw,y-hh],[x+hw,y-hh],[x+hw,y+hh],[x-hw,y+hh],
        [col[0]*sc,col[1]*sc,col[2]*sc],90.0+i,4,0);
    }
    var masts=[0.132,0.168,0.212];
    for(var m=0;m<masts.length;m++){
      var mx=masts[m],mh=0.020+0.006*((m*7)%3);
      vbar(mx,y,y+mh,[0.085,0.100,0.130],120.0+m*5.0,2.0);
      var bh=1.25/H,bw=1.25/W;
      q([mx-bw,y+mh-bh],[mx+bw,y+mh-bh],[mx+bw,y+mh+bh],[mx-bw,y+mh+bh],
        [0.95,0.24,0.20],150.0+m*3.0,5,0);
    }
  }
  function section(l,r,bottom,top,sideW,drop,front,side,roof,seed,kind){
    var fr=r,sr=r+sideW,k=kind||0;
    q([fr,bottom],[sr,bottom],[sr,top-drop],[fr,top],side,seed,k,1);
    q([l,bottom],[fr,bottom],[fr,top],[l,top],front,seed,k,0);
    q([l,top],[sr,top],[sr,top+0.0035],[l,top+0.0035],roof,seed+4.0,2,2);
    return {sr:sr,top:top};
  }
  wire(0.060,0.858,0.245,0.804,0.022,31.0,[0.20,0.58,1.00],51.0);
  wire(0.070,0.887,-0.060,0.836,0.022,35.0,[0.14,0.42,0.66],55.0);
  wire(0.846,0.814,0.951,0.803,0.016,39.0,[0.56,0.58,0.66],59.0);
  wire(0.900,0.842,1.055,0.880,0.024,43.0,[0.16,0.46,0.70],63.0);
  wire(0.080,0.900,0.860,0.853,0.045,47.0,[0.58,0.60,0.68],67.0);
  farShore();
  for(var i=0;i<specs.length;i++){
    var s=specs[i],r=skylineHash(s.seed);
    var l=s.cx-s.hw,fr=s.cx+s.hw,top=HORIZON+s.h;
    var front=[0.196+0.030*r,0.176+0.029*r,0.460+0.065*r];
    var side=[0.046+0.013*r,0.037+0.011*r,0.054+0.014*r];
    var roof=[0.086+0.018*r,0.075+0.015*r,0.090+0.017*r];
    var pink=[1.06,1.11,1.26],cyan=[1.06,1.11,1.26],violet=[1.00,1.00,1.00];
    var cpink=[0.18,0.60,1.00],ccyan=[0.30,0.74,1.00],cviolet=[0.44,0.84,1.00];
    var waist=HORIZON+s.h*s.waist;
    var lmk=s.landmark?0.25:0;
    section(l,fr,HORIZON,waist,s.side,s.drop,front,side,roof,s.seed,lmk);
    var upperW=s.hw*s.upper;
    var ul=s.cx-upperW,ufr=s.cx+upperW;
    var inset=upperW*(i===0||i===2?0.15:0.07);
    var ult=ul+inset,ufrt=ufr-inset,usrt=ufr+s.side*0.70-inset*0.72;
    q([ufr,waist],[ufr+s.side*0.70,waist],[usrt,top-s.drop*0.72],[ufrt,top],
      [side[0]*1.08,side[1]*1.06,side[2]*1.10],s.seed+1.0,lmk,1);
    q([ul,waist],[ufr,waist],[ufrt,top],[ult,top],
      [front[0]*1.10,front[1]*1.10,front[2]*1.10],s.seed+1.0,lmk,0);
    q([ult,top],[usrt,top],[usrt,top+0.0035],[ult,top+0.0035],roof,s.seed+1.5,2,2);
    hbar(ul,ufr,waist,[0.20,0.16,0.24],s.seed+2.0,2.0);
    var crownW=upperW*(0.38+0.08*r),crownH=0.009+0.008*r;
    section(s.cx-crownW,s.cx+crownW,top,top+crownH,upperW*0.15,0.002,
      [0.050,0.050,0.082],[0.078,0.048,0.090],[0.115,0.080,0.130],s.seed+3.0,lmk);
    var coolSide=s.cx<0.52;
    var accent=coolSide?(i%2?ccyan:cpink):(i%2?cyan:pink);
    vbar(ul,waist+0.004,top,accent,s.seed+20.0,1.0);
    if(i===0||i===2){
      var adW=s.hw*0.68,adH=0.036+0.010*r;
      var adX=s.cx+s.hw*0.08,adY=HORIZON+s.h*(0.46+0.05*r);
      q([adX,adY],[adX+adW,adY],[adX+adW,adY+adH],[adX,adY+adH],
        [accent[0]*0.10+0.025,accent[1]*0.10+0.018,accent[2]*0.10+0.040],s.seed+8.0,2,3);
      hbar(adX,adX+adW,adY,accent,s.seed+9.0,1.0);
      hbar(adX,adX+adW,adY+adH,accent,s.seed+10.0,1.0);
      hbar(adX+adW*0.14,adX+adW*0.72,adY+adH*0.52,
        [accent[0]*0.72,accent[1]*0.72,accent[2]*0.72],s.seed+10.5,1.0);
    }
    /* Every landmark wears an aerial, and every aerial carries a red light
       at the top that is plainly on a timer of its own. */
    var beaconCol=[1.00,0.298,0.640];
    var mastX=s.cx+s.hw*0.12,mastH=(i===0||i===2)?(0.026+0.018*r):(0.015+0.011*r);
    vbar(mastX,top+crownH,top+crownH+mastH,[0.34,0.34,0.46],s.seed+25.0,2.0);
    q([mastX-px*1.6,top+crownH+mastH-py*1.6],
      [mastX+px*1.6,top+crownH+mastH-py*1.6],
      [mastX+px*1.6,top+crownH+mastH+py*1.6],
      [mastX-px*1.6,top+crownH+mastH+py*1.6],beaconCol,s.seed+26.0,5.0,0.0);
    for(var kk=1;kk<3;kk++){
      var ly2=top+crownH+mastH*(1.0-kk*0.30),lw2=px*1.1;
      q([mastX-lw2,ly2],[mastX+lw2,ly2],[mastX+lw2,ly2+py*2.4],[mastX-lw2,ly2+py*2.4],
        [1.00,0.264,0.580],s.seed+27.0+kk,5.0,0.0);
    }
    if(s.landmark){
      /* the cold landmark wears a lit gallery around its shoulder */
      var shY=waist,shT=waist+0.0030,shX=fr+s.side;
      var nL=13,spw=(shX-l)/nL;
      for(var gi=0;gi<nL;gi++){
        var lx=l+spw*(gi+0.5),lw2=0.0013;
        q([lx-lw2,shY],[lx+lw2,shY],[lx+lw2,shT],[lx-lw2,shT],
          [0.12,0.52,1.00],s.seed+46.0+gi,1.0,0.8);
      }
      q([l,shY-0.0038],[shX,shY-0.0038],[shX,shY-0.0008],[l,shY-0.0008],
        [0.07,0.19,0.44],s.seed+47.0,1.0,0.8);
      /* and a column of blinking obstruction lights climbs the mast */
      var mBase=top+crownH;
      for(var kk=0;kk<4;kk++){
        var ly=mBase+mastH*0.88-kk*(mastH*0.10);
        var lw=0.0021*(1.0-kk*0.09);
        q([mastX-lw,ly],[mastX+lw,ly],[mastX+lw,ly+lw*1.7],[mastX-lw,ly+lw*1.7],
          [0.62,0.92,1.00],s.seed+45.0+kk,5.0,0.0);
      }
    }
  }
  BUILD_COUNT=data.length/10;
  gl.bindBuffer(gl.ARRAY_BUFFER,skylineBuf);
  gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.STATIC_DRAW);
}

var ERO_SIZE=384;
var texInk,texInkBlur,texScene,texBloomA,texBloomB,sceneFbo,bloomFboA,bloomFboB,BLOOMW=2,BLOOMH=2;
var eroTex=[],eroFbo=[],eroCur=0;
var inkCv=document.getElementById('ink'),inkCx=inkCv.getContext('2d');
/* The writing, spread out.  The pool of light the tube throws on the sand is
   read from this, because a blur is the only honest way to say how far the
   light reaches : a ring of samples can only count what is in the ring, and
   a straight stroke makes that count jump at fixed distances from the
   stroke, which drew a second word beside the first. */
var inkBlurCv=document.createElement('canvas'),inkBlurCx=inkBlurCv.getContext('2d');
var inkSmallCv=document.createElement('canvas'),inkSmallCx=inkSmallCv.getContext('2d');
function renderInkBlur(){
  var w=inkCv.width,h=inkCv.height;
  if(!w||!h) return;
  if(inkBlurCv.width!==w||inkBlurCv.height!==h){ inkBlurCv.width=w; inkBlurCv.height=h; }
  inkBlurCx.clearRect(0,0,w,h);
  inkBlurCx.imageSmoothingEnabled=true;
  if(typeof inkBlurCx.filter==='string'){
    inkBlurCx.filter='blur(4px)';
    inkBlurCx.drawImage(inkCv,0,0,w,h);
    inkBlurCx.filter='none';
  }else{
    /* no canvas filter : a small copy blown back up is a blur as well */
    var sw=Math.max(8,Math.round(w/7)),sh=Math.max(4,Math.round(h/7));
    if(inkSmallCv.width!==sw||inkSmallCv.height!==sh){ inkSmallCv.width=sw; inkSmallCv.height=sh; }
    inkSmallCx.clearRect(0,0,sw,sh);
    inkSmallCx.imageSmoothingEnabled=true;
    inkSmallCx.drawImage(inkCv,0,0,sw,sh);
    inkBlurCx.drawImage(inkSmallCv,0,0,w,h);
  }
}
function uploadInk(){
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
  uploadCanvas(texInk,inkCv);
  renderInkBlur();
  uploadCanvas(texInkBlur,inkBlurCv);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);
}
var IBOX={x:0,y:0,w:0,h:0},SS=1;

function initGL(){
  progScene=program(VS_SRC,SCENE_SRC);
  progEro=program(VS_SRC,ERO_SRC);
  progPost=program(VS_SRC,POST_SRC);
  progBright=program(VS_SRC,BRIGHT_SRC);
  progBlur=program(VS_SRC,BLUR_SRC);
  progBuild=program(BUILD_VS_SRC,BUILD_FS_SRC);
  U=uniforms(progScene,['uRes','uTime','uTide','uWave','uCharge','uFlash','uWet',
    'uShore','uMax','uHorizon','uSun','uSunR','uBox','uInk','uInkBlur','uEro','uMouse','uMouseOn','uMark',
    'uDawn','uLit','uSunUp','uWaveXScale']);
  UE=uniforms(progEro,['uEro','uTime','uTide','uWave','uShore','uMax','uBox','uWaveXScale']);
  UP=uniforms(progPost,['uTex','uBloom','uRes','uTime','uBloomK','uHorizon','uShore']);
  UB=uniforms(progBright,['uTex','uThresh']);
  UBLUR=uniforms(progBlur,['uTex','uDir']);
  BU=uniforms(progBuild,['uTime','uSun','uLit']);
  BA={pos:gl.getAttribLocation(progBuild,'aPos'),local:gl.getAttribLocation(progBuild,'aLocal'),
      color:gl.getAttribLocation(progBuild,'aColor'),style:gl.getAttribLocation(progBuild,'aStyle')};
  skylineBuf=gl.createBuffer();
  makeQuad();

  texInk=newTex(2,2);
  texInkBlur=newTex(2,2);
  for(var i=0;i<2;i++){ eroTex[i]=newTex(ERO_SIZE,ERO_SIZE); eroFbo[i]=newFBO(eroTex[i]); }
  clearEro();
  /* the first guess at the quality rung, before the first layout */
  QSTEP=Math.max(2,detectStartStep());
}

/* ==================================================================
   3. LAYOUT
   ================================================================== */
var W=0,H=0,DPR=1;
/* The picture is one very heavy procedural shader. Its cost is, almost
   exactly, the number of pixels it is asked to fill and nothing else.
   So the quality is a ladder, and the ladder is climbed by measurement
   rather than by guesswork : a machine that can afford the top rung
   stays there, a machine that cannot walks down until it can. */
var QUALITY=[
  {s:1.35,cap:2000000},
  {s:1.15,cap:2000000},
  {s:1.00,cap:2000000},
  {s:0.85,cap:1400000},
  {s:0.70,cap:1000000},
  {s:0.55,cap:700000},
  {s:0.42,cap:420000},
  {s:0.33,cap:260000}
];
var QSTEP=0;
var RENDER_SCALE=QUALITY[0].s,RENDER_CAP=1.5,MAX_PIX=QUALITY[0].cap;
var ADAPTIVE_REDUCED=false,PERF_FRAMES=0,PERF_MS=0,PERF_WIN=0,PERF_WARMUP=0;
var PERF_HOLD=0;   /* seconds the ladder is not allowed to move */
/* The frames that follow a re-layout are the re-allocating ones, and they
   must not be read as "this machine is slow". The window has to be the same
   number in the three places that use it : setting it above the counter's
   own limit quietly does nothing at all, and then every window drag walks
   the ladder down a rung for no reason - exactly what it must not do. */
var PERF_WARMUP_NEED=12;
var HORIZON=0.665, SHORE=0.462, MAXY=0.100;   // GL space, y up
/* MAXY is where the sea may reach.  It is not a free number : the staff is
   48%..90% of the frame, and the mark on the staff is the water line, so the
   highest water has to land exactly on the bottom of the staff (90% of the
   frame, which is also the top of the data band).  0.100 does that. */
var SUN=[0.665,0.730], SUN_R=0.076;
/* The sun does not stand still.  It walks west along the datum, a couple
   of degrees a minute, which is all it takes for the bearing on the datum
   line to be a reading instead of a constant. */
var SUN_X0=0.665, SUN_DRIFT=0.018, SUN_DRIFT_W=0.030;
/* the opening : the sun climbs out of the sea, then the city lights up */
var INTRO_DUR=2.5, INTRO_T=0, INTRO_ON=1, INTRO_HOLD=0;
var SUN_Y_END=0.730, SUN_Y_START=0.596;
var DAWN_P=1, LIT_P=1;
var SUN_UP=1;

/* The HUD is pinned to the world, not to the window : the datum line, the
   acquisition reticle and the inscription frame all track the geometry,
   so the overlay reads as a projected instrument and not as a title card. */
var _uiHz=null,_uiRet=null,_uiAz=null,_uiReady=false,_uiS={};
/* Grains of rim noise are thrown onto the dial once, at random angles, each
   with its own clock and its own phase, so the edge of the ring is never
   evenly bright. */
function buildReticleGrain(){
  var nz=document.querySelector('#ui .ui-reticle .nz');
  if(!nz||nz.childNodes.length) return;
  var frag=document.createDocumentFragment(),i,a,r,sz,s;
  for(i=0;i<26;i++){
    a=(i/26)*Math.PI*2+(Math.random()-0.5)*0.20;
    r=50+(Math.random()-0.5)*2.6;
    s=document.createElement('u');
    s.style.left=(50+Math.cos(a)*r).toFixed(2)+'%';
    s.style.top =(50+Math.sin(a)*r).toFixed(2)+'%';
    sz=(0.8+Math.random()*1.6).toFixed(2);
    s.style.width=sz+'px';
    s.style.height=sz+'px';
    s.style.setProperty('--t',(6.5+Math.random()*11.0).toFixed(2)+'s');
    s.style.setProperty('--d',(-Math.random()*7).toFixed(2)+'s');
    s.style.background=Math.random()<0.26?'rgba(214,226,250,.92)':'rgba(198,214,244,.85)';
    frag.appendChild(s);
  }
  nz.appendChild(frag);
}
function placeHUD(){
  var ui=document.getElementById('ui');
  if(!ui||W<=0||H<=0) return;
  if(!_uiReady){
    _uiHz=ui.querySelector('.ui-horizon');
    _uiRet=ui.querySelector('.ui-reticle');
    _uiAz=ui.querySelector('.ui-hz-sun');
    _uiReady=true;
    buildReticleGrain();
  }
  var hz=((1-HORIZON)*100).toFixed(3)+'%';
  var lx=(SUN[0]*100).toFixed(3)+'%';
  var ty=((1-SUN[1])*100).toFixed(3)+'%';
  var rr=Math.round(SUN_R*H*2.30)+'px';
  if(_uiHz&&_uiS.hz!==hz){ _uiHz.style.top=hz; _uiS.hz=hz; }
  if(_uiRet){
    if(_uiS.lx!==lx){ _uiRet.style.left=lx; _uiS.lx=lx; }
    if(_uiS.ty!==ty){ _uiRet.style.top=ty; _uiS.ty=ty; }
    if(_uiS.rr!==rr){ _uiRet.style.setProperty('--rr',rr); _uiS.rr=rr; }
  }
  if(_uiAz){
    if(_uiS.al!==lx){ _uiAz.style.left=lx; _uiS.al=lx; }
    var az='AZ '+String(Math.round(SUN[0]*360)).padStart(3,'0');
    if(_uiS.az!==az){ _uiAz.setAttribute('data-az',az); _uiS.az=az; }
  }
}

/* Where the quality ladder should start. This is only a first guess :
   the ladder itself is driven by measurement, and it is free to climb
   back up if the guess turned out to be pessimistic. Mobile is left at
   the top on purpose, because a phone is slow per pixel but has very
   few pixels to fill, and a phone does not need the help. */
function detectStartStep(){
  try{
    var ext=gl.getExtension('WEBGL_debug_renderer_info');
    var r=((ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER))||'').toLowerCase();
    if(/llvmpipe|swiftshader|softwarerasterizer|microsoft basic/.test(r)) return 7;
    /* a separate card has no business starting low */
    if(/rtx|radeon rx|geforce|quadro|apple m[1-9]/.test(r)) return 0;
    /* a recent integrated chip : slow for every pixel, but it has the whole
       pipeline and it does not need the help */
    if(/iris xe|iris plus|arc graphics|uhd graphics 7[0-9]{2}|radeon\(tm\) graphics/.test(r)) return 2;
    /* the usual office machine : start it low and let the ladder climb if
       it can prove the headroom */
    if(/intel|uhd graphics|hd graphics|radeon hd|radeon\(tm\)/.test(r)) return 4;
  }catch(e){}
  return 0;
}
function applyQuality(){
  layout();
  /* the frames that follow a re-layout are the re-allocating ones :
     they must not be mistaken for the machine being slow */
  PERF_WARMUP=0; PERF_FRAMES=0; PERF_MS=0; PERF_WIN=0;
}
function layout(){
  var rc=document.getElementById('stage').getBoundingClientRect();
  W=Math.max(320,Math.round(rc.width));
  H=Math.max(320,Math.round(rc.height));
  var nativeDpr=Math.min(window.devicePixelRatio||1,2);
  var q=QUALITY[QSTEP];
  RENDER_SCALE=q.s; MAX_PIX=q.cap;
  DPR=Math.min(RENDER_CAP,Math.max(RENDER_SCALE,nativeDpr));
  /* once the ladder has stepped down it owns the scale outright :
     a weak machine must not be pulled back up by its own pixel ratio */
  if(QSTEP>0) DPR=Math.min(DPR,q.s);
  SUN_R=W/H<0.72?0.066:0.076;
  /* the supersample factor gives the edges their antialiasing; the pixel
     cap is the real budget, and it is the thing that saves a slow machine */
  if(W*H*DPR*DPR>MAX_PIX) DPR=Math.max(0.5,Math.sqrt(MAX_PIX/(W*H)));
  glc.width=Math.round(W*DPR); glc.height=Math.round(H*DPR);
  gl.viewport(0,0,glc.width,glc.height);
  refreshGlRect();

  /* a human-scale inscription zone, held inside the near beach */
  var portrait=W<700;
  /* The field of writing has no sides.  A field with edges cuts the writing
     off with a straight line, and that line reads as a frame drawn on the
     sand - a box the eye keeps seeing instead of a beach.  So the field runs
     the full width of the frame and starts at the tide line : the wave is
     the only edge it is allowed to have, and the sea keeps that one honest
     by washing the writing away as it comes up. */
  IBOX.w=W;
  IBOX.x=0;
  /* The wave is not a ruled line : it keeps a long swell, so the sand's edge
     breathes up and down.  The field of writing starts at the lowest point
     that edge ever reaches, or a stroke written at the top would sometimes
     stand in the water. */
  IBOX.y=H*(1.0-SHORE)+H*0.0135;
  /* The readout band stands at the foot of the frame, so the field of
     writing has to stop above it : a stroke the player cannot see is a
     stroke the sea takes without them knowing. */
  IBOX.h=H*(portrait?0.940:0.930)-IBOX.y;

  SS=portrait?1.15:1.35;
  /* Changing the canvas size erases it, so the inscription is copied across
     before the new size is set. A resize must never destroy the words. */
  var keepInk=null;
  if(strokes.length&&inkCv.width>1&&inkCv.height>1){
    keepInk=document.createElement('canvas');
    keepInk.width=inkCv.width; keepInk.height=inkCv.height;
    keepInk.getContext('2d').drawImage(inkCv,0,0);
  }
  inkCv.width=Math.round(IBOX.w*SS); inkCv.height=Math.round(IBOX.h*SS);
  if(keepInk){
    inkCx.clearRect(0,0,inkCv.width,inkCv.height);
    inkCx.drawImage(keepInk,0,0,inkCv.width,inkCv.height);
  }
  /* The matcher reads the writing at a fixed scale.  The field of writing is
     now as wide as the frame, so the mask has to grow with it : a mask that
     stayed the same size would read the same hand a third thinner, and a
     thin hand is a hand the matcher does not know. */
  MASK_W=Math.max(MASK_MIN,Math.min(MASK_MAX,Math.round(inkCv.width*MASK_SCALE)));

  /* A re-layout throws the old targets away, so they have to be released.
     Otherwise every resize - a phone turning, a keyboard opening, a URL bar
     collapsing - leaks three textures and two framebuffers, and the context
     is eventually lost on the machine that can least afford it. */
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  if(texScene)  gl.deleteTexture(texScene);
  if(texBloomA) gl.deleteTexture(texBloomA);
  if(texBloomB) gl.deleteTexture(texBloomB);
  if(bloomFboA) gl.deleteFramebuffer(bloomFboA);
  if(bloomFboB) gl.deleteFramebuffer(bloomFboB);

  texScene=FLOAT_RT?newTexF(glc.width,glc.height):newTex(glc.width,glc.height);
  if(!sceneFbo) sceneFbo=gl.createFramebuffer();
  gl.bindFramebuffer(gl.FRAMEBUFFER,sceneFbo);
  gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,texScene,0);

  var bw=Math.max(2,Math.round(glc.width/4)), bh=Math.max(2,Math.round(glc.height/4));
  BLOOMW=bw; BLOOMH=bh;
  texBloomA=FLOAT_RT?newTexF(bw,bh):newTex(bw,bh);
  texBloomB=FLOAT_RT?newTexF(bw,bh):newTex(bw,bh);
  texBloomB=newTex(bw,bh);
  bloomFboA=newFBO(texBloomA);
  bloomFboB=newFBO(texBloomB);

  gl.bindFramebuffer(gl.FRAMEBUFFER,null);

  uploadInk();
  inkDirty=false;
  buildSkyline();
  placeHUD();
}
function uploadCanvas(tex,cv){
  gl.bindTexture(gl.TEXTURE_2D,tex);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,cv);
}
function clearEro(){
  for(var i=0;i<2;i++){
    gl.bindFramebuffer(gl.FRAMEBUFFER,eroFbo[i]);
    gl.clearColor(0,0,0,1); gl.clear(gl.COLOR_BUFFER_BIT);
  }
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  eroCur=0;
}

/* ==================================================================
   4. WRITING IN THE SAND
   ================================================================== */
var strokes=[],cur=null,drawing=false,inkDirty=false;
var charge=0,flash=0,mouse=[-9,-9],mouseOn=0;
var idleT=0;
/* the hand, carried between events : how far the nib has travelled on this
   stroke, how fast it is moving, and how much pressure is left as it lifts */
/* inkLift is the pressure on the sand : a full hand while the pen is down,
   running out as it lifts. It must never start at zero : nibAt() multiplies
   the whole nib model by it, so a zero pressure does not draw a thin line,
   it draws a hairline and silently throws away every deliberate effect
   (the nib angle, the breathing swell, the fast-hand starvation and the
   slow landing) that the writing is supposed to be made of. */
var inkRun=0,inkSpeed=0,inkLift=1,inkPT=0,inkLx=0,inkLy=0;
function sstep(a,b,x){ var t=(x-a)/(b-a); t=t<0?0:(t>1?1:t); return t*t*(3-2*t); }

function inkPos(ev){
  var x=(ev.clientX-glRect.left)/glRect.width*W;
  var y=(ev.clientY-glRect.top)/glRect.height*H;
  return [ (x-IBOX.x)/IBOX.w, (y-IBOX.y)/IBOX.h ];
}
function inside(p){ return p[0]>=0&&p[0]<=1&&p[1]>=0&&p[1]<=1; }
function clampInkPoint(p){
  return [Math.max(0,Math.min(1,p[0])),Math.max(0,Math.min(1,p[1]))];
}
function commitInkPoint(p,forceTail){
  if(!cur){
    /* A new stroke : the nib touches down again and it must leave a mark,
       or the line would begin with a hole. */
    cur={n:1,p:p}; strokes.push(cur);
    inkStamp(p,[p[0]+0.0008,p[1]-0.0002]);
    return;
  }
  var last=cur.p;
  var dpx=Math.max(
    Math.abs(last[0]-p[0])*inkCv.width,
    Math.abs(last[1]-p[1])*inkCv.height
  );
  if(dpx>=2){
    cur.n++; cur.p=p;
    inkStamp(last,p);
  }else if(forceTail){
    /* Chinese characters commonly finish with a short dot or flick in the
       lower-right. Keep that final pressure even when pointerup moves <2px,
       and keep the point in the stroke : the mark that is painted has to be
       the mark the recognition is allowed to see. */
    cur.n++; cur.p=p;
    inkStamp(p,[p[0]+0.00035,p[1]-0.00015]);
  }
}

function inkBegin(ev){
  if(STATE!=='IDLE') return;
  /* only the primary button writes : a right click must not put a stroke
     in the sand, and touch contacts always report button 0 */
  if(ev.button>0) return;
  /* a second finger is not a second pen : it must not write, and it must
     not take the capture away from the finger that is writing */
  if(ev.isPrimary===false) return;
  var p=inkPos(ev);
  if(!inside(p)) return;
  drawing=true; cur={n:1,p:p}; strokes.push(cur); idleT=0; inkDirty=true;
  /* a fresh stroke is written by a fresh hand : full pressure, no speed */
  inkRun=0; inkSpeed=0; inkLift=1;
  inkPT=(ev.timeStamp&&ev.timeStamp>0)?ev.timeStamp:performance.now();
  inkStamp(p,[p[0]+0.0008,p[1]-0.0002]);
  if(glc.setPointerCapture&&ev.pointerId!=null) glc.setPointerCapture(ev.pointerId);
  ev.preventDefault();
}
function inkMove(ev){
  var p=inkPos(ev);
  /* The halo belongs to the picture, so it only follows the pointer while
     that pointer is actually over the picture. The move listener sits on
     the window, so without this the halo would light up and then stay lit
     at the last position the pointer ever reached. */
  var overCv=(ev.clientX>=glRect.left&&ev.clientX<=glRect.left+glRect.width&&
              ev.clientY>=glRect.top&&ev.clientY<=glRect.top+glRect.height);
  mouseOn=overCv?1:0;
  if(overCv) mouse=[(IBOX.x+p[0]*IBOX.w)/W,1-(IBOX.y+p[1]*IBOX.h)/H];
  if(ev.isPrimary===false) return;
  if(!drawing) return;
  var points=ev.getCoalescedEvents?ev.getCoalescedEvents():null;
  if(!points||!points.length) points=[ev];
  /* how fast the hand is travelling, in ink pixels per millisecond : a
     hurried stroke must come out thin, and this is the only honest measure */
  var now=(ev.timeStamp&&ev.timeStamp>0)?ev.timeStamp:performance.now();
  var dt=Math.max(4,now-inkPT); inkPT=now;
  var spd=Math.hypot(p[0]*inkCv.width-inkLx,p[1]*inkCv.height-inkLy)/dt;
  inkSpeed+=(spd-inkSpeed)*0.35;
  for(var i=0;i<points.length;i++){
    var q=inkPos(points[i]);
    if(inside(q)){ commitInkPoint(q,false); }
    else{
      /* The nib has left the sand : the stroke ends here. If the pointer
         comes back, a new stroke begins - otherwise the two halves would be
         joined by a straight chord ruled across everything in between. */
      cur=null;
    }
  }
  inkDirty=true;
}
function inkEnd(ev){
  if(!drawing) return;
  /* a second finger lifting must not end the stroke the first finger is
     writing */
  if(ev&&ev.isPrimary===false) return;
  /* Keep the pointer-up endpoint. If a fast gesture leaves the active box,
     clamp that endpoint to its edge so a lower-right flick is never omitted. */
  var end=null;
  if(ev&&ev.type!=='pointercancel'&&ev.clientX!=null){
    end=clampInkPoint(inkPos(ev));
  }else if(cur&&cur.n){
    end=cur.p.slice();
  }
  if(end&&cur){
    commitInkPoint(end,true);
    /* the pen lifts : the last few millimetres run out of pressure, which is
       the mark a hand leaves that no equal-width segment can ever make */
    var ex=end[0]*inkCv.width,ey=end[1]*inkCv.height;
    var tx=ex-inkLx,ty=ey-inkLy;
    var tl=Math.max(0.001,Math.hypot(tx,ty));
    tx/=tl; ty/=tl;
    var run=0;
    var lift=[[0.0018,0.66],[0.0026,0.42],[0.0030,0.24]];
    for(var i=0;i<lift.length;i++){
      inkLift=lift[i][1];
      var e1=run+lift[i][0];
      inkStamp([(ex+tx*run)/inkCv.width,(ey+ty*run)/inkCv.height],
               [(ex+tx*e1 )/inkCv.width,(ey+ty*e1 )/inkCv.height]);
      run=e1;
    }
    inkLift=0;   /* the pen is off the paper */
  }
  drawing=false; cur=null; inkDirty=true; idleT=0;
}
function inkStamp(a,b){
  var g=inkCx,w=inkCv.width,h=inkCv.height;
  var ax=a[0]*w,ay=a[1]*h,bx=b[0]*w,by=b[1]*h;
  /* the pen is off the sand : nothing is drawn, not even the hairline a
     zero pressure would otherwise leave behind */
  if(inkLift<=0){ inkLx=bx; inkLy=by; return; }
  var dx=bx-ax,dy=by-ay,len=Math.max(0.001,Math.hypot(dx,dy));
  var ux=dx/len,uy=dy/len,nx=-uy,ny=ux;
  inkRun+=len;
  var drift=Math.sin((ax-bx)*0.018+(ay+by)*0.011);
  var span=Math.max(8,h*0.090);
/* --- THE PEN, sampled ALONG the segment ------------------------
   A hand does not draw a constant line. Four things make a stroke read
   as written rather than plotted :
     the nib is held at an angle, so a down-stroke lays down a fat
       line and a cross-stroke only grazes the sand ;
     the hand breathes, and the line swells over the length of a word ;
     a hand that moves fast leaves a thin, starved line behind it ;
     the pen lands thin and only opens up once it is really touching.
   Width is decided per sample, not once per segment, so the line
   swells continuously instead of stepping from capsule to capsule.   */
  function nibAt(t){
    var arc=inkRun-len+t*len;
    var broad=0.50+0.50*Math.abs(uy);
    var swell=0.72+0.42*(0.5+0.5*Math.sin(ax*0.0130+arc*0.0094+ay*0.0207));
    var quick=1.0-0.38*sstep(0.55,3.0,inkSpeed);
    var land=0.50+0.50*Math.min(1.0,arc/span);
    return Math.max(0.46,broad*swell*quick)*land*inkLift;
  }
  var nibBase=Math.max(3.4,IBOX.h*0.0192);
  g.lineCap='round'; g.lineJoin='round';
  var STEP=3;
  for(var t=0;t<STEP;t++){
    var t0=t/STEP,t1=(t+1)/STEP;
    var x0=ax+dx*t0,y0=ay+dy*t0,x1=ax+dx*t1,y1=ay+dy*t1;
    var nm=(nibAt(t0)+nibAt(t1))*0.5;
    var pa=nm<0?0:(nm>1?1:nm);
    var wgt=nibBase*nm*SS;
    g.lineWidth=Math.max(1.0,wgt*1.02);
    g.strokeStyle='rgba(255,255,255,'+(0.11+0.08*(1.0-pa)).toFixed(3)+')';
    g.beginPath(); g.moveTo(x0,y0); g.lineTo(x1,y1); g.stroke();
    g.lineWidth=Math.max(0.9,wgt*0.62);
    g.strokeStyle='rgba(255,255,255,'+(0.44+0.15*pa).toFixed(3)+')';
    g.beginPath(); g.moveTo(x0,y0); g.lineTo(x1,y1); g.stroke();
    g.lineWidth=Math.max(0.7,wgt*0.21);
    g.strokeStyle='rgba(255,255,255,'+(0.90+0.07*pa).toFixed(3)+')';
    g.beginPath(); g.moveTo(x0,y0); g.lineTo(x1,y1); g.stroke();
  }
  var nm2=nibAt(0.5);
  for(var k=0;k<2;k++){
    var side=(k?1:-1)*nibBase*nm2*SS*(0.17+0.05*Math.abs(drift));
    var skip=(k?0.50:0.72)+0.16*Math.sin((ax+bx)*0.067+(k?1.7:0.2));
    g.lineWidth=Math.max(1,nibBase*nm2*SS*(0.045+0.025*Math.abs(drift)));
    g.strokeStyle='rgba(255,255,255,'+(0.10+0.18*skip).toFixed(3)+')';
    g.beginPath();
    g.moveTo(ax+nx*side+ux*len*0.08,ay+ny*side+uy*len*0.08);
    g.lineTo(ax+nx*side+ux*len*0.88,ay+ny*side+uy*len*0.88);
    g.stroke();
  }
  inkLx=bx; inkLy=by;
}
function clearInk(){
  strokes=[]; cur=null; drawing=false;
  inkCx.clearRect(0,0,inkCv.width,inkCv.height);
  inkDirty=true; clearEro(); charge=0;
  recog={ok:false,s:0}; lastSig=''; idleT=0;
  inkLift=1;          /* the next hand starts with a full press */
  inkRun=0; inkSpeed=0;
  T=0;                /* clearing during a tide abandons it cleanly */
  STATE='IDLE';
}

/* ==================================================================
   5. GLYPH RECOGNITION  (the tide only answers to two characters)
   ================================================================== */
var GLYPH_FONT='"Microsoft YaHei","PingFang SC","Hiragino Sans GB","Noto Sans SC",sans-serif';
/* the twelve characters as a bitmap, embedded : recognition must not depend
   on a font being installed on the machine that opens the file */
var TPL_SHEET="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAwAAAADACAYAAACzgQSnAAAQAElEQVR4AezdCdy32Vww8HO0UFSKatJilF6kZEuRNFNoXir0ylqoLEWTfZqKaSaMrE1JSapRFCFjDFG8ZpS8yTJIpcSgTetUoqSZ9/n+Z84z5z73Oec613+5l8f/+Tznvq7r7Mvv/PZz/lcKIVw6Gk499dRLP/KRj1w69e9DH/rQpXe5y12G69X+d3/3d1/6b//2b1NVryX9Oc95zqy+veY1r2m2+6d/+qeXfsZnfEa1vl65ZoUbSviv//qvS3/iJ36i2k/zXwuvfvWrL73kkksme/Txj3/80p/92Z/t1v0VX/EVl97rXve69Kyzzrr0V3/1Vxfh5S9/+aVvf/vbF+Ev//IvF+sPBv7zP/9zss1lM7z1rW9trlc+B//7f//vSz/4wQ9ONnPJJZdceu6553bHntfbe/+ar/maS9/3vvd127T/TjnllLW01+uLtKc97WmXfuxjH+v255JLLrn0hS984ez+fNM3fdOlf/VXf9Wtu7ZP7bXnPe95l4K5XuH//u//vvTss8+e3S/jFkbX/6Mf/eilT3jCE4basb7wnKCMffCCF7zg0re85S2LPfB3f/d3iz1gjXtjWzZNO8Y2N7zrXe9qNtnDf712nvrUp15qjVoVf/jDH770B3/wB4fmNbVzxzve8VJzm3DM7/3e7+2YV3Wedtpps+pUN7wJf7b6Cs/LNyf05lQ7U3WO7J+pOub0V1361QrS59RX5rXXW3WneHnKcnv1re3Uj9pT+ty+mLNaXSkOvM7dA3P7MJXfuFJ/ak/02p6bqqeWPlU3+gDOa2X3Ms74jLM2fnHWsdUfafLsd9B/4yj7SQA4Ejf2/yd/8ifDkQGFI4PpFvi8z/u88KM/+qPhCLHu5jsWEi+55JLw7//+78fCUHaN4eEPf3j4kz/5k13xZcQnfdInhXvf+97h+7//+8uko9/3uMc9wq/8yq+Ehz70oeEIIC7Ct37rt4Yb3ehGi/ClX/qlC3gBM1e+8pWPllv3y7Wvfe1w0kknTVb727/92+GXfumXwhFhpJs3xhhud7vbhdNPP72bbyTxy7/8y8Nnf/Znd7OCtSNMVzfPeGI/5y/8wi+EP/uzP+tmijGG29/+9uEBD3hAN9+6Eo3/B37gB8LrXve6Lh765E/+5AVMHhEClmp6dP2vcpWrhPvc5z7hiMBQbecI8xiOMI+Lvr7pTW8KR5j+RYAf7YO73/3u4aY3veliD3z+53/+Yg982qd9WrWuVSPVf4SgrlrNjvLL4j94pbe3zMH1r3/9RVtHGPsFvjjrrLMWc3eEsQ9HFAfhiMAUjhC2cESQWMzveeedt0hPOObWt771jnmFVz7zMz9zUef2z3pn4D/+4z/WW+ExXtsRZUD4si/7su4o/+Ef/iH84R/+YTfPNnE7A6vMwCwBQENnnnlmuOiii7x2w01ucpMAYXczbRMP9Awg0kc0++Hiiy+e7OfVr371cERbEY5o+ifz7mcG/fzGb/zGoS6cfvrp4Xd/93cXzEWvACbw+77v+5pMYK9snoYRvOpVr5pH7Xo/ohUJRywnu+I3EfHnf/7n4Td+4zcmhSBzet/73nfBvG6iH2WdhIDv+I7vCK997Wu7a7OqEGD9X//613fb0Lcv/MIvDI94xCP2bPzaXCZ8zud8Trj5zW++TNG1l0FD/vVf/7VZ75WudKXwkIc8ZDH3U4y9dW5WlCXIB1azqLW8/uM//uNa6tnzStbYIGa1Vl0S3gi7vTAimMnTq2Mk7f/8n/9zIPbp137t14bP/dzPrU3Z0bgjVvHwR3/0R0e/ty/bGVj3DMwWAP7f//t/Cy1LT3ujk7Qyn/7pnx6+6Iu+yOc2HNIZeNaznhV+67d+K/zP//zP5Aiuc53rhHve856T+fYzA8bilre85XAXRgVexAlSH664kpEFAJNSSVpEsbxdeOGFi/e9+kMA/OM//uPJ5ggvGLbJjJdnwDSbs8s/dz0+9rGPLTS8uxIujyAE0PS+853vvDym/jCfX/d1Xxe+4Ru+oZ5hIvZJT3pSIHRNZAvXuMY1wo1vfOOpbPuaTqtunfaiExQBz3jGM8Lzn//8gGaUGnvCGxjYi77kbRx//PH551reP/zhDzfrgTuNvQxTdJFltCyTf//Mz/xMINA1Gz6S0Krjx3/8x4+k7s3/Jz/5yQt+IVm+Ws/v/M7vnOyQPK3yo/E//dM/HWjfJxvbcAYKUvxRq5mPf/zjYa9w/f3ud7/mGt3whjdsdXER/ymf8imBMqacf9ZjePd//a//tVAEl+m+p+o2Pw960IOafVNHLaS2Fx3c/mnOgITZAoBCT3va08If/MEfeN0VAC6t2Z3vfOcFMzhCPHdV8gkQgcF53OMeF2KMawuI6iam7mEPe1h429ve1qz6Ix/5SHjhC1+4QKyPfexjm/kOSgImADEZ6Q/m5dnPfnb46Ec/Ws1OEEbkv+VbvmUlNyCuT5BltZHLI81zbx0uz7bWB0b7JS95SXP8GqPJfelLXxrOPfdcn2sL3Et6lbFQEQJaLlEEJhq0+x0hcNxGenW10v7v//2/4XnPe16wX8s86ueG8iM/8iMLN55l2yjr3eQ3IXOT9ae6uTfc7W53C/e6170CwRgzygUJnBPKUr69fk652K27P9e73vUWbkjGn4ee8KsPtMN5/vId80Sgk7cVWnV88Rd/cavINn6NM3DCCScs4L+s0h4gAMQYy6Sj33AL60ku9K3rvRQAucq1rCeY+KOdqrywfuP1yvIUgXANQfeud73rwoWvzDNVt70Kh5Tlpr5T25XuHrgofAUau2qghBhR0pYTsEMAAHBTkyvdgl9wwQUL/8u8Qiar0047LTznOc8JzgHIW4b9NsFh2PQz7/f2vT8DgJPQ98///M87MppLzO83f/M3h3vc4x5D5wV2VLBPH4jvFPLJu+bsC+YOUk7xBF3MId9vME1QSGnpCdGOIu03vvGNwfmEVLb2ZL1wzmK0zl6+N7/5zYEvfa2dMu6Zz3xmeNe73rUjGrLBgJ966qkBQ+EMiO+UCZEzL+X+T9+sRTG2CaB6rnnNa1YJR6rDU9vOlpQuCISH888/P+g7QiRvHvRNH7UzFZ74xCfuMsX/y7/8S2AdIbSxEkzVsV/pYJbgqL/W50Mf+lDQ5033h9tgTWjadLtT9dMqjq77VF3b9N0zALbgxZ/6qZ/anfgJFMMCxtrwcz/3c+GUU07ZMfKTTjppEtfTrDsDUwp+6/iGM3d0aPuxbzPw67/+6wE/smq4053uFCij5g5khwAwaq5jdjnjjDMWHc8bpPXhMiG9FWyKZU1wDmXGGLsac24IpKG8X/m7SXKQOY/L3xEHk2kD5/Ej75gh2khM4Uj+w5TnBS94QTjnnHMWrkAY/1e+8pXhxBNPDBipGvN7EMZGuuaf+453vCPQUINN2gim80c+8pGzuug8y9/+7d8GDNVb3/rWQDNB8MFktiqCaEcR9ohGj8ZPvtE6e/m+6qu+KnzBF3xBq+s74gmABD3rjpm0f1hQ9AXzK31HgSMf9ri93sID8MfVrna1Iznr/z/1Uz91IaC0yufx8BZtZ14TYQl8nn322VUTsr7pY16m9W58z33ucwOm1vjtBXP7Qz/0Q/t+AYADxom5d2AQQTE2B5PBp3lwrgTMW6873OEOwdmO1lhXxX8OjcOfBGYHdFvt7Fe88Y2u+371cU/a7TRijpzpscc72apJ9sRtbnObxWUP6IJ9XM14gCNprVkN5yiJyuFQGsGxn/VZnxVYCM1LysMihuFL39vnemeA8oeCaplarT1F0Q//8A8vU3xxcch73vOelc8DLtX4EoV2CABLlD9wRZizELxWxzCD3AJS+l3ucpfwa7/2a4tbJRBSAaPrUF+Y8Q+yeOADHxhI7VxGDpMQkN9UgsFthe/93u8Nbvxh9sNI0Fq38mISZ0zf7Kw2OEGPRtOaag+zZ90w+RAsbR/G8Ku/+qsXfoo/9mM/FrizYOjyBlmsWuNI8QSea13rWgvhkx81hjillc9SW563dRDfR8ZPeLLu5vS2t73t4lxIOe70fSyO356++tWvHoz/HkesXR/84AcXwmAac3piehGQZdc5wTUYfe973xtKy0ZZ7+///u8vfMEx93AQSwyXPTiNJrbMX36vG/9xeWEZIQTYm2V7m/o2/26igb8JatpxDu1Vr3rVQpDkFkAgR+Cn5sVNSYI65gaH5l0coJ25Zfcrv7E+4QlPCIQ2CjJzCJdS7szpE5oHntCIGOPC9eu6173unCr2Ja/xU/C84Q1vCBRGDqjzI3dL3TIdMpduhosxLorDGxQerLcinEHbTzc4fTiWA74AHI+MEZ6iHOQVAn984AMfWCiMTj755AAuRupIefBH4J8iHE39ru/6rpR04J6pQ8eUAMD8SLsT42UbLw0yPS0w5Jy+PQGAhaLRs1EhL/HHH3+8x3BwrV8qA/ljGHqCCATAP7bnpjE3zRiGO3wAMyLiNKyYH2dHMPYYHMwMU6qbdhJzb/5oqo477riAwYdwv+d7vicwPdeY/AM43G2XtjMQECrnGG5xi1sshMsE1wRYhMQe6E0Tq1AvfSptU/iPEDDV9mg6S55zJiwXF1544cKah0El7CfGnqUDw/q+970v0LqqmxsFocg7qw2c4j0Pzu5wIaOtthaEBmepzjrrrDzb0Dst77d927cFlheWmGWsyEMNrTETGkSZgX5RnjmnkWggN945TRE8R62Kc+rdZN40fnvwVre61eIwv/GzXKDjI23TOLOOyovJf/CDHxwoS3yngLfgSsgt9DAIRanfx/qTUgDv4Bpyyp0YL+Md4d/RSwrwlfY6GHJuwZxRFnKbdjmE71bQDoXRquErv/IrF8rZVjut+GNKAHAfeQ8BceH4nd/5nR1zQeKr+arm9SAuOwoVH1x/aEVjvAx4JEMeifj4LoM6EXhM+7oCbXfZzmH6/uVf/uVAaLIpbEyMvdtbuDNw7ZK+Ze7XsaLbOg7KDND4u2Upt0rO6RvGYk7+Mi+meAr/lWXK79NPP33xWxgx7sR/U9ftcl9CPAn+ZZ35N429cbIuODzp1pEk7GPs5aV5Z7llnYvxin4o52ICSh75yqAu7i7cMjC/BDB5EHK4x/tIwAC4Bhn+ijEGzDQhADM5Un6/8vzFX/xFoPGvtY8GUrLU0so4tMx8xXjF3Jd5DuI3Sx6FU61vaHgtvoxzHsz5OBYQVmYwV+bxLf4xj3nM5PWf8m7D3szAu9/97l1nWbVMAHROzftUYKUlQGPC87wE6Kmb4bjZ5e6sy75z+6QMzdsfeT+mBACSHARcGzgig8jSIuXpfFZpmPI477RIyQSEMIirBRo4zKlnLX0bt52B7QxsZ+CgzgACiBEv+5fjvzIt/4b3WOZKjac8lBwEHK6CrHjcyAjzNOQxxoWWlOKEEkb+VkBYa8oUzOnTn/70xQ1l97jHPRb11eqgjaN9xaCV6Uz/SXubp9EGziGoLI+5ZjfGuLBMm6Bs9wAAEABJREFU0g6feOKJC+tOjPHo04HsvL3ynRUixivyx7jz3Rz+9V//dVlsx3erjvvf//5H86GJmNejEdkLGKjNe5bl6Cu/f7BwNKJ4MceveMUrFu62YKEMLDBFkV2f8pTl5n6/+MUv3nGtL7env//7v9/VlggCkOdIwDDy+58SGgiYMcaRKrd59mAGeITUBGDrOWoBIPxSJMB3e9DltTZxzAgAEBWNcWt2aJq4k5TpLQ0ALfQIALi5ZSRf2e72ezsD2xnYzsDUDMBbU3lWSb/ooosC95qyjlH8R0vWY3oQRQwmxp92FMNGo5/aw9SxgKTv2lP9uQYf40+TSpnD7cRtUbVyeZw6nvrUpwZ0Io93aUNNA4yZNbY8b+vd+QsMcIy7Gbsb3OAGgTtoTfho1bfX8awAtTYd0h8VgqxzrQ5xmH+/W8CnHhzUwsi5IXlqZefEgRdwo18psIKl9/xJAEpKwDy+9k6T69BvLe2gx93/iEAYYzwqnMZ4xbuLV3r9t3fMf4xXlIkxLi6IsdcJmFxj5CmDX1vv1U05W5bx/fM///PVa5l7dfXSausfYwzJpRseIBC06rD34YtW+kGLz/tzzAgAtCw9Tf373//+hfYhH7z3lgbgyle+cnB9oDy9APHFGHtZtmnbGdjOwHYGlpoB5uWlCg4Wgv9aGjCEb7Caajbaf4fn+elXM1we6XdjalbYy5MXvq3cO7n3sCJg4FxcgDmNcQz3EnIc9iNwpHo9WUAc3PaeB/j/S77kS/Ko5juhomYBSQUIH/zL0/dBe2KAuLGU/TIHIzSwLJd/cy/zOxrL3qqS17WpdwJQbfyjAhDmkA95jG1Y5IHQg/E0Nr+nE2OsMuMxTsdzjavBc6qfMMbqlb43/SQgcNslDJTBvPXaZ+Eqy/h2ULtXbm6a9WepK8slC9CU1QYPWJY9LN97LgA4oQ3hrHuCmERbSNjmc0UeYKy1W+uPA2Q9gaJWTx6nTQda87jt+yfGDGB8jJTFCcLqBQe95W0FiAmD1KtjXtqvLQTh5z//+eEtb3lLq9mV4o3fXqNddYi1DDR5U8TQgcyy3Dq/9U0fVxroMVLY2ahyKIjzKpZNMOAGHsz/1Dzz3Z9yA8JgEVZcqTiH8YeH4X53r7MalOMkTLACl/GI+ohloSxXfhu7q3KdQyjTDso3dySMYdkfMMB9SnxihryPBjDgjMYDHvCA0SL7ku+iI1awmhuc8RPeVu0UGOQG9zd/8zfdqlj70IxupolEgjILWSubm7le97rXtZI3Fq9PzjrmDThnk3+X7+CnjNvEN9xTW399dqnMsm3q/z/90z8tW3xPyu0QAJgyY5yWMmPcmUc5UtRUj2kDfvM3f7N7D/VUHbV05lV+orU0ca6F4w/pvRYQAIxWnhbjFSagPH7k3YbnW1Zqm/Ky5uKw/BJw3u+Rd2Nr/VL0SPnDnMctItbeGNxUwmTZCo9//OMXh57lbQWaS1fStepYNt6VZS972ctazS4dn8bP9OtMDre8MrgSb0oA4C9cllvnt77p49IDbRRE5DGcjeQDGY0BgrPyzsW4PP5D+EaZf21iwjElJQ6WloLDtPzy0/fIkyYUYafM4c7RKoMBqKW5iKAWPxqH+XcTCHgfLbPxfJUG0D99rSQddYOopfXiwADm38HoXr6DkMY7APNd9oUFZNQKVJZN3/YVesDdZUqgJoiXl5SkekaeLFEsTTHGZnbudj2+pFlwxQSCO57AXOgn5npqP4PLFZsdKt5SBnGDTG5AQxVlmViUWL7cWpZF73q1Fsso8Moy+OqaJXdXg0XEDgGgSBv+HL3aigbvKU95ynC9oxndNuGHblr5EbiXv/zlreSAACAUZYZltB5pw7uu0ntZ50H8hqiZDkeYSWuNsPbGwawO+Ht5DlLaKIPtasManORjYU160YtelEc1311bOKVhcq2h20SalawhYZ3jt9em/Ea5lvR8JgmQLABrGNpQFaPjv+CCC7r1EX5oszG03YxrTKSpRkxXqZKp3ZyXdSyD/zB+c5j/1Oa55547+ZsHKe/UkzYbTnN1sPnhOnTeeecF6+faz7I8/F8bv1s8XC1d5h/9hicdDmTlK8PUvqctLcvk33zqezRPH3t1YMSSdtN7i3kwB+qaE9A9Ap1fGve7OOrP+157p7meakOeWtmROH1I4y3bOf/884NzKmU82FnFCmQvuGIVL6DvLQ8F7ZozComEO9wq5YrS1vWQaEe57+985zuHZLFRZxkoXViTy/hNfOt/gnHKJtejuqDFoX+KJ+eBekK5/bhXNAC/Yq+W84BGoVVl/NS3vlP+3e9+95vKuviF/RG+ayoPGjbicVJ2aGUBwN3Hd7zjHRc+a2Xl+TcJm9TS0jTkeee+k3ppeWrlaJVInr12MVk2R1neBmshjTKvb5uYpcGG77Un70EKTMCYTOvTC5gbiIxk3Oo/4utKvoTIWvkOUjzE2xu3NGOnuaAVavUdwufzTKpv5cnjWa56RAFDiXDlZTbxPjJ+Wm2C9tT4abDAU6+ftGpT9dQQcq/OVdJGxm8tpg75EX5c47ZKX+aWnYujavX75Ur7tkybW3fCfyNuP3lbmAUH6RDOPH7uu/bf+ta3BoyQPqiXG4d6+PFqgyBgf/rBHvEC63VNsMewuOQBIyjfaID7uXLQ+GLCa6GHQ7XjSudauRTH6o5BkbcVenU4nGx9U1mKi/SeP7lpuN4zj+u9WwM0kOBjHrShrdTv1nPE2iJPq/xUvD7oS63v+kn7XktbRgBSD1j2+xJ4Ab8N0fNQkB9/BGa8C261Uh4+qQXXPua8ibGhzS0+SJ2bcP+JMQZCnr7aV5h2uMS7c5n2oEPA4EgfBHPqTEhPwQDfqkv+TQe8Su0mKHOpr3Pat+7W66C7vaUxrSQAYGAe/ehHT7oxQApufqC1SA2v62lzuR+6VR/3H5qfVrp4hLvGcEDSoyYgY8wRn3qPtfDIRz4y3OxmN+sOi4mRpryb6RAmnn766Ytr/Xpd98uttI69PCmNdmeKKEBKGOpUZvXn8jU86EEPWiD6Xg2j40fIe0wVYZxQ3mtrr9OsV07EyvYRLFbGKeGnLHcQvpnaMUFlX5bBfxieWl1l3W5XcZuHmz5ocP2WCrgo8418w70ONnI3gZ9e/epXBwyR6/nK8gQBd/5TeLi7WzoLSA3/q0OfjjvuuJAECfl7wdi5/dAq9vIdtDQ00DyW/eKmYfxlfO1beVZ+DJ95qOU5qHGsQLW+LXMOEAP8i7/4iyExgW4/8hsAtfpTHDckiqb0PffJUjB1YJsSh7Jjbt29/A5K20e03faV+aLccdYTA+9q1CnFSa1+AjmBpZa2iTg4sKwXrkhWjDKt9l2uey3PQYtbWgCAHP0SIy3H1KAgWMh+Kt8y6Uy6PTMdAjPlkmFT1EyAABlAT/UL4mPy5EYzB/Hpt427rtDTJk+NYSqdsNe67zuVpcWAxObMQSrriclCiPci8NWmZdHuVMCsuOaNRqCVdy4DOEIU+A8SnFtt7lW88d/97ncP6xr/FFJlGvajb+uGA7dHIFZz542V0xzE2PatxUBNuT7V2uXbThBs4QBMeK1cipsq36rXeFIdDtfWXEDm4L8p5Qdt5ROe8ITgMKRzLa95zWsCtwDKG4Q29WXOE95FuPkXu4M/F74phnruEGDrne9856I5e0yfFh/ZH0y/w8dZVPeV4Eoze8YZZ3Tz7Vtip2E0mvayzMLKMOoGYT7h8MMoBLOA1MYPF9krrCnl3NS+0T5ML2FUOqsxD4UY27iDl4I9qKwyywQ/PMdi1SqLNucWhlo+2nqM/DOf+czA8uyyBni/lncqzpi+/du/fdcPBE6VS+n2J5yavjf9tP789st2Ri0AmH/4P617WU/rm9WGAmTVQLk+5RJY68PSAgAtLxNPjG3A1qBNhSl0CMb3OgMhxOZqaRMtKIIz0ibmoMyH4ZnSfiBCmH+/JgmIyjpa34gLH0nmonWFr//6r281t1K8eR4R9pj9AOKyjSE22tqLQHNhfUf6ylw5xbQSNPnhjdQ3QhRoULgTjdS36TzG32OmtD86fu4EU0gVU2t9NgEHc4VkPuB8WHvElfDH13cZxgd+wTS2cADB0/y2wlT5Vr2lIMTaVLZhf6i/jM+/4T+MRa71tVcoC+B9TATGhvZRm2CfUBNjn27kbfTe0Rf1l3nucIc7BMxbGZ++4WoWm/RdcwGBo6fGn8pjAPwY2EG+7Sf1tfZ0EBKTWKaBgan9qgwNNivOMntA+f0OrJdgqewHPAQGevs/laFEdNNULgByR5vCna76dQYm1ePJ8tLia6TnwZ7CB8XY3lPgvWZNho/hbjjMXuXK8+AHPzjw1ScQGH/e1ug7Ws4Nby6+TfVT0FHMpu9NPwkbrA5lO9yUYmzPq/z2/jLMv7IsjFPuayPpIy6B2ivDUgIATc7d7na3xf3MZYXlN+LwxCc+sYxeyzctT89FxxVMNFMjjQEAxCzPiwAgZnlc+Q7hnXzyyTt+XbDMc9i/R4Q9yO85z3nOYR/qrv5z/eE7HGMbCdD8cSngS7irgkoEpm6KKPBLxkBViu9plL2+zvG7yafnSrOngxtojPBDQ9/LioCyWPTyHPQ0+K/s4yj+o8mHB5XHQHCngAv8eFdiImJs7x/llgkxxsDNB37SJiGMwMMFyB5rMVC0k6ViqDZ+ferRF+kCBoDiw8FG34cxGD+ta9l31pkpGohxNu+bUPKV/dnUN0tSTZAc2QP6hGElBIMD3wLlAUGUEOW7FdCNcu64DJn7Vpk8fkrIwNc4G6OdvJx3Vmbpo20pMxIw0294wxuCvTGSv8xDICvjlv3Gg7olh6DUqoMAWxOAKREoLFrlKJmdeZyr+W/Vt9fxswUAyJ6EOCLZkTr9+mJtY61joO7+t1FadQH4cmO18vI3IwWX6Q6BQQJlfPrme5qIX4o7lp6sFHe60526wh6CSpvm5o1jaewjbk/GC7kym3qfCoiCQ/M9ogAOaWvWu2+merY73fjdPjC11+eM34Ex2qHdrR28GLjOYUYWiVbv5gp/rXr2Ox4Dg5Er+zHF/PHzzfEfQluzJpT1rvM7xhho0hzs5fLErN7D2RdffPHiRqC8D63x0wDm+cp3uM8PHREUy7TD9E3bag5qfR6xANTKHaY41uuaGxg3OJcW9MZi3xB8y5vvMNUE0x4TLG2UR8n7gEYk+gD2CW8uocjzpHeMLSY4fedPdVDe5XHreGfB8KNmzkHgkQgZc+rlnssNqce0j9TH9ZCbOoWAs6BvetObAhxRlnVmxxyW8SwgPeuP/Y/PLcsdlu9ZAgCGgJajx3SngQPsTWoFMFJcXmJsa5ZsEm4EqU+9J40rqbXMY/P3GBbmu7LMsfJNg8ekSQrujckGf/KTn9zLcujSwA1Yn2KAMBPPfe5zA0Q6MkjuJFN+xQixW4dG6ttUHuP3a6tT4+c7Tvs9On4a4ZZmdlNjWaZe/ST8TuG6OcLPMh8I89oAABAASURBVP3YqzIXXXRRwMiU7Vn/HjONucjLYGbe/OY351FLvWMYEOQWU7NUpZcX4upQngtr4X/aP+cLLi+660EDWNNWcgckPB+YcJ/7hLwvtNWY/nxAtOD5d3onBPX2rLUyDyl//kSDuTPCD71AkM7L1d7l6dXRS9MHfanVK07ZmhuYcTur17NaglGwqp48EIyd9cI3OWdSmyOaZwJkXs47xtOzFVz5mNbv3ve+d0h95Hbz7Gc/O0jjAaFv2uhZk81Nq51l480bxQmh6CY3uUlgIccTjtZHeOKG5MrQVYRrdCwp2+AxAgF6TTA788wzj3aHsrimuCAAErCM52jmY+hlWAAAxAALQZgaP6kIUGOgpvIum+5w7pRm0rWFzMMjbdBk1TYCAAIEI3UcS3msN9etKVcVSBkDCNkdS+MHNyPaBy5mbnzA1Au9OSC0MtcmhNTKy+rERQFhXWcg4GLqW+3m8cYPcedxtXdM4+gBOcj3Ote5Tq2aAxVnz/PLn7q9wtgRdsyDsR2oQczsDEUGpqIs5mBZTwhSrizj7EoNl5b5at+0sKxf7jlHa/ymACamlneZOPhK/8qyDsHWmDiw0GPG7M8aY4cBw3Qd1IA+g9t8Hmgya2PBXAp53vzdPmjd2uVwK6sfQaoXMIh5nbV3eXp19NL0QV9q9aY4TGF6z58sID1ew5zVhIdUh98Z4K3AbZrCAMxIwyc5P4j59J2H3nzn+fJ368kK78a2W9ziFkeFAgezpeV58/eW4JfnGXlHX8CQA/54RWNTTtuUidxkKLfEjQZzjw9hoRmhxyP1xniZxdAc5flr50AJDfAQgSTPe9jeW/0dEgBOOOGE4GozE9GqKI+nFeKHmeK4kKxr8VKdNjNmpia1pTwkUBKxvqe41pOUrN9lOlPWsouPoAL+gxJGJXDaTzcZjKy331hAtG3sfM3LeTxM3/zeIWvwM9VvFgCH/97ylrcEWj8MQ6sMxDwlJLTK7mX8nPETxCFoViDXxPb66Zq4UWGhV8+m0xxmdKtGjG3rYuoD6yDiBPa5DKX4w/akAIGvyn4vg/8wvTTqZV2tb/gD0/DABz4wEDbc7PbSl750YVWDv/nYYrJa5efEY8Bq7noYdni6rAsD0HMB6DG/ZV0H/ZsVCBNX9hNj/YmgBMO8Ws9y/A4Br0MDDKZdU+vWKnwL4bk8/Jva7lkc5OGy7DkVwLSrWXv50O7auHtlUhqeAn+FmSYk0Zbf7na3C4961KN2nYtkeetZYVKd5TPGGNAOygBnLGKcxsupDjS8tXbgPeXzJAgRyrznAY3Lv/N347GWedxhep8UADD/rlfzQxrLDAxRPPvsswMf8VVMObW2aZ79Mi0mrJYujraV24V++G4FUnhNAwTxAexWuV68a7Agz9FAS/CQhzwk9IKrRvm0jdaZ8tEo5CavVr8x/wiuk+etPHk8zYpNyUzssCjmMU8/bO/gZPSMi7HxEWdOx7iwODk0LL4MBGA+yuCxTNv893gLc8ev5hhjINg85SlPCfaR+RNfBhYFDGUZv1ffI8h6zvit5cMe9rAFcUKwabjsn70azzrbwQDXfIGXwX+YDoqBGjHVZxp92lbnBbgv2DuYBpY06XlQF59dN6twN8vT5r4rj2aosywrrqbFNf4eA1DWU/umGFj1mr91lOeaxa2t1kdxLSUYIain2FD2WAiEYDiiHAulBfpZxi/7/aQnPWnxezrWgstcWY+5nsKTrb1V1jXyfVHD/W+krPkCm/DHVP6HP/zhgUv1VL5WOldkOPb+979/aDH1ZVnCW8+Cl+fHyBtPHucdbvesBetAgVFLE4fnyl3v9uudciVZZPQrha4AsCrzz42EGxAEbwM9/vGPD8yvI5rl1MGp57Oe9axAQCGJtvJq3zWWU8Q5mYCYiWkDaKUILy0Bg9QMabTanRt/4xvfOGCmnZ1oBT51NsHcukfymx+HmaZcH/K6CCPJQkJQco+wdc/zjLzbSLTItBW9II+8vTpJ8r06pNFGlAyPfid47dWfp0EOMV6mkcAQGr8DTHke7xhLrj3eD2pgpnWNof2yTB9jjMGP0XAf8oNwroJM9SBqtDgxXjZXKb72tJddGRljXPzCeIxjT1bBWn0pjsbNdZTpu3xaIwLs6PhjjCHBvrrsHwoJ76MBrgGLYLIWpMnTq28E3su67aOyTgyyOO3Bfw4O0lq29hutfAs3vuIVrwjmW30YfhpL+JQS6Pjjjw/2gjvGuXXIMxXQDjeqoB/gYyp/mW5MNP8EgDItfRNK0nt6YjTs8fRdPs2N8ZXx+bebiihU9i3c6EZB2/A6RU3et/w9HYRkBbD+1ss+ZA3lIpXnPRbfkwDEfc3NXi9+8YsDptUtf9a5NWaKw7nzY37trVqd3Anhy1paiqsJqylt7tM+Zf3jmoSZhSvwGRht/M/c+mr5CTssezHGWvKsOH3trcdIZTXe7T3vec/i1qIc/rmCcpcbqbOWh4soi+gqwZ6lIGkFVo6p+rmGgbmyj00BADPEj2tZzT+zaelGgliq94ILLgiYjbIzy35j2pjSAHCrDkj4lFNOaSUv4h14ZcoifSdT1utf//pgLIsMlT+rAmJeJQ2YH1PJ48p3TDat8xSCKMtNfWNeEGPIJ8blN6kzA9aj7J85RUxb/cBMaN81kb0gj7ytesTzIe7VIe2Wt7xlwKTIL4BLP1a3qnDKZ5oLCX9/9QoEAlfW9sYv334G4+fKY/1W7UeMMbiXGDxzjWL5MP7RusG4WxtKGOr1S//zOa/lRdhamirlwa31q5UdiYsxBjc8+eGwkfzyEELlB5O1YK9PMRcj8F7WzR1N+3ngmpDjP3eEs9y2GFy4DzHO60jvNJv2E4EYA00Th4C5LKBGiFK53pOrlfnlRuHebcqXHs5Xl3TCDiaOcCuuFSiA4BaBwEJYdJ1py79dPZhF/fB+2APrHX9x+y/RPzjBYdLe2JZhgHv17VcaWGftgXfwPXDQWWedtfgBRK5+e9UvAjJtd689+FU/e3lG084///yA2aedp/yAK1jd7LHW3h+tWz68Ba+GqTHJOxXgQkpfTPpUXukUUqx43ssAf+Vx1p8XQw7/LLwtHKcsi0FLIeEH5OA6OKgW7BvzrJ5ecKuZfK3AXbVXHk/TgpWqAIA5h/hMXq/iVlqMMbj+icahloe7AOGCprDVsVq5XtwZZ5wRegdRMV+IPGakVQ/mQGil70U8SQ1R6bXF7QYw9PLMSeOegrGmJYpxeeY/tYmJOP3009Pn4gmxEAAXHwfsD0sXP0ZayXV0zb3xNJ3qAt8sNqswlurZZLAvMGsQxTrbiTEGbj/c1jCTcwgAGEc0RvvD3Y6pvpWfBti91LX0dY6fssB6I3q1tubGYcpoq3rlMAy99NE0uE/I86MBLQKa56u9w8lu3OBeU0tfNg6ex7DQjLEq0exj1jHt2hK8s2DwRQaDmJmp9lgHEG2WPAILvMgdkgvMVNljJb1cf+Ni5eVK6n0k4B1qDE8vLrcWttqQp1fHaBrm0fnBVjtlvIsLejAAt2D0ynLLfuOPeu2p156nVPG+arBfML/rHEPqE/pHiz6CD0uGPNWRnhht+3hK4ObyY/8q11I8goHynJJ5oCRSLg89umjtpwTkvK69fDf3eGw/8udZa3uXAEAbZcFGtXW1Si3ATW9604X5vpYujkTNV/i8884LEK24VQKiQKioHeRN9WIQaGPT98izt/lrQKROWiq3uPCNmxto5qY2gvmlZZ5bt/zu1qXl108B84vwkfpjXJ35VycCSojMha2DyvyDPW5XND76vo7AJGfszp7QqubzvY7659XRz435td/XJfyUrTEvYwIJAITwMr31DT9wPYDEWnlSvDU0jl793DtqV6sqt+7xszZynUj9W/XZcrNJ9fbGnfIs+2wRUPURTC666CKv+xYwrAQuMIDoY1QF72Du6U9/+uIw8UgH0ZDSjUw98G2rPJcJZv5W+rEQD5/H2KYNtKCYp2NhrLUxgCc4vZYmzj4gqHtfR3Dt7JQAQKHmzOA62ttkHRjPE088scsLah8jTSjjHUKQE5cHcXgXikVWiR6PBGdRZqId8EKN96BknRIkUvtoUXovn/oF/sv4/f528Q7rOx4b/kJLubeW/dohAPCzFPZKWxljDEwu7mQG9GXn5n5j5JizWuVijMFBTUS/laeMn9r8ZX7f5o+JDhAuE7Spnl5gol2mboyujZHqpm1QV/pe19P1XW6FSW31pGhttoQpaZsMxs/0uWwbLUTE7cH4WWqmkPmyba+jHORwjWtcYx1V7arD3HAFYVZfRsCwhwhQuyouIgibPfjSDwegakR6E+PHkPNXJwAWXV3qE3HsFTS/vfRV0pzdqhFQdbaIH3dM5u2DHDAmxjAVwNVB3r9T/Q9ryEDb3JsDLhIEsTU0dSCrAAOtPaDDaEiNuZK2TBjRlscYg99BmnJ7XKb9dZUxJxjPnvCU2nI7F2GdVcOZzhLnEc4pPeXHuGPgvdcCgRXtdU7iVre6VS1LoCh25qOaWEQStoqoo59wXKk0OJq4Dy9gldWSJwnrbYyXCe7cmhxALnnfhQCASWNaefSjHx28r9pvi8MkS1IbqUun+d8ixiP5e3m4sqTDbLV8mHNCQC2tFtcjgBafT1qt3GGJc+aA7+uy/WVVaK0zzXdi4DDEy7axyXJuxqClXrYNfsk0QLXyEDnYrqX14uzFGONCaxLj+NMGn6uJs3780Hv96aUxo7bGD8Hy18QML7O3MR0sdrQ4rT5w2fDbCj0iY30xpbU6Vhk/X3Ea4Fq94N3BtxhjLXlW3JRpnsbLXptV6WDmHvwi0jXrhP6gIwc5IIgjU0CRgaFo5cVktNKOlXg0s8cA12DgWBm7cYABz1YASzStLhFo5RmNxwCPCvSUKn4vY7TuZfKxgC1Tzk1HLl4xN1Pl0R8COdolsOhh4DH6yoIv6YQA34RN+by3AnjljhljHf+6OKGmECrrQ196rqvcksoy+/XN7ZjWH81M8573BS53LhdfkuKv5IP/Fz9dBDclrPKkGUL4mf5bzEFZPyKHoJTxc78JAG4gaZWDzFtSYa1MTztMc3oYzHC1caU4m8khufQ992muuVfUyoEn2llIbcqqsV/CFCTw3ve+t9b9oTi3RbipZSjzAcxk/AmxLtM9h+QdlErIOtXBLOqWC4zwzW9+8xQ9+0n76CaOVkFtX+ta12olB7joTW96U2CJqGUy/mXXn2XB+Fs4jlsdH/Vau3PiWMeMo1UGTsNst9JXiedn3ypvjWnSWunHQjwtGmaiNZaW8qOVvxZPiCa8rxrcQEX5VmtjlTgWYlatVh2baLPV1l7H07Ab/1S7tMSUmKWGdapcmU45SeAq42vfmLxV21Mvd8XnP//5obx5EDPp5h555gSXP8DL+jdVzv7hmkljned1Jo0bLVdqvwaMn0zpmP9VFK9wqT2X6us9CUA95VVP2dyrVxqcbc71pxbwxATaVzJpAAAQAElEQVQQeXtBH9ExB/anhFXnE613qu9Kfqraoc0Y65JSyjj3aWEd2vEjSVOMvYE6yKXM3HZq+bkBtYiy/Db0iMbMAvUIIABfl+SvX/sVLrzwwkCbuUz7JGCMHmagLA+oEU+MEGm8TM+/lbex87i9emcFWXb8xug+8wTjviGFZetb75jHaoMMV+lvQtaYYePXKsHI/edTh3PlxeBipr2XIcYYECHa9DLNeSUIMsY27qI9KolLWY/xt9ov85bfLAgtARActCwEZT29bwda7Y9WHsK1g5qt9GXj3dpDgGuVJ+D30lvlDlM8rVmvvzSJvfSRNGs7dY3fSLrbitL+G2l3NM/UHGBAKBJH69vvfHiD0bMr17ve9YL9NdJn81RqWEfK5XncTodm5nG9dwydm5t6eabS4H7MNnfVPDjHOdUXwl+u/MELzFEmv+1tbwuEhVofWdcpa90kVqavwrNwWUPzyzpr31zT8Xm1NHH7xbNoOwVnTikqYmzTwZSXIM9qxD1L3JW4QDDB+BgJfizB5I/klYffltBqA/PvRwpyIFJulUCrjfC36qC5d8tIKz3FOyA7JY2vS/JPbe7Hkxbfpli2bS4rJULF+DDbQaB+aZAw1avfRrJuvTybSqMBJ8gsWz/hFRNozCR6WtEpxLlsW5sot+r66xNkTXtlze09Wh17B/MO6chTCxhvZ4B6rhRMsKwAOZPBLQjh6AmWmCE3wbAK1tpOcfxPa/AvzlqmfLWnNvQ/hx/vhA7XVbqBoVZuTpy9hWlplcGIu6yglb5sPEVJb9+6VOG0004L+bos29ZBLOcQ8ZRGzbz35mhfx7WGxinK7ONeVW77c5D+sMyDPUvo6o0ppZVn5lJ867nKXGDktdequxZPAFeuljYa53wUJcNo/jwf5Q18n+L8bkAPl6d8nng/+APt9z0nvPa1rw3L3r6jXVcnj7TnfEfvFjQKdGMeqesg5CHs+ZFGB6r150puMOCr62MqYOKZGedOvMO5D33oQ4OJz9sAOCSRlnk+zzvnnUtTz6/dgpKYpuq0GUeQ2jok/6m+bDId82ptyzZGGCBlMNDmHFIFYH5A5qSTTgo0tDY3BqEnRauDYOm5H4EGGCyWbTOrjSBGY2Tt4ovuykHwUNZ1kL9r649IUg6MjD8fmzVHBP0qsHu0p+aCfz4GHfwQBvK68neamMRk2JOPe9zjAvegPE/5rm4/bFfGl9+19cfEux2rBhdleUIPRt+cESbAwT3vec9d+K4sN/oNvnoCABegFqNKOwT/Tq1DrS8j+9Zap3Wp1XGY49AICp7eGJLQ28tzmNMcxJ8SAGKMgSusH86yN1lFXKc4JygzNU/yjNQp31Rdo+n2QO8WmLKeGGNw6w2cUKZNfbu5ZQreanU4DOza9VraSBzF27JuwOZa+dQOdx08XY2fSHk84VX5luX9lOPaCeeqbzTwMsGfoO0jZeCAXj6KPj9oaCy9fPuRlrdpntAmh7LtVV4y0heHgJlhesRXRgvKxy33xRI/GvyyHPMSQqkMbSmfpWXrU0cv9BgXBHPkoA0T2OjmzwkhhsJJ7J7Z1nxwHyBBk0Z7eafSuFsAaFrHqbyQdCmI2cDMx/l8cmlxn7ONmse33lkBaH0dhOI6QCOc8tpENkr6rj1pOWvxexHnFH8pgCA0LFcEmpE+mD/7AxyM5D9Ieaw/K03eJybSM888cynXMPCFcWBWttfyest3QgZk7rxQTxER42U3eLkGDnFFZGNsmzzhM/UySZdtlt/l+lvzF77whWGkrLow6IQFlyjQ+r/61a8WvbbAOkoYb1XIwuKyglo6DbXbiPjzWk8MWi1fLQ4sT+3bGJdneGptHqQ4zN+U4sLhc0R1FQYA08dyuGrwo3FT+23u/HIxcah7qlyMlwkB9qbff+D2OSeggVNtyDNSp3y9uuAGjGAvT0qzB9L76HMZmHBw87a3ve3i4ofRdlI+8HPf+953pQtc8BDmJdU58qSUSIxknh9Phxa2eAfKFTf9yJeXm/uOPqNTc8pRdml7pAwLYO8MaKoDjjioruAYf2MmIKJNJU1bCACIMF+uNKDyuSrzn+oDLHe9610Dk9MznvGM4FchU9q6ny2CqJ0YY7BJQ+cfQgn5dbLsSIrxCkKI+XWff+tQl7tu+fq5xpM1gv8u38FW/l78K1/5ykD757ASAsC1CUPTKsNtgrCwo/NHPmjxEwLA/PthLNL8kaSh/8ojhASBvIB5dC96Hle+E4JaB4nLvJv6JrSlur1DLoTUFDf1ZCpnMYqxzZRO1bHe9Hm1GXMqQUhnsZsz/lQ2PR3+nkKecA74VcaegZxYkXzXAubGj4MxeU/tXxqtOfgljR9jwCJR8zut9SnFYXzsmfS9rqcbMVg6nCfo1cldp5YON5g3TzBt748IAvAJ83etzjLOWtj7iQk29wToWkCM4JeyjvRt/t/znveEvOxUGTCDgcnLTL3TXKY2W88b3/jGYUoAUnZVBsAhdsqxVQPLk77o07rC6BxoDxxgZB0C9b1fgWtar214h1DdyyPN5RXLWM6UtQ5zmEI/bDdlaVFvK2Du3JzTSp+Kpx3uKRlq5e0xlt5aGuYeTiz3OuYfj0BAqJWbE4fnwGe5cRKjO1WWggkOVG4qr3TCJhcr71OBEGZM6ziUPdXWSLr5QNPQD3ysOa+VWwgAfIJKDWjKLJ5my4KmuFWeJt/Bvcc+9rGrVNMtaxEQvG6miUQuLL0DwLXiEGBOCMs8/Jb5XplLTHGMlzGLNE1cq8r8I9+YoQSkfIExog5fsoDQ4Kt7pB4E1GalzXSF17rWZ2QeIQVEf6Sfm8qjfRoNmwbzS3s8py2udLTYxtIrZz/13NN6ZTeZRgAzfsw/wkVYX7Y9+xszYj/06mABY7FKeWj3xaXv2pPAPMWUgWMaebimVkctzvorx4oGadby7GWcsxO09txrbn3rW4cpv1pMpL1f9pH2loVAfIwxOLDpal4MMNcg8bXg8N0cHHqVq1wlgBsWQEQZ8awFuIWFpdamOEyIHwTKy3Iro4SSXgv2HKEmLzP1TktdqyvFmUs4On1PPQ8aAxCmOjyQPncOVIkGEf6TMChur0PvXNCcvnCtSbR1TrmUdxQmzJW2UrllnvYfSx/cu0x5dK+lsS/rw1xyv2F1wC+U6ekbD+ESGPtTnCdGdJ34leIIX4VHpSio4RZ0jdsP4XQOXYd358ASYZEid5TnMo/OmJnDWiCoUm6Yu9GgTvNgjilxpqwdCwGAVqhGLLkFkCoR09EO7Hc+i/CoRz1qoRVfpS98O23guXXYiIkQ5mVthFe96lWBma9kYGKMgbaBdJqXmXrH/APSGC8TJFL+GONi/PzSuXeMaGSsPzccPwQ3RRxTOyNP1yBO3aJAuwkBjdS3qTzGzxVuGeY/9YkGwI1AtJgpLn/SqLN8sXjk8QfhnQBIEYCIrML8GwsrE4bUeytgts8777wdv9IKCcI15qlVbioeAoTsIeKpvHk6ZtthbrcN6Ueetpfv8Bf3Qe50XBAx7wQpe9PYWn3BqHC1K9PhsBLfyONgdY/Bt29719+powzasgcoYMq09O1SAEJc+i6fCB5GoYxf5ptGnWAH/5nXOXUY/5QmuaxPG+BulAEoyx+0b7SKwDi3X2jgySefHJZVas1tr8xvz5Rx+bd9BM7yuNo7IZj1rJYmDn+E2fLeClMwYa+w1puzVh3iWeddvuLpuxa0Rbhnda+l9+J4DaDDtTzmC6NKcYWf0AbYQDNr+fM4+ABNJFywkGJM8/R1vaubppsVhZeJOXW5jBuJCPKlW/JUu5hn1q+pfGU6lzFKm5E1wOCjN/ijWkjeHGUbtW88B/6F8sU8JMafG1OvLwsBQIU0byQl7wKGjFmKr7rvgxBuf/vbB4Sali73lwSQpGgHCY2DFBzjTqY4779N1CMyJszmn0IkeZ35e40QYnh65wmkERz0Pa+r945ZQ/h7eaypOevlkUaDDXDmuE0oNxVcMVtjQPJyECnEksft9Tu3D5qEORqCWh9pOGtEwQblUoXJrpXb7zjj51dPo7JKXyC029zmNpO+rOYIw1225UpRgoE9WqaNfPMJnStIq5f7ES3SfjH/cI5fwoTEaapyhuD4448P3Gp6OAv+qDGeLSYWUW8JWvqCAV4G/2FCekwwAklLbM5rwe+BEHZqaXPjMG/OeqFj7373uwPrK8vKSD3wP+vJSN48j/GNMgB5uYP4Tiudw+GcPoIhigAWoTnl1pHXmvfqAWMY3l4eyjX0sJcHnFKY9axTyoMJ+LXcn77tFXtGvl5woQHLvmcrX4xXuCG38vTirRfGWXC7DTdlTDRlAWUAXIKeo3Fz8CSmn0L1MY95TK/5taTpF8baGFg4WaOcSZtbOV5zZF3KemNcbQ3K+ka+uWK5cIPCiLIjlcH8+30HShBzURvPUQEAA0ZKU5gbgIVflRlS1zoDjZVBOnVNu5MC868fNwC0JMCpNmlguTy08qm3pk1L+THzU35nJtvmtsmVc+A5vyddXBmU8WtuZXztm1kcw1pLS3GYqFe84hWBy1GK28sn7QZJutemPmJ6enkOUxqtiLXOiQJmy7kXiHBvxrI/rYB1PvoIRq8HtElcfyDrWj77GQ6qpfXi4C8ChDXo5TtoaZhNewABrp1dwtybj9Z8GQ+mGqPhPQ8tEzYNKDfBPG96Z40kdKTvuU/9qDHB8BXXnF5961QGGIN50R5mntYSPiR8gjH4VloZ4Cx0Jsa2Eqksk75j3HsGILW9zifcvcoP+OkLRRhrMkWV770IFGhT+GekH3gJ/W/lTXSLMpK1joKnlTfGGJz3y/cEXIku2yutcike/aCgk9/5Qd8prXyyFvbckMv8+bc24GXBPuHio00/lDjHnTiv0zu8hR4SCn2PBO5nrMH89v3oF3icKkeBSgGk7/Y64ZUiQ/xU2TKd63ILd5Z5y++0Bi7BKNM28Y13p8Aq62a9MwZ8M4scuugSGNfbp7xHBQBmf9Il3y4mFN8p00F5krjX0RfA6OBzq6473OEOgcTbSufHDbGRrFp5xNMgEEy82wQ0fIDZdy3EGAPtKWtGLT3F2UiEFIub4mpPTANCV0vbizjXTfnNhV5bhCnuJ708hy0NUXA3MCZL3yElrkVgwPexGgivzJZT42PK7l3PCVE5TwE2pupK6SxdmH8EK8UdhCfGs6dJd86IzzszdYx1hpNSg4AAb/XGhKnAvOZ51J9/p3fz1cKnU8yP8wPWKNVVPmOsM8HOhfRcwzA2m8YFiLN5YjX+rd/6rbLri2/9nDrAvsjY+KONZZmwRpXzoteQe+oH/KwVa2HPKqUbmA+0coSBk3/V4NpbbfbqoSjopRMi0OEY6/tRWdazZM2lEfdbKuJ7gZuHw/rgD56que/WyhOKMeDSMHotVx3pAsYX07uK9YWwzloGd1FKcCeGg/CFI4wt4fqUU04JhArXxnMzn1KAsbrYkxQTFKzcd+xDjCx4OueWYAAAEABJREFUNLYyaIfXAoWuQ8d4Lvsv5cPHsaim75EnWJ0SfnnIgIFWfdaA4NsTIltlxZt72nyCkO9lAj4xKUCU9+1HwLjIUoJQ8h8VADAnCDjJqYfcVbRfwUaYwxS0+onIAMxa+sji2+ysIwCONrNWjzg+c3k7yjgE00OaAIf5Sj/UUQtcFWgUamkpTr+e/exnh/1aS8AGkU65/xA6bfbU72Pl6UArYZr5kUvKfq3DXs0n1x/3WOfIt9Y24ou5h29q6eKYijFoNN++RwJ3D0wXQjWSf6/yIJ69PYDAxthmNPTTXsLYI6K+WwGzz3Sd0pmAMR3pO386bGvv5XHeEX4WiRjbfcII8LntMSLggFnaQUD1YnrcUmadfNcCnDXirlgrW4ubEr5a/cf8TcGeucME19oVB4+PMmFwQ4xx4TYX4/JPdKO3r/RrJIABDAjYbOXXDgbFD+315kF5TBrhvEfT5BsJFFpwAwUYhhFcKYfxp7mGh3owJi+67NkK5tFeaqWLJzxzOfZuX2Lo4TbfZWAdcP4P82U/Ug6NMv/KsjAkPoJyCQM3NecYT4rEZYUAQrB1y8eCmeTK85KXvCQYP34xT7cerk+W5lpsghG3UgoM+4lCMM+f3uEJTD93FcIFAS7GmJIDOFQPHHg08vIXdNY5VYJVjFeUuTx58fDbPPbi4mPgDw8T7k6trA4an3vuucF1z711gH+mlLRlG+DajUysGPYL3F/mmfpO6bkFNMV5ws0UdXjIowKABI3a2N4PYqB5b22y0f4qD0hb+acWH/P+hje8YVGcX5U5qwEBCdFVgsxYi8yX/wGwU65ArgV9xCMeUb3XF8Ij0dqMl1e566E/+qV/uxL3KIL0XtuwZfMkUSasMv6wf9tHDqPTAhD8Dvt4ev2HqFi6pkzv4NId3RiHWn0YDyZuGvGpsy1l+RhjoEVHiPl6q6vMsx/fPVfC0f5gGuAE55to7lvlEBum65ROc4YIpe/8SQCoXYWIGPe09BQw8B+8RhuJQcnrTe/WmpUVsyAOfFgf763AOoq5aaXPjccE9YQvloyyTgzIlNaNoOIwP+G+LJ9/a98hSOuSxx/0d37TNK+9fjqT8qIXvShwd5yaB/Vc+9rXDrlLrLhlAh90QoAzgBhG9AOsOTek3xjNXr1cd2rrnspQWlGCYjpTXPlUB6UVHJ/S4B00V1qK88QsOtSPr3BVJyEFfMVYZ1aVyQNlY0nHnQWgDM3z1d4x3rTjcw9jo9u8IFqCVIwxWE8KhtSuMiw9lDDSavuOdh6tSGXSk3Bk76fv2lOdBKgyzdmKqRvS5lgBRtafRcMvERvvlBdI2d/WNyFGXZRjBBZMeivvaDw83uITkxv8DgFgtOL9yudwx9Ri9/qGWJHcWgwI4ERAe5ufT1oiatpyuw+J17sAGWFoaRFajB/JuIc0Y4wBA4OJVmceSLJT93Prj37l5fbyndQKEUwRPswMaXcv+7aXbTGRY0bntkmT4qDa3EDLdrWrXW1ucyvnpy2c0phpBMwjXt7zAF4QOYSA9jXGMeKY15HeER4EnKCB2JZarJRvL5586a973euu3BQk7ge93vjGN4aW1jo1grnAxPrm/0p48F4G7kTwVB5PuaDPLcIvL1P7Oeec4zWwAmDAFh/ZH3iWKZ9WlnabJhLx7uFVjJNzMrSpWVUrvfa0eHBPSwDqldMhcEyJRAiiEBLXCuAP09pKP2jxGCDa3x4DwrXR/sIA00y7cYRgODUWwjD34ql8vXTWe7DSy9NLw0MQTFt53KKCcWqli2f9wUd4zwPBhGCU4sAGfEeryzLB7XEOPqCsJFiUe8Kcgz/rkNpqPeFWwjdhyXsrXx5PkHJbVx5XvsNDmO8Ur4/wCf4nxZVPAgkLQhkPjsBTbzwsavizsqy5mFKoKkP4QFe998LI+oMfvB3c1vMCISj03IRijIG1FU71ewoUJDEuT/vKcfXwmDnnIn6oBAADpFn3nBsQJQxGzw+Nxp75qVU3xFMSKUweVxsIEPCTDJm6xbfqAbQt4qEOSMSBQExRXocNgLj3kLN+6E+v/bzOTbwTXEau0IJI+RRuog+HuU5aLMh6biBwxbg+BDI6h9w87C17rFUGw+VGMbCf8hgfdx+aD4eUpiwIqdzIU90IGSTtGjoC9Ui5deahReMCtEqdCIj9TKBHdBDaXn3wF0bEfGqfQFTLj4kt47lPMRuX8ekbbiKwpz6YWwyKPqY81hmjg9FDZFxWQGmBgKc8tSetLO1XLW0qLsYYakJLb+710+HGvG64lZtCjO09lNOAEWsuJnAVpVXev6H3FTOhO1MMsHlDv1JTNPvcYcBHiiufGEbzxbpXps35xnxh4ueUyfOirbkCL097wAMeELjQxdhef/nBv73oPQ/2Q2II7Qmad3OjPULwHKsmXErIsL/yNtK7uWQRTN+9JwXCPe95z4AnoKzp5aXJJwAq08sHD+QCgLzcwVjHvNeCPZpbDfI8BAAeHnlc+d5i4il6psqa+ykBgLXedaExttcf7KUfr9Q/PBrLTw773ilG7CX55asFlgkuWj33pVq50bge/qMAwnsdOgHA5oO8RydBPpuRydbhNkRJXBlGNj+G1aYsy9rkTNcYHMx/jbiWZWjP0iGilIZYkOyd0nZWIMWnJy1CT9MK8Fxvpj+pzF4/IRAbCTM61bbDoDlDOJV/m34wZ8CeQmAIx2Cw1kvaIe4C0jDnGH9IEkOAaRW/iaAtbi1ci5zJsM830U5ZJ2YSLuhpvcsy5bf5cRsNJtocS8d4wBPeW4F/J8J0gxvcoJoFE4vhzhNpfrkpINJ5fP5OI8nVIo9jdUq+sPpI+Ehz7BCg9eUKk5cp32n+MEkYlDJt5JtwwXqR5zUebgN5XP6ur+UcUFz0tGbKlzSgZ81FdzCBtNbKtgIrAWZu1UDTay5a7UzFn3rqqYvfqYmxzQBZKxYgdDivr+cOwV0FDHNHycss825PYF6WKYtvAL/WviyPbrnBbApWMbhuUinLp2/7jgDMhde4MVlwQUsQT+XyJxwKl/aUlcZgr00xvqneGGOwR6ydvdZSiFCaTGn/MbUsfKnu9MQDTbnywE3wcSqTnvgA/ED6rj2tDR6uTIMT4XbzVqbl37l1NI/3jk7grwgKvlvBHiVw5OmUM7wuxOkDiwQPCPu/h0/lX3dI9RlrT5BndQBDh04AcKMKAEwDbT35OLn7mWmF5Pjwhz+8lTWMbH4LC8gAW60i7TD12gAjrhvy2YTqTfV5T2bzsg6LRaMXYxs5q8fdzWXZ2jfk5CyBMusMEL35nqqTpcJGmcq3TT8cMwA+3XRkf5Y9RqQIvDT8CCSNP8ZwGc0H5tU+KduY+qbRghSZ5DEQ/NcJ2lPllk13UHFVwQax5EOe9wHx5oaYx819t/dKppS2qkcwtEFhUWr9xCOAzgU4FIgRREwpMB73uMcFay5PL9CcWpdenl4a5ooAiuniHgmvga/eeBwEzd3zEP8p9zNwV9IAjAtteCmUUQJh4EaYXm5aDuStGsDLsgwH6zIGmPWxN9fgxnjLPNYQHGB68jRuBve+970D5Vgev+w7RQIt/tzy1g69QadrZe2zEbpF8MHg1+pIcYRCmmSuxsu4dcChcCmcmuqsPeEwtwOVsFfLm+IIiBQTNO4EvhTviQ/CuMKVvlvBJQDcvsp0c8MyYK7LtPSNia+5AUm3PnCT91qI8TKXGXxTme5wNAVFGZ9/E+5rwoc8Z511VuB7770VCH+syeW6UFyw0l588cUBbHCjtB/wYlMCRast8SwEznF57wXzQbjL88CBzo3lcenduRQw5vvQCQBcDSB6BIYkloI7dvndC8y4AB1CpIWCjA22FRCuqc3PhFkjfqlOiNeCIX6jwQG9GK9g6CHfVll191x/9CPGGGjeW3Xk8erTZ+XWFWj+mdmm+qk9EihthPdtWNcM7G89kB6iku83GkNCMzcQAjnXFIxxjFfA/Wiv7UGEmgYOEhstl+eLMQZI2X30cwhnXsfIO0ucsY/kbeWxjxBrZuKUB5GlHSQIpbi5TwoBa5HKcU/AsMTYXhNKl9z0ncp6IoBM+6wBXAx806ZPMRLKEsZYLI3Ldy0guFNzidknZGIOHbpEfGNsj8ctJaktxNMcTwkr4K9GA7hjYF4wPgItNb/vdTG9qZ+behq/NWCJ6LWBOTP+1lpZ/2QNMg+EJa5gtOC9euemEULmwL++OLTbYqqtvWsm7bdeX+ALB5/BYysfNzpndTBgeJBWvlY83AmHwqWtPHk8fIgp5TKUx0+9c+Mqtfj83wnQvbLwAGa7lWfKDYhFlN87XqSsAz+ALyjj82/7nItSHucdXBI+vLdCjHUBwvrDs1Prz0KBwa/Vb/9wH7P+4IMwRWG7Co9lrvRpam1veMMbBvSGdUKwPyliW227AMLhcuM4dAKAyeUr6tcdMfsp0GAlYYBWxuBGwsjiQyDMWz3AH2nrWM6DeNCiYa6mxgl5Y2IA6lTebfrhmgHMPoaSNsS+oTXmxuJgLoF3mdGox9kfTCVES0tFywYXLFMfQu4WEYzqMuVHymAKMUAjeXt5aMzsK0xaygf/rWIF4JOetN80v3DoFLOCgapp/VKfaKH4wiLi+hpjm/lOZawDH+cpvErru+xap7byJ1cQhDLFUQAhoum79gSDPRoAHjEvBAHwuW6mt9anXXFLRGDEKM9GfpAKY/vMZz6z2woLEAadsGjPjzKy3UqLRIweJqaI3vVpzVi64QzMWa0v4B8TbZ/tqqCIwDTx8S+ij35qxx5BC49GznhhKeUyBofOKBZYmtBT4x0pR5Blic3pr/3LVanFNKZ6W9r/lG6P8G5I37Wnc0a05GWa/ljb3jj0j7KhLOubQENA8d4KpQDBVZDr3NT6o2fwbg8PwVOpXTAFD6bvZZ4sm6wWF110UejNibodsE4WRIftlRVfC5QulBTSDp0AoNPrDJAVgtirExJZxUTdq/tYSaO5ePzjHx8QwakxmW+alKl82/TDOQOYOrdOYFIxRhgse2iZ0dD0M3VD1C972cuOVuEMAS0rwWAKOR4tdPkLoYS2+PLPjTwQCswCZNtqwNgwVdxRWnnEs04iUt4FggumGSPre04gfOeCCa2uvvbqQPycTWrl4RLi8gMarylBItVh7OpEKFNc71lj3nr5e2kYIPMujwPs3AJo2ny3Avjt0QBKJ3e7Y2zW2ddWf9YVz+pB0zhVH+YUPE/BirFjtrlkTeWdarOVTstcegAk5R8GnBaW25F9ww3C3mn1BY6ytlM4hPuHNlr16CvNPesT2PY9J5hfboP20pxy8uoT64Z5mRoHbTJ8WrZDEdo7M6MdeMAceG8FTDxNeStdPJhrMfFck4xHvlZwtomnQZmub+hBGZ9/EyDgKRp68fYt4cm8+K4Fc6pfXLpq6WWcsaFXUzilLJe+4XU4Hgz78VjuOiMCbyo/9WQlTcLKJ7wAQFPjDlYMbG3iAAatFkCppUUe/iMAABAASURBVG/jrpgBDBpE0tuENhMt2XY+r5i3Y/ENMYMIabME2hOIbc5YXdPIlOkKydr+BG8QLUaSNnmkbgw5RD5FZEbqmsqDSccQwCFl3jQ25nD9r+VJZTBoDr+xBKQ4B6rtI/spxY08HXy1FinvFP5T/xTxI1CMzr92MUgERLeu+R4JCNa6iCAmBUxql++v8wvG6bsWrM0IDQCjewFXtT4uG6fP973vfQMmqDUHxk9hg3EMA//Uucl5sH4s/ixXZXCOAXPLJYQwMtVdeVgWp5hnDBmt+VR9YPrss88Oc3AdAQQPot9T9bfSjQPtnRoH159S+UHzzxICz7TqF+9H+uBO772gDwSmVh7tOC9ZS3fGCY6qpaU42nr4MH2nJ5iDq6bcBWnI0ZRUDvzDR+A8xeVPGnjnW/K43jt3HG5ZU/0o64Df7DFulLe85S2Dd3mMyZ7yvmqApylrUj2f8AKAiUAM/CxybZKZ/UY2vnq2IYQ0lw5/1eaDpoOkXkvbxl02A4htSdimv+8TmI+nTKCXtbD5v5Bxvp8wrJi4kZYhKcyzQ7v8intltEHbyAxOs9FiYtRB+w0+1e17LwJBiNk8tYX51Yd8bPALPJPy1J60ZpibZFY2v7R+73jHOybNw6k+TAnGCDOT4jz1p4X/zG9P8608iw9NPg2h716wturDKPXylWkO2WFyyvi53/qY4x/zyP8XUWzBjrWxRnPbOiz5rTEmqCUEgF9wfFjGM7ef4IpGuTV+DHrJNPfacAsWF0P7rZdPGmUZd+Z1nBcxDpeIcL+qMbOsfYQM+bSdArziXFb6rj1ZzZStpZVx3AXdllXG59/cgFje8jjv9qPyrb2IvrHeWSv5y0BQt15lfP7NSkngyePQD3ShnDf4ylqWODMvW3vnApq7GdbypDgWYIe53b4EF51//vkpafEk8OqbviwiVvjj7BchK1WxFQAunwlEMPkuXx4VEAvEzQKkuO1zegYAMI0G82qe26am+TfXefz2fecMOKSJSZkbHGw0xztrOxhfEDsXAhr4Vo8gXz6gd77znQOmHmPSylvGcwlwi4M2yptIUl7wKD1978XTuAkxCKjAR5oJOh8b/IIpbvVbP5PgnBNv7zRhLkYgWMjXCubWXe0EsVoee7LEfwgOGLRna2XyOHjS3GIy8vj83fgJqYhtHj/ybh5PO+20kM/bSLk8D4bMAfJSi6luhLcmBOwFDbCOMcYQ4wrhSFlKAmPJxzz6bl4d0Ke9zXEIuHPd5LL1jra/3/mMvyYEgRkWM/tjTh8JAZg2+65Wzhy7mhium1t3rb4UZ53gBK5Q5V7k+uicQsrr6QwIutHDPfoKLigPlJkKFD0UE7V8GHjMtNuYkh96mY8G3ThSPM24vrtIgg+/A/7lHk551S2vPqe4/Gk97DfW4zxeeyysOQ5QByvr6aefnmcdeldfwvu1AupmBYaPHbwGL2CwllecPhhzuabSRgP6R5BHb1KZrQCQZuLIExGzIDYDQHHnv7gjSZP/LR7igmAehsA1gfZhcmBLZoDUbCjzkqogmZN00/f2+Yk1AwiiQ2KQXz5y34iBWyhudrObBTeJ5Omj75AulyG+v9rCwKayzLFMqghEiturJ83ZU5/61KBvzsnU2kUsjNtc5OnGYCzmxXmKPM27/UWgYP7nK1oTBDDefgfFjSzmSLlagOsw6Jhe/UD0S4ahVi7F8adnKtfnFOepLlpkTPbItZjK1AKc4twHIVGdtTy1OHnhOgwEQlvLY164gtAsyi/PXBqgzGEOGCNwhHkzB9YRvrZvDvO4RvtuL+VCgDnAAOIJRuvI86mr5lqCicOgb/K8CFzDqpesohQv1jLvn3dwb08knInZFp8H2vzW7Td5vvyd9pvwZA+ZVzDEp53Awb0FXgFveZn0joG3Xz3tWVdhYvrhSP1N+VpPv/UAh+XpytF8O5juwH/NoiMPHJmEAK4/8GFez5x3eN+4zUEqB6a4OFFmOIfQO5+SyqSnNeWuhYbZmynesxesKauQm6ng0DzvVgDIZ+PIOwLlpgNSbI3gHslS/U+qavkl0swctIDZAkjVwawpErDRKkI+NgHz3Ig2cU3NH8hqMKK0IJBNK8zZ3PkgN1l33s4q7/xjaRXVARli/GmEESBafPGrBgSHBeHEE08MEJ/5RJBoUVate9nytKhTZn7MM6KjDXOD0aUhNBZjEt8K5s4tENe5znUW1hM3u2AyEDQ3RPR+ByWvk6uLclz4MPRgNE+feucKxP/VfpeXMoVlwN3fLIPiVgnqIAxxddBPQgqGtRakmQdEH7E1R722zTEtuLrMP9cf+KtX5lhLw5RxhzEHmF/reayNsTceMIBxJwhi1DD/c/dAXj/cpi7wJGDIMebiV6k3b6P1Dt/4rRNCCIUfRUIrr3HDM65Qd5sOnClvcpvEyPoeDdpy+QOc5PdeCP+jFgS81M1vfvMwh+nP+6Ude9d803qzNnCdhAvhjzxv+W5NuFbKp9yqPBJBw0Uz2kH3MP4EEIogbYmfEyiJCFCujGfpIUC0FM5ojjEToODL2liWEgBU3GNoATignzMwEh8gbQ1GPIQ+p85l80J6JhkyXLaOY6EcAMUIIAatAEn2xkqraD6ZOzEXvbwjaQ4iQWjgoRXWBSeQ4pRVZ25bzJt+n8KP/7QC4jAyF1fkuewN0mUibdV7zWteM9i7l+We/ksIhgx7e53rynRNV+QgFGLKISMHsTD+GLkrcqzvTRsQH4bRzSDgeU7tU+sPDsHjnDp7efWXvymhiFZOvyH8XpkyTZ/BAWUE315arzLP1Lf9ikjpz1TeWjr45ZbE2nPSSSctLB9z575Wbx4HjozPQXO/6VAL0szDHKUDnI8BpqwozeV5+3Pe7bneHvJbNXPqa+WFD+39GOuuRFe+8pUDBqRVPsWbA8wF5iHFbfqJjrRoTIqXZ9P9UL89RAjgJz4HdpQtA7iHQx2Ud9gfQ44xL/Nt6ttYWM3syZE27Hl42djtX8w4Gj5SNs8Dhhyw98zj9+qd4A73O2tgf5mH0bb12eUSLA6jZVr51MXageG/7nWvGzzBRCv/nHjXLhNQW7gFHof/e+0tJQDYFJBNKyBAcybcoAEerXRrMOJpD+Xdhr2ZAQygHwiqEdcUx6d5qjcQCM0CZDKVdyqd754fHAMPrbAuONFfDESrHfHramtq3PuRDnFAIK19Lh6MzO2b9SNgz9UqzW0n5YeEMRHpe/Q5tf7GAR5H6xvJx0pBKJrSVo/UtV95wA0GEu6A1/erH8u2C15oLAkZy9aRl5uilwh5nn/2+wYKoN/WcQNVV6tERxJNaT3lqRbeQKTxg4N1VK0e9+zTsKt3HXVuug4acPvXlZuHcQ9TnKxr/6461wS+Zaypq7Y7Un4pAWCk4m2e7QxsZ2A7A9sZ2M7Adga2M7Cdge0MbGdgMzOwSq1bAWCV2duW3c7Adga2M7Cdge0MbGdgOwPbGdjOwCGbga0AcMgWbNvd7QzsnIHt13YGtjOwnYHtDGxnYDsD2xmYNwNbAWDefG1zb2dgOwPbGdjOwHYGDsYMbHuxnYHtDGxnYMkZ2AoAS07ctth2BrYzsJ2B7QxsZ2A7A9sZ2M7Adgb2YwZWbXMrAKw6g9vy2xnYzsB2BrYzsJ2B7QxsZ2A7A9sZOEQzsBUADtFibbu6nYGdM7D92s7Adga2M7Cdge0MbGdgOwPzZ2ArAMyfs22J7QxsZ2A7A9sZ2M7Ans3Ane50p+B3N/xK64//+I8Hv2wc9qz1bUPbGdjOwLE4A1sB4Fhc1e2YtjOwnYHtDGxn4JiYga/4iq8Ij3jEI8J3fdd3hbvc5S7Bj8VdeOGFwQ80nXzyycfEGA3igQ984ELI8WupfolW3DZ8YsyAXx/2g3l//Md/HAi54P2LvuiLPjEGv+Qo11FsbQLAN33TN4Wf/dmfDX6BzUK+9KUvDc94xjMWCGsdHd3WcfBngJbqOc95TjjnnHPCWWedFb7t277t4Hd628PtDGxnYDsDB3wGrnSlnaT60z7t08LXfu3Xhp/6qZ8Kb3zjGwMG6oAPodu97/zO7ww/9mM/thByPF/5yleGv/3bvw3nnXde+NEf/dHwpV/6pd3y28TDOwOf8RmfEe585zuHb/iGbwg3vOENFzzj0572tPCXf/mX4c/+7M/Cs571rHCjG93o8A7wAPd8J1ZZsqOYf8z+Qx7ykHD7298+nHjiicGC/uAP/mB4yUteEt773vcGUv3nfd7nLdnCtthBn4Ef/uEfDs997nPD933f9wWCwEMf+tBw7rnnhn/8x38Mflb84Q9/eLDRD/o4Dk//jq2e0myCIUTg2BrZdjRmAAGnFHjta18bKIjghl/6pV8K1lyaPNtQn4EPfvCD4e1vf3v42Mc+tivDJ33SJ4Wv+7qvC2eeeeYC7+7KcEgi0IarXOUqO3p73HHHhTve8Y7hCU94Qnj5y18e7ne/++1IPxY/vv/7vz/85m/+5kJ5esIJJxyKIdLUWyNC26/8yq/MFkb//d//PfzzP/9z+J//+Z8d4/3UT/3UcL3rXS+wDP38z/98+Jqv+Zod6duP1WdgLQIAbUS5eVPXYozhOte5zgLRn3322eGmN71pSto+j6EZ+JRP+ZQQY9w1omtc4xrhG7/xGxcE6ud+7udW0uTc9773DS9+8YvDC1/4wvC93/u9B0aggKgf85jHhCc96UmB0Hus++cS5Al7//mf/xkuvfTS8PGPfzz827/920Jj8/znPz98y7d8yy446EVYVwj+J3/yJ8P5558f/uIv/iI89alPDQhLr9x+p2FcweLFF18c/vu//zt84AMfCL/927+9cNcwR/vdv4PSPpz/C7/wC4FSgLKIgoh10B625ubMvjko/e31gzvOox/96IWiY6/WGIP0tre9Lfzrv/7rFV0r3r7kS74k3PrWtw578Y+Ch5uGvUqge+YznxlOOOGElZp+85vfvNj3rUrMO+YYLLXy7GU8geVxj3tc4LLyV3/1VwsBDeOOWZW2TF8e8IAHhNNPPz2whtgPv/M7vxPe+ta3hoPu5kUw00duW95f9KIXLZS+z372s4f5PXT9Xe96V3XaYozh+te/frj5zW9eTd9GLj8DaxEAXv/614fXve51VQ1F6tonf/Inh9ve9rbhB37gBw4M45b6Nvp87GMfGz70oQ8tiD3z5O/+7u8uGNHR8uvK9/Vf//ULZpOblcC6st/SMY0eLVVrjAREZuplLQG3u93twqmnnrrQLtztbncLv/iLv7jwgcV47xUhro0NTJxzzjkBMTjllFMWmhv+uczy4g46E1sb01Qcc/xXfuVXhitf+cqLrLSQiJ74e93rXgsfTgcWfS8yTPy57nWvexQncHXw/chHPjK84Q1vWDDTE8X3LRnBO+mkk8JnfdZnBfjti7/4i4Nv5muMAcZodA56g8BUvOMd7wjvf//7Fy6W+4lDwTO3E+PTJxZecN8bJwXRp3/6pzeHeK3t4LKZAAAQAElEQVRrXSvc8573PPBmfkwoN9cnP/nJgasjyzY/fHhp0ziIcEnQbE0iYRxNaqWvK94+h3+//du/faHYIdA9+MEPDolZPe2008IycwGWfu/3fi989KMfbXZV25/5mZ/ZTN/LBPv8e77nexYuK1/4hV+4gF2MO3eVd77znQs60NsTtb7CH8aY0ijVbnKTmyxo/W/8xm8E8JfSDtIT7oO3U59ijAulL4HmV3/1VxcCTUprPa39a17zmub6/9M//dNCwdIqv1fxcDGLHGvFX//1XwdWD14Pe9W+/YbXYjG55JJLwj/8wz8s6OSP/MiPLLXv1iIA0FA8/elPXyAB2sDWZABoWoqvO2KybOU5qPGQ2ld91VcFGm0Af9wR8ySBBiNKciWxb7rv3/3d3x1e9rKXLfwiEV1uVgKfSRuIIHaPe9xj092o1g+Bk/j57VUzHInECADgZYQVGi5zf6SaxX8IB0I844wzFpsQ47lI2MM/kDWGqGRujBOMWxemawRzD7u18abAO41dzSVB4+YDHD7lKU8Zsvi85z3vCXCIsnmw5rSttEviuQfxCaYJ/chHPrJgiP/wD/8wnH322QEzLs9eBn1ACGptfu7nfm540IMetBBUwUItz0gcvHPiiScuiL/54GJJsDDuhz3sYSNVrDXPN3/zNy+Ydb668OF3fMd3LBgUAi9cyCpSNkiQsw9qa5zyXu1qVzsqBKa4g/a86lWvuqOPvvnhc39gxdgkDsLgC605ueiii8If/MEftJLXGv/hD384YD7yStF2zCqFCGveXOZXXXAKl1HvZcBXoDF/8id/Uibty/fFF19cxVkxxnDta1974bZiLuzf0Q4S8P/jP/5jV3b0BA0hfC5DO3dVuOYIfAf4q1ULT8BTI5YbjHUNxq092PijP/qjWhN7GgfnWVP8B8UFukPog/9YNDfVGfNHqUbhwnr62Z/92QuPi2te85rhVre61cLDAk2gnMCTjPZjLQKAxmxMJt5f//Vfb0px8unwda5zHa+HKvz93/99EErEBxAwonwwEYJ1DgqDSdv3ile8Irzvfe8L/OtoXq5+9avvaoY2FoPEr3a/tAXPe97zFmc99HVXBy+PIDhd/4g57/LPoYd5QFxq2h/zf7Ob3SxgilyPN1ThmjJhaH7/939/ARe1KmOM4cY3vvFic0LgtTytOBuehQmTjdGkcQVfl23uVqm9iTduri8OaLVaJCRjXLkLtPKkeJpUmoz0nT8x0uAa0jWXkB04QBQxxLe4xS0CF6IXvOAFgZvJXs7PBRdcsDD9c4PK+5zeWUb0nesCGE7xc54YKX6w6krlYozhBje4QeA+w9wO/6S0TT8xfzUibX1oROHBmgvcz/zMzyzc98Dzpvu4qfoxINa81FLDQfYrxtf4N9E+F7OS9qR2MEhvectbAsE8xW3qae9feOGFTXck+57LJw353D7QqNL01sqJhw/R4Fr6Xsex/MD91qXWNv/1r/7qrx5SgKTylGctPAjG0Dk4NeU/KE/7gvDZmgu4AR6f6i/Fzn/913/tyma/Ef4OwtqjVaWQBuYpeQhozsIui+vLgXOldW4KnHG1cwvY1a9+9TLb0e/jjz8+POpRj1pYie93v/sdje+9rE0A0IjJoQlnIv6Xf/kXUbsCYtnSmu3KPBhB68TsTst09hFtoIkaLDorGwkLIqoVsujcVBCCWnovDtNCegRAmH3+nvwKIQN+83e4wx2Cxc2ZgFZ9tK+YTdp42vZWvk3Fm39m4BZzGGMMI+MI2T/rSdNIyMmid7zaGKwhNuKOhA1/cP9hkqshrtQ0jRBNARhJcVNPbjCYPJo1zC5NitswmEkJhVPlN53uIOcTn/jE0Fpn7RuvvenpuxUgVKGWjrnh2gD5/83f/E2T8SAUgBMWg6n2au0sE4cocfOinWqVt363vOUtl/bPdjiaAFCr334A8w7SIrK1POuOgwPhpxozal8T0E466aRdzVo/xIw1AA0oM2AQeoohbo+uBmQF3av1Lfvo2y13Fx3RtnsvAxg09ikcBN/zFydIYW4oTOwnNKxV1tzGePkZq6JhCoI///M/r2qki6xr+QQD+tyqDFx+zud8Tiu5GQ9GhBp8cL1997vf3Sy71wkEIQKJfrXaxhDPEXjhQGvZqg/fBF5a6fsVby4IAawiZR+spXUbEU6N3ZyVdYj/u7/7uzJ6X74pAOy1WuPoNHxNQ19L78VR4uCdKXmd+zCXr3rVqxbnpuA+/E2vfEqLMS6sxXgwLmkpvvVcqwCgEcDA9QEhZhUQlwe+S5jbPG6VdwSB9g9x+NZv/dZAG0gLfv755y/8xVepuywL8fUYHsBelsm/aQK5MNDW2BRMXhAeZKrPblHC7N/4xjcO/Aoh0rz86DttAaBxKPWEE04YLba2fCwBP/RDPxTMVzknNnJvDstOEGYe9rCHhS/4gi8ok3Z9Y7aEXQkbjADvGBubFbNaa4qGgFa0x+CU5cCFg7VlPGbQuYe99Dss+5C+7Tt9YZ1Icfkzxhic/YAY8/jae4x15ga8MDErw81NaM0z4RcCJmzJvxcB48by1Dv/wlyL6ZvbH77V97nPfYJxtcqCLW4BCEgrzzrj4W7nvRCoWr09JoXA9Mu//MtBHWVZDCMNZx5vzmjU//RP/zQgvBhkPsWYLvO+l+uc+qUvGICaACSP8QveW4GwxnoFv9sfxx/R3NHsomHm9k1vetOus2XwmlCr01o4OF9L20SctjB0rX0onUZ4btusS/iD2tzChxQBc+vcZH6ui6wWtTYw/phizFwtvRZHyGutMTqqPgJorex+x8HTBJiyH4RcfGBtz5d5rbtxlvHmEp0t4/fjG2yzgNUEFf2prSGFBfdIc2F8yoJz8CzYv2go6wHNPW8H58rUVwsjcfApHnIq79oFgNQghtbBLsygAYpn4nF7wDLIQfk8QKJuCmFtoCnN05jfmCERCz5TLa1KXmbk3WJh3C1gmR8yxNgCkDLNN20pAuZaM1YCDCECR/OFiMuz7uCgpvbWXe9IfbQjmBcEnyUD4NOcOTwnbaQOEuzpp58ezNVUfggGQ4pBnMq77nQMgTMZLAHgoFY/JrjHyJVlaLvBWxnv+/M///MDX2yIxfd+BvuLYOsQYDl238aAePf6aL/W9gCYQTxonJVXDzcfWmTEQlwZMNusJ2X8Jr/5f1N6sAToc9lWjHHhr1nG977BE8GCy1wvH1xE+MCM9PKtMw0jjwmv1Ump4RBkLU2cM0yYXLDhOwXMMDwNN4Jr45fP4TYugwhrymsvYZjhBsJPit+LJzxDYWPey/aMCWOMDpRp+TcaYc0wNnm8dwKBMcGduVCHMaztEWXsC/3yvhcBM4bxrfVfHPpOQJvbF9ptQkC5hwhUPAqkza1zk/nNu1DDReYIUzenfWfcWJFqZew3ViO0ppa+33EY2prCypqi+yP9M4/l2iuHca7VLW2vg3W1/42r1jYFgfMAeZrD3RR3cJx4+xidgtsFzH6MUdLaAnwAF01VuDEBQMMIBQ09zY7T05hRbgwmUfoyAePvcA2NK82wTdOqB8PFRE5LyZe2lW80Xr9JupBcWYYLCMCQp0zzbdFp5r2PBpuKBsFNPz/90z8daNUxfiwFI4s72s6m8kFW97///Ren042dBtxh8ZH2MP9nnHHGwte5ld8mxAxilLhZuA2plXfT8cbqDAwBp6YJARdzkBizJ5jajRDD4urNWhubHmOrfmvAIkGDgVClfPYDJi59t56YHqFMt88I3FwLU5q2MNuetbnBKDqcmfLv1ZPrHo19TRDCuOTz0usT5vcnfuInFtcmw3WtvOrUpnmnaIHwW3nXHU84xfiU9SLg+iGUaenbPmAFxUCmuPREJB0eJyQ47zIlyMHvNbhJ9W3qaXyYkrJ+e5LwY4xlWv4tnbLg/e9/fx69450wIaRIQjIhIH2npzknZAspbi+e6GBtDuAs86MPzr9wy+vBsXwpmBdwjeFPcZ72OeUhfO/7oAR9QqOtQdkn45i7JhjFmgBgPljAuDiX7RyUb7haKPuDjlEAlvG1b/Norcs0dQhl/H59U3JY37J946ewwgvkafLj42r7Jc9XvpsLMESp6ZpU5xzxfnio3l6Ah8DKiKJ1owJAGhACzgSCaKe4/InocaPgXw9YuO9g5miDUj6EgQQMwSKQzCSIfUpvPTGeNEhf/uVf3soyK14fLXRZSJy0FM/1Jkd+EL6+p/T8CfDdfiDdwrEWYPQJN4Qn/u+EHQwWzQrhp0aA8zq900BgErwf1MBl67nPfW4g1CVN/xTzTxvkEKoDpm6VAg+J6OznOPWB5pJlKmdwIC+HxiCH0f4h+JibGHdrBsCKg0EI5mh9m85n7FwYnDthlSMIQVbgeaptGl1jLfNBZCUylQceIQSYA3tHXAqIZQ85pnybeDLREwKMHYxqA9J3bqPUCkkrAzzoTIGrcplwy3TfxkbIcOMMl0c3Q4jfy8CiC9eVc49ggUmMUa8/F1xwQeDmYq3yfLRiXEdp9ylM8rTyHbyhKYhjmbbpb4I8fF+2Y23szTK+9g1WWIzKOZCXdYFFB/H3LRB2FnPiIwvKYzDMRxa98Vdr3JoDtMk5JTgafHIFpfgD31MdM4clXBkjXAC2psrvZbr+6C+4L9vFIBIOyvje95d92ZeFmvLCXsPMmdde+f1MI/jlAmvqi3kQnHHkFSK0fOTxajHupnfm2Fyrk4sMZtoeEe+dEkTaXgU8Kngs27MfaooefXcmk2WsBivqEa9ee8U5ALTUeSo3Dd3mNrdZXKXqjIAzoRQH5lu5MqgHbrXvyrTa954IALWG8zjMucEiem4J4r6DwEOQiA2E62YbjOGoNiGvH1Keuxnz8vm7hQd8eZx3C6KvkJwbL2i5LALG74wjmmx+Y9yhbGb58wDh0fLz23fLD2SJ0c/z5O8EA+3kceU76wvGmDBVph2Eb+5PBDrMEnO3vmKQCYsYyNKtS58hknPOOSfc/e53DwRCSFH8QQo2O9cEZzlsVgwwNwYC7Zx+OvNgncsyNjiXmP1gfMq+1L6tIeTlDugeDOdl7eka4cNktBgb42ddghcQglSf/cVqkL73+gl+MT9wWYwxEG7MxRTxZqF0CQBLqSsxy37DEfAhQup2CHBV5tmrb/MNJ+tT3qZv8C/k8eW7uWAZSkJSmd77Bv/M7PYWQtnLu6k0tAS+L+s3L2hNGV/7NgfOgtXmCiOB+c/TCMgtAYClBOOgX5hlddMW2le1ttcRh9YRbsu6xMHTYJSronRnHCh4KLDgfXGtgIm0xnk6uDK34tRL8MPkEHzMkXTlzBkfeUyivHsRKHe0X7YFd8FFZXzr27ywgFH85HnMBUUefJfHH7R38w/2yn4ZE14I4w93CX4ssgafcGXNyoXngk8pCnlCUP7aC/aEd67VlG5TPFHZt2W/wbhQlocTMPFlvG900bhZznznwX5x1sl+5QZpjvBAeMc8n3eBKxFhyXsZ85CthwAAEABJREFU4AC8pPbKtNr3gRAA+ETSfpeMdYxx8SM7qywsZsA9rTQutQmYG2djQ9BlOYuPKDrAS4OVGBpuL7TCkB+NpVAiDIvpLABfMPXShDvFjdklONCC+sEJ7lTS+Y3VmENpAtcLJvT9ZBL0oxeYOgG8jZzyseiYr/LwCuTiICiLikOeB5HxT2NITwIYDTiBjkCIUKW0kSfJH9Ir86rHXGA0y7TD+g2WIfOy/whoDWGmfPYFmHD1Ge2KvU7IZiFLeQ7Dk9XEWZl73/veC4Gh7DMCiPgRfJ1zKdP3+hsMwnUlHvOdGLWpPhFy4MypfCkdwQUPMV52BSqFAfzo5rWUZ6+eCHat7/poreBvJnv5aOsIdgS8sn/2MHpSxqMvxprHY45yXJnS7Bu/DeE6XBaUREswEaxJq9DO1EbtaawlvZZP3ynx3JeuL+IE/QS/+oTZFVcL6gRHeZqyBGNza28T/J2TUA84ijEubpZDF82F63EJ3WEP/tX6i2m3rvbIaBfQPTCSz5myxgzfw3W+D2pAy8Fo2b8YYyjHBCbhulJQs854gFD8w+TjZSgK8Q1F8oJHZHl1B75+lOnr/gb7tf0vLq05HEBjT1FpvPpAGYsvAB++UzBuwnLKl+I9/XgqXMfim9LxBTVBSX71uzLU+0jYuACAuGFmacVai4Og2Ngk+JFOQ6y0YZhpG7BWBgKFbCAKV1PW8iwTp+1am5hUgOHgLe1tXrcFBvCnnnrq4jaLUvNlg0AAmHYL6IAYqwEXF3cJs5C48QIhgdyYCq9+9avnTRx9B4QOJQpHIw/gCwkVAZ/SmBEOaY+4O/ANPoBD2UiXaM3Shr+igbC4QaWlGcjzHaZ3wm9N88WcOoITaINZz7j6Oe8DnxzE8SeiAB9iUOAmLnD6z+pZI37GQeODqYJHfB+EgMGB8/K+YNxquDHPY9zcoWi8SkE/z5fe4Up4AvGnCU3xmGG0hWkdc5ji9+JpjOXYtSte4LJJMKEEctuPQ/K01nzi5UuBdaumMYTDMdLmCmzY75gAhD+VnXqCFT9UyX1gKu8y6cZZmwP91iZ/9rJefYLHhTLNN+0nOljugxhjMHZuUPJNBYo0NHMq3zrSY9ztsoLBw7ibi9E24ILafvDbAFwIR+vZq3xwGabbRSt4FvxG7rI91Q9rXK4n+LCvy7LWnqBXxuffhA/nPVmI8vhNvNuf4L+sW5x11we/z0Lp63exWKsIA/Y6qx8+MS+L/4PfwS2aD1/Q4lPk8pLA/7AeoIXiCb41AUDbeGK8VV5/731jAgDkZbD8VTGzEBl/LQxsTRCQl5Rr89Q6jKHn+4tw8IunCWaGBEhlfoyDKzAR2nUzA4hcC/FhYgAhTUzZJ4CNyMcYA9NlmY7RR+RoTmyEMt034CANQ26Ii7gy0CohmOsed9nOOr5tDv7A5rSsjw89M5h7tcHMYRhPOYZlv62zNS4RpHlyw8icDb5sH+aWo71yTsX+pPUYLW+skF+J0OwxMIDRHK1rP/PBaZh5jBpXxbIvmBvWCUQBPsS4IgyUE8zkZf78G+7A7M6Z17z8Jt65PpQmf7g7MT3Gy2JpXrTPTxfjjw5IMybxrUDRwtqBmML18DzFR5mfoMzlzAUTZdqmvu3DcuzaSmOHy3P8rO+swlwVCAbyCmiaYN58p0CT7bYrMEJx5teGaQivdKV55BpDIKR61/k0fnu0rJOGlha+3M8pH0bN+HxjGLlGchV0sJwVz4/JySN9maBP9tV+WonBB/gdtYbBgeaiZHLBE54Hg73MXKy7jFupKCkxmdxQufHY4z2epdYHDDCBAf2HC7jMuk0O/WgpNmv1lHFwyiqwU9bX+gZj1rhMt17GRgBGv6XHGAPFFDj3ey14YC560lIgAJhDblLoux8UxEfCbdJSPjiFItiFJ3BKik9PCgXwkr5HnvMwykSNFtMJZYMEHIA67ygJ1yEvUgzEnldHOsK8mtw83qSaEJoBBz6dDSAomASTlk+QckwwtC1PecpTfK49kPLKPmpEPCKkj2WfpAsEBPNBk1WrQ55eIAHycfTDUjUEa66YmWiMevVsOo2ESgAE8OU6523bCEzk+p3He+fOweIBJnx/IgUWJH695RoTgriymbeDMh80QfzwufAR2Jx38I2g0w7RzPf6SutRY25oWSA0Y1YeI8ndx75GPByShGztI4ICxhrcybvXgXnWvsPM09Y4/Kh/FBCIu/4YI0uH92UCWFiFOC7TZq9MjQBiZOFB80FzZf25MHKHIfSgD4h0r96UxvWLAADewRjlCLe4lJ4/admn4CzPv+q7MYK7sh5MMWLPHQeez9NjjOHmN795YAUmIFJqoJXGFuNuLXJedpl35yT4S4PLZcpPlTEHNRiwB2sKMPXJz6LDQkLwYcVHzwlHcF6My82DtaBUI0ioj4VhrwSAGHf32TgJXnCX9cULsepTzBFmzUUeKDS5Dpd7A16j/VdPnh9f5ewcwQB9tEdcooJBz/Ot890POhJKnU+010rl1Ehb1p5CmBABRrg2Efrc4gcmKELKfTNSrzzmnFBCOPG9yQDetFe2gY+xhvZ/qcRF51hMrPMHPvCBsmig3CA4t3CcAgIci6bEuBPu4B641hzINxpWFgAweBg1AE6b6wYLWmoEq9YJzLEDvzYqoEp5ADkG1ySmOE/51SXdt2ACapOFaUBsMAPybSJAfACgrBtAQ+ytjUEjgHnnxkJAysdT1pV/a4/G14bnRuSwF4IX404AUAbTQbgarVuZdQfmeIiY9gqRw6xhDgF/rS3WmnLN5attMPEHNdCA8+NG2KwZxEzjS3M7t88QISGvLEdYqh0GQ3RPPvnkgOFyuNJ8u3uZNsFaYMrtmbK+Vb9pXt0yRTNdwj2CTjvkIDzNeKstjP1xxx23y0+U9sy4+DNCmIihuvj7swpBmFxjEAxIE9xhMjcxzlbftUV7RbObH1qPMS4QOmGAKRjjiyGjuIDAa/XBKdbNDWDwRJnPfFjTWtn9iENwyj76Fm+8BB79Agf8WCl/fI8G2q+73vWuAQy4/titamhBrTxrBAVSLW0TccZorGXdiD84hAvKNN8xxgAfEI4oR7h4UmxJWzXAl/aJ/ahu9JFGcdV611EePsQb4BNoMSnuuHXEuJuGjbSHuXYNtt8Ucr4OvkQT3ZzHD3wv6Z81L+ESfKD3cBvcSxmG17HeLGDi8nHSGJf4Hj7AHOca3YRvaMtZ1Mwj+CFYuoIaridUajevfx3vlC2Uq+BsTn3oO//9Bz3oQcEYKYDhb+5pcESMYzCgffxdrW3rjfZyncEr1fKsM87a1OYBH0M44s4V4+5x4RFp8NFxdcztkzlA3+2nsqw5IAjOVQ7OEgAAIGIPiGmZMTt89x12BOA03GXHWt/lppHPIGwe771AgOBPSTBI+ZRDOLn+zJ2EVMfIUzu1xefzCKmVddCEsmAADHOHCQCkJcECEPzdLTDNF0TmkAxicsMb3jBAIrQ5kJ2NU7YDOEjXe6X5yNsHF3zc9I8mIpm/5IkxBuciaIf1jZVEfAoQpbGnb0/EtTbH0kYCpgEyoLFw/SqhiGvGpjQkGF1aX4wuGEAUIGYCG60P5GQdR/ouD2bSwVjvKXz84x8PLEeQB0GTds96gyfBQWP9wCiZb8gWrNCu0bBYl3UQBmttbq01AY+lIvWx9kSYIfxW2xhDLkBlWdpyzBSGyd4yp2We/BvusU9y2MvT1/luju1PxNmZAwJMrX59RugQZ+6KhGFasDIvXIAwwqE0bNwh7ec8X4xxcdAxHJB/tf1p3xLKuKxYj1pX4XjCMUWGvcGi46A8BlH5VMbc0eRSJNhXLdO+PcF1AH5RFkOI6SBwYbjEbSLkfU31wy+YsfS96ac1wCSCGUyHPW/OwCbr2abbH6nfWrN62DPWqsXE9erC8FBuYfgpkuBSOI5gCX600Su/yTRwGuNOZs+6EEopR7l85XwKXEGJYU70C8zA0aX7j/WjLLSPjJlVlWsTfEM4VrYM+AKKIP7i+KMyfZVvNIZ7ln4TNNAh5/esTa9eSij70z62991SA9/ho3rlUhq8id/kEoNvSvHpSTHC4wN/tFdwYM1r/CstP1zlmfpXPq2ncx34njKt9m2/8Iawpqwk8CQaXOalIEM3yvip76oAgFibVJ2E6FIgAQLE5JeI2ZlqoJYOKNzMw4SVp1vMkhnM070bPIKBwfKdgsG7Cgqgprj9fAJ2GmB33trA+Vgx+jaQec37yCSGaPlhH1ocN39ABHkeUn8NwIwbwsjzbvIdE4rBJggaC6uLMw4tQg3wMUPKmI/UNwikhgzEk6hTvqknhEf7ATmZa0IXBtL8Qx60sXyQWVIQkKn6ptLtEYiNiRYsI/w1pABeCXI0waXwU2tDfowsTVmerm7zZ51pEGlFERcMb2vOU3lM2d3udreAEU1xc576ZAwIMEJsbq11Ttha9VlbSN/elocgjGHhLmOtCC6EBGmrBPBiX5X7ZZU6lQXnNJf6auxwIiEdw24vskDI1woxxsAcDP4JbGCzzIvZ58KQ4lkISyWGNWTpSHk29cRIgi8aVtf3gTPrX7YHHmtxBDYW4DItfZtDgjErAXcIDDsNIQKHcU/5PLk80ZiVzJE0dIK2G8GFZ8Vxt6D5tjcxw9xExe9VsA/LecEMIs5o57L9gAc/8pGP7CpuDpj8WY3AzK4MS0SYQxpmjIc9C9/AXfBHXh24j3En45un24+Ug1y34GVpeIpHPvKRgUIGU6N+8VNBPkwghh/uKffGVPlNptfmAc6zNlwWWcDK9vFNeCgKG0KCMyNlHmcp4EYHQbkQUR5e//rXn1QCYE7RCfiVoqasd5Vv807gYmkhhFDSwGsxXmbxxJxO1Q8/4xXkNUdT+e0bNNY+quEhbi9wx1Q960w3x+U+Vz++ooejjcW48aqEJ2XywLIFP+IDKQ1ZTSjYrDtY4t7ku7S2gzfW45qAlNdfe68KABaVNAmh1QotG2cREVJIISHtvC7pQh5XvtMkYHz0MaUxjdOI1twjUp69fJJEETYbvIaYpUOAkGTqF4Ci9S2Ze0DP3Mec6ypQAgJmIJXzhCAxF7SyvlcNNJEAjhBCy2tuMQU0npgswo1vDDZtH9PWaJs0vtafH6My1rsUhHybG4RPnlrQR4wkDb8+cRXhfkab0uoPpIph4LKB0NXqLeMwKTRqiBYNjLWjleCuRusIGZYbsqwjxhj0l0uD9SzTWSzMJeEI8QXfkEyeD3xgbJbdk5gozPfIuGmlCGkINg0jIuTOdXOhD3m/pt4xvIQZwpd5g8T4gFoHa4WQIKJT9fTSERVrhLlApHp5e2n2q/Gy2hFawCA4Z+HUV25HxtKro0zD/GFw9RGChg8wV3k+48+FKcgcnOV54Dvtg5U83jvh19gxaTX4kmckKAvXEJjBAIHVXsHIEYTyOvQ5//Zublhn87GIz0OMdaaR1RNDb87z/LV3jAPhBI41nykP4iv4Nl9wjT9/twEAABAASURBVDH5XneAo3p1wmtgn9BtzTB89oC+98pJwyjAtRgb2mKCDKGzbBMcgS9l1hWsn3Ns5o/gSsEAb2FICAJgTVvwUQ0GpNnnmFfwaBziUnDwkyYTU4PHwORw7aMhpsBzWJJCKeUvn/APGKV0sa8oJbjhjeC1sq7eNxxMWaS/cGELjuDpGHfCNIaMgkQwT7V2wClh1VzU6BUhgbVA/bXyU3GYUXjLOKby7nU6HhDdZK1imbfuzkvlezn1icUUTidslHQW34Pnq5VL5Tf1jHHnmrfaQUfwbWgL3o6FBu/HXa8s40wMnAtuwLg9gW7IJxAm0YASJvBjy7j/qLMqAGgU4GOsZJoKkDaTqw0DKStfKwMhYih1tpaunhLJyZfibELaf0yDeMEtIZgT/fW9nwHDSlqFMCCoXl9o2CxcygNREABsfIhTedItrZh5da8zbVhp+VCeRYU53fsqAVNmzZ3ngJStFSGAFhADgDiQQDGTq7QTYzyqyYAsQ/HPeiNuiBCBB8PIxQbzSEJGYMyNeBp+feoxHXn1Ng+NC8KWxyMsNL0IqvZTQGBoezFFtKPm30a2Xnn5qXfjAd9MqBh9ggtNAOSG4IkjBEDYNvpUfXPTtYMYE1xqZQlPEKm5BZu0Tu7bxnyAy1qZXpz50x6NBwaCVcO89cqMpGGs7AnMFAHFXuEixDRujCN11PJYfz/e5gCX+UeUwUot72gcrT6GBvOUylhr7gHp2xMs5fBL60oIADPShRhjQNTBn2/CGKEUvJpjRNQesX9phOFK+eYGY47xCuLm276HYwXMrDr1OcYr8onrBVYOhN98sBqWeeFC9dvXZVr+rR6MMYGHQJWn2dPJnUz/rCnGIc/Te8fcUkwReChcKEFq+TG+6q+liQOfXFEx0nCKOPTJPHJVgFvRCesGB+TrLC/XWldYa58AZk9ifmLcOd+sUWBMmXUFDBdNZFkf4c4+xpSgBeZAKPOBb4oZgos1LdPzb+nqoxAiCMCzcLw9nuej9IAb8RXgHT2UHwNpH3BxNJ9wwLJwn7dHK0/phQljjYcLWVrAXJ7Pew0O4A7Mfamokz8F+NF+dgA4xY0+wUs5R7Wy8BiGsZa2V3GEPLQNXKB/xg2/YYi5bFs76475rdEHewHNorwr5xPvx61sr8aS2oETa7Cf0j3tI3ue+yumHl4RLxgPPG0+fKcAbnr4ylqidSl/eppbLpXpe86zKgCogEaGVk1HfZcBs4tRpAWlWaQxcgiPRhjglfmZPBBCfuBlWvrGDPYA2wlqpuNELGlTaILUm+rYr6fxYUhJ9AB7qh+YdoQiz2ceEQSEHILDqEJ+eZ7yHRGgOcNslWlzvwkfyzB7o+3Y/BgbJsAkBNYQqM1F0KN5JtggKBg982MTQBQx7iSGo32APM0V2M3LQMbqp5nJ40ffja2VF2wg9lwfjAUxI7iwgtjwtTnYWdfYF4JKc2xutQcO7Q2wxF3FwXt5ytqMHcGyv8xtmd76xii09is4RpDN9SpMivWiMWEZQYCdj6AZw0yZR1rJVv/mxBMezBuiMlIO8saQ6F8tP0YFs4vBydO1Q3OVx1n/hNNSfBLG0rcn5ptWTxocQSgFrzFesRcQXD+4xFKqzJwANjDVnmW5xADSYEnT5xivaFdcLfD35TaKCNL6WcdaPnFgBczCab5rAbGj9QPnZToBIDGAMcYAlwllvto3YcHccrXAAFK4OFRPU0fQZMFL5YwdE5C+0xM9Qt/cgmSf1+aRawaGl6BvjTBHtXypTk+uUAQA73kwt+ZDXQ7kw6uEQpZK8Kc/CU7hgXwMeT35u32LqWrta5p7MABvwdN5WThQWZr5PH7kHe6lbLKn0aG8jL2hXRad2rzLizEyB8r7XiXYZ0mQTPWgO5hVgnaCMU99S3lGnubVDVdg2Him6Ls6rSO6CXbQQW44JQ6RLw/WgiLHeubxe/1u3bgkcfNMa4fRLZWI8pXrbtzgGJyzRqXyaQyEA94f6XvVJ6HdXrRGNPcUFRR21jmvmyDSWnflMfvGjN6jKXlZ7/Lg/0o8R8iBz8ExnImpRzvl0yeWBMpOdaRgjginlOspbs6zKQCoBNIg9UNSGCadAYg0NRg0DIPOpkGSlvmAloiBsICRA8DqbQVA20oTb5PnQAIgaIhpSzAx8iwbaDWMzUQDLO40iMBofRCfhbe4I2VosjG4+ZhbhKVVn7JcFmiUWnnmxCO+gN4cjJSTD4G0tjQwBLhWOZuYVoWW1TylfNbQuNN3ekKM0tL3sk9zhKmztpgx60z7gHnL64QsmdlL7Wyep3xnqjdfxmVDl+m+IRJCss1ss4pbJYAvzI89R/AzJowxTT0EglDRYmMuaB9oseTBeLbaVR94N0+tPOLNJYYDvMELzqhgMKTlgYZDm+rEkECitKoQWZ6v9U5DxIXAOiEciIP2+BJLa5VbNR6jR2MLVmt10T4nOCIwOXMT424mmPYHM2YOynqklcQb/Jewrp2SuBHOMPd87FsESHs0xq0xSO8F+xguq+VBtAmuGGTtx7h77MrB9+CTeZ/CBkNM+y+tFzDN/Ja108rnYDuNLLxHc4hxl5cLiHlBnH0LGI2SkRNfC6yN2rUWKT3GGNAcljDCgLFLQ98E73ngu+syhJGxpnLmqoc35bvqVa8aagIAYVhb3D9ZCrRNKGSpxEjoI7jCaDrAyeoIV6izFeBF+7aHC6wBYQsM5PWgB/CnMeXxtXfrxrIMP4Bzc8fiTIEGzmtlRuLy9RvJX8uDLlPalGkYQfgUz5PSzG+M9X2Q8pgXY3RDIabQ+uAxrEvKA49SZjjjkHgtjB1YZ+kgvFlDaZQfNXhQl3rgDviT25l9KH7TwXq2+pS3TempbzkPYF4pOz3zvODIvKF50sBzno6mqS+PW/Yd/8gaAwfEGAPcQZmNtwSjrIOpbrjCuqfv9MTTEY7RLUqaFF978pgpYcy5JYp3e5kiAh0njFK+xFiHMfSENdwc1dqZiusKAAqTLCBlzD5iDBAxxphF6Slg/AG3iUtx6WliIJ+pTtoomIxUrnzyzS0nzYKZcMSbFqEsM/qNUJGuYoyLXx3kh0XwQWgwjVP19PpdKwvR0mwC8lr6SBxExRy6LqaI9o/7AO1xiyjReLIKcY2x3oBWHzzLDZrGgDmGNLmZGHeK97SZWuWkjwawpR0MDGJt49KW0BbToIFbmvCWdkp5Gh6HzTBQrXYRRm3w7UUEMd4Y+9wtLZXFMJLkMYOEAMgdc5zSR57gA/Ps6jgIKmfyEQZjwhgTREbqa+Uxbm5nNcZRnxEvLgnGSYNprxIwcoZL3fprjiEy3wJGmfsa4QQDy1IIyRFgECx5UjCXhCXWA0QCkpcGAWPO4RFPAo74dYYEAwgtYmwfEAoJOphA653gyNoiEOC37AMibQ7KeN/2jznyngKmpdwDNNc9C0sqWz4x7yy3y8IDfG+9EJaybt9oAJg3bv0WlwIciPmwNxAv+4lwmdJbT8wDRgeMjzDsYE4fjBPOovG2BzBWMV5BKDENGOFWu3k8vERbas7z+PSOQSFwsNphfMv1sh8IuBjgVGbkCR5KXGteCZgYezjNPmHBK+vTjxojUuZL33A0X2s4PsXVnvAbOKiliaONZWkCA75TsP7mrxRwU3p6Ym4IGRQnBBb9MuaUPvdp7tEkMACHzS1f5reHMGjqLdPQEnSPRYuSqpyDPD8cgTlzWQS8gY+AF+FC+CtfO2vJnYmVjCXMgWewRqjLeS3p6orxCjjXJrzJqgA3S9emvSFtU8H+4u5MCGX5sv9abZkL+TDIXPi42KGleEO4Ev+Yz4d64OOEPwgX+Z6zNui0IO+qAd0jTJR7UZ/MOVhladOOtRLvPQX9oUR0FjHF9Z7g1W1A9kzKF2PcdR12CCG0grKERHuplWcqflIAmKpAOimFbyM/X99l4B6EoEKwEBCEX+bpfRuodAOlJQLoAF6cADAAEEaLRUDc3GDxIeO8nEVGaCAW0rQ0bXmWIfWxjO9983elIS7z6Aemy+LaHJglDAiGFoGVX38xbebV97qCuYWguTMBaBtXH/lmuknHWtK2QVCQGSQAiWMMa32ATDH/mLlaOiRam1MMCFNpHmjca3VAFGeeeWagEbNJnWUAZ+YmMZC1cmWcehB5c83cBkHJ4wl2aS7c2awN7+r2zqphHPLmgfaFFU29Ak04v2DnZKwpuErBWrKw5eW9M4EiarRjU1oF+ZcN+ocBY7pk5nZlJcsOBE/jh3jxaVS//esbM+g7DxgHApj68njv5suhWof2MG8YppLwY6AQrry8+UI0uGjQwnpijjB+lBPqXmfAcNlriDS84gYkBAuTmNqhBWeZSN/piflB9I0hxeVPAo+Qx3mP8TKCbnwEPky4tsv5kbcW7A3CJti3L2t5RuPgHLBbw2mYb3sdExjjZX1O9SLGFDHgNcVNPTEN5pbrBmXOVP4ynaCkDgxZqTmGm+Crskzrm3tSb4+56QtcGDsmIK/HXIHdUrjL85Tv+kzxVDKRGGI4E26x94yjLLvst7oo82g8W3XYw/Y63FvLY4xguDYHBIB879bKE8pqbsK1vK04uAP9ZGUzT2gSl7uptlv15fHwFPjXRh6f3lmFXApg3YQYd+4DOICCjBBHW48vyftFiFBOfZR4lAwYT/yGccC56DBFAiEavpXXE37OvSDEw0vygadV9776pgIBA73SP8oYc9Hbu7wE9A8jjSaj0/ZSUmZRtprTsl3KXkyy+Bh3zrH9Bg6lrSNYH+cQ4NFafQRwfAFeF9yn9Ut59UcdeIUU13sSbPByeL1evl4aOGWdWEUBvBYBgMaMVAuAWx1GOEi0tH8IJEarzGsShVp8ikOcEWQaSUgoxXsyAbvvfBmmwCakbVFPGSw67TUJHUEWyjwkwDJu6pukj7FMZY0H0DN76Y+DVFytPBFJm4cgwoyLAcdETrWxTDrAsmHdtYyxRWRpYCFYgJvXSQsMKdkUebx3QgzNHmbSdy1AHCXcICLWEZHIA6YbkS3rgTzXiQwwApApRB1jDJ4QFs0m4pjaR0ytA812iktPY+cqUzIU5o8PpzW1jilYc/Wl8p7g4u1vf3uwX3zvRTA+e5NQA95ZLSC2vG1pmONy3awNbRW4zvPX3u0pTEgp/NHEQIzKIOzO+HAlKQkEeMP4gQnM8hxGT92rBHgMcQe7ZT1wAyERYcQslmsKTkukH2MMGD0CN6GLcGHflXXXvuELRN9acbUp4a1WZioOQdEPdZd5Y4yLA/wIoLGG7J99WI4tS971SljhFsqSVcKSzNrHPMEf5k3cnIBRByOjsAH2ubeyNNfaQcPUBR8Yf54H3QL/mL8Uj5mDrwnvLIAEY9p1ll84DmzDKSNWj1Tnqk99NE54qFcXYZK1rTbvcBtGyR7M66CUE5/H1d4pgwRKnlp6GQeutMmqZX1ouQkR6D0LKGadApKSQMAflPuurHPqG11uwYFxU35gYMFBjDuZU8qXGkPUAAAQAElEQVQ5ih9MfK0dFkVwLY89gJE2d3lesIbRdm6LbzrmHywT3tK+Qx/MCeGZAqzE03l9q77D1xRElLDwO7h2IUGMO8detmMOuG9S+KS0mvY7paWn/UQhRgEmDgx4phBjXLjFmf8Ut+qT9p7CslYP/MTiaw3gfeuT57MWYH/OGoBbsJLXk94pU9SV6jVnaAr+11zAM86BgfdUZpnnygIAjTsXnFL70usMwk8bivnp5WulQV4YVFpak5Hno52SxgSWx0+9Wwyat5bUD9iNFVEBDHl9gNVC5XEj78ZB054YPIgFMcAMIOaIMCYSIUn12Xy0xp4pbr+e1pE5tGTO9AdCo6Eh1MgnrhZspoTQUjqiUyMOBJMag4FRYLJN5ffqSUNL+CmRkP4jnhizkb5ArphGBCXPT5vAN9a48/j9fAeLGFsuAGU/7AvzQVDEKJXp+bd6ch/YlAYe7AlaLYwfQaxEtimvpz2jTe5JvvciYFhphGpt6StXRFYK6w+vMOOnvOC3xFnGQNA3Z+VeSOXyJ/hiHTRPiJKzV8zreZ5V3wnBzPr2cV6X/YxoGWfZV2kYzDx/7Z0ABa8R3oy5zGN+WHdoQvmJcxtjNcIQlHmnvsEZd6SpfCnduDHm1inFpWeMMdjrYBSsp3hP+N/YEW3f9ggrFU2pw63oETpJC6pPXBrkmwydDOYbbkBHCM2YQfiiDBh++8mcEkbsz061iyTjwGxjThcRl//BeIALMGsuLo9ePMAl3/bFR+ePPnMFoUSgIKLsSn1GC7WdFycsUZqwxnM/BjvyEJS5nxofd100U8BYGyuGdVlBwLhZ8axr3hfvMcaFEAwG7IMYdzLBMcYgLTT+GT9ruvMEGGQujxQftezmmeshvkDgDy6ftaf4IADBk+LWFVghrT2GGP4iCLFUEDJo68H/aFvmr4QJCgbCMKVXq54YY6B0s/flsd45LoJ7CGGsZdLXEcARnqvGe6gffUarjd+6iEtB3wgA6XvkCdYJmvCd/HhPgjdawNpACDBO7YIBNMXT2rAQcpM1L/CK9THXcDPrE4W8OqfClaYy9NIhb0i6pgHtlZPmrADtMWTouxUw17U0QIQAck0p8/D75jZASq2VbcVh2jCttXQbGsBB3OXiy29DQoDe5wRIG0K1kGU5yMsGICx5L9P3+5v2G+NaanH1y3wBQggac45hgfRoMqQLxkRwlNd3Cogv4E/f6SlOWvpOT0DvcGr63ouncdBs1BAQrQXEWVvTWt+4BeWanZSHfyT4Tt8H4WnMzNoQU9kfDAGGlNbKerOoIdyQZpkX7qBJLeMJFvytCQc1uCrz+9Yu4uh904EljMsb2J1qK8bLNPu5QgKhSAg/lYe4MRsEvhTXe9KGwn0IAOavl3fZNEwKdx5EMa+DOZ/yAR6McSfjA//1YB4csOzRYhHYELa8bu+YAgwqJoTFU5w6+a0TvPQJQyJ+JIAx8DSSVx5t8ffFmFkXcSn4pmygBAJzKd7TmuYMALxmjqStEtAVrjgYfNYDFhNusNwu9MF+QX9pizHIGLQyGD8ljb1pbo1xpE9oE9g1F/Au5p9wRINtXmt4u8U81doDW4RjipTUZx4C5jjPrx04En3GmMP3+kNhh4mm9IvxCliMMQbuec6BsUhyV8zrG3kH/5hBc1/mt4fFe1qDMh2cSCvjW9+sdnB9Ld36o5+EXwyj8dh/aCnrgTmslVs2jksaYZsVxbpgwlnhrcEydcZYF4YIcWCrNW5twekUAHjMGu2HT8C2vGXQd4IgV2C0ukxvfVtzNNca1vLgNQkA5bpbb32slWnFEcr1kdXBvqHRh9O5YMKzYCwvG2MM+GU0CMNvH6NDvs1FjDEYK2swRQYFOSE5r6N8X1oA0DCzm8ZrzEDZUPkdYww6LaS0GGOIMabPo0+TfvQje8FkMaWZjCx68Qpo9Q8gLCIG/tiINAk9ZtLCl5tB/wDAQBPVLDYDomizlxkIGw5/QvDSaNMBicWFDI0d8wA52rTy7EXgnoGIE+Sm2jNnGFybEcBj/pRBJLkXlfCDEcJEy5MHEjImI48z9zREzirk8Zt+x4zQ5pWwoF3WIoKPsxM0UbRcTIfSymAfqQchz9MQOAfQwXgev5/vNHY0m9Ztqh/WnCWL5tOZgnyfQ1IINO3ZVD0j6RgvSHQk7yp5rJXx82GdUw9CRpCn+YYnasSFto1CBPNJc+wAMnM7LV+Jj4477rhA8J7Th2Xyah+uSQwgYQMsg0mayBh34mowSwtea4uyAPOIoOt/mQdTD/ey+GBAMGBlHswOdwc0h1sE5sH+L/Pl3+a6xBl5eu0dPiVw8AnO0+EfcAb+4eU8zbqCwxTH+sOPHi5Lcb2nuYPLMXfKmQPwYB+hZfA/nMvdVt+sTa++daXRLoM1Qg+BBvxjTMB0KaBb+5Yme6Q/YITgB7by/Np1O5A08wB/mJc8T+1d/whFLE2UaLU8vTjMIJgtaQtmjebWnJRwoD750STvI4FAD/4JkWV+MEWZgtmj9MT0E4bAv7gy/358EwwJp/iRsv0Yd+KIPJ3lx36qjTvlgyvsed/2n2cK9iFcAB5SnCcmmRIKP0R44LIqfiTAcdzTCFxlfvANL2m3XHf7F1yUZdK3fsJvmHvnVpyzlIbvwxs510Hrr33xcCzLUA134bkoyORz7pYQVPIhXEgpYCngekLA0gIAQGR61pCOtAIAJlHVBmIShVbZkXiSDmRbAoeyzPSAoAQQaa2A4DpYAajzPIDU4scYF+a/kP1DhIxPyKKHXy06pI7hU1dZkKaM+ccGs2FoNiwuZEj7gSGBHPlrM60REso61vmNmWOKTYz8aN2AlKYHM6QMxA6YSwHAPCMy8uTBBkRo8zjzJb62/nm+db5DMGAfcurVa2wYf0jIwcjaRqRx4TJS7gMC0Ote97pe9UF9TIEY827GNSRifrl7LbPmBBzwmboBPs0hAp3iyqe9RENCKEdsIdgyj2/xCDUc4HuTgTIBU4bwz22HUGi/gl9MaV4eDIujcSUwWVdrSsvLvItQKpfKEJzADdhKcZt65gwgTTNmCvNFC1buW0xPjSmBLzCuxh/jFQwBnIqp4R+MQDq7hfmujUVZrjQOkTv/RatLwKaNFqeefI7U4ZvwQrPme07gUkX4oXW1NuripkLRUtN+U97kY/duLbm6YOCMNW9ffgIMBgBzal/ZF5g7+4wmnLY3LyMPxUJiFrVBwcDVZQ6Ny+tc5t34CSXl/sUATQkAYIFlniDJwkPwJdhxE7Gu6Ny6xwJPozn2zJzxml+Mtj1g/ZX1tB8J6faBID4PeAdCQB7Xe9eO8ZcwogwBkmDofS8CHISZR1On2jNO+wQvYG/WxgxHoPu1uri6gPcSjsq8+BtrZ7/naeoVD3fk8XAn3i/GGPCn6HCePvVuveGUkqeglbdnwb+283rQIfCfx6V3MO9cHQaf4pBimquP+rhVoa0pb/50Jgxs5HHe4Vn7zD5Rl7Mw4mvBzZbmo5YmbikBgKROk1NqLW0OnVNxCoCaTxLGFMCkeE+DELwLgCXGKwiEOAGB9GwFByFKbY28FgnRRlB9jwQTzsfKRsjbJciIU2cJsPIB/nJ8I+2lPJAgsz7JT30p3hOTj+FEBAG0uFrAmBgrxqGWvq44fpbaMRdz69R/zB/gdZDLD8rkdYAXzG9pBpYH0RS8p2CuMIvpey+exs+cHuNuWG21b5M6SG7seR7aCcxhHmcOML2Yjzzeu3kjLHKVgKgcBEeQIEeCa2+zK79s4PZC6CwFlZH6CLCYl5SXWZlLQvr2hEC5h8QYF1ZATK48rF+E/NoamydMEiJNaFTPpoJ5x3Tai7024MBaXzAK5sEeLecQDGMya/XCR4hsuR9YV+C2WplNx2H+hbIdTAM8WcZjYjD2GBm3erBesgayiBgH5oESJJVDEFkXKTTAOKJLEOS/bg3sJcwy336KKHVg1mnFaIrVxzfaNzylbKp7zpNrJrjHlGoHw0IzSFtX0gDwWxs7665xUnw4xAdeufHA5/x5MQTgNx//0T5e/oKBQBtoD7m8YL7RSmtACMREUB5xqQCnlxfb2KOGtzWGic1h355Hmylz7Atwbv6ci6AU4U4IhjFr5lQdmwjatX/gyLn1WxcXNuAJCJngkVaVcoICSyjrtGfntoV3gM/KuvBTNbgq863zm6aa0KxPtXqtJy25M5GUO5Qv8FuJ15QFpzU+AWzgI3kAyNcL6kYHwFeJJ+0Nez7BvScaOJfpz9u3fqzWmPQ0B+IIfQ7jwuPlmAgL+pfXM/WOvlF6JAtHmZ+rG5xaxuOZwRdFMDxSm/dUBty7dCB9l8/ZAgBtJWkG8sorA7zMkqSaPN7mgxxpKhF4g5KOKECGyyJndaSAuECAabFSvCchBZJBVHyPBMw4HzsEAGNvEWh+aCgAY4n81SkfIPE+NyBqNh2zL6AwZ3PrSPn1da4vWio78mSGppUc2WCQfq1O8daK/3yJADB6YCgnJKkOzL+y6Ts9lVFf+t7kExPMDD4HnvQnxhgwLjQevgVz6TYZTKHvFGgSMH35HPDr4z5lv9AYmrsYYyqy+OESzAqtmn0GMR5NXPGF0IIhQ/h7VYFb+9ozz4cI2DfizBvhCRL1nYKx1gQe+THd5RwpRxOKwUCYfW8ysGAgdiXiL9u0/zCuhLKcWIFbxJx7Q5qLVLacrxSfnkzBcFKez/yBHWuT8u3VkwncOPL29A3+gwfzeO/incliQaCR4uaDeBmTdLAqnU938nfGOCOOLC7K1XCusjHGwASuPKGAEMyiwMwOpuRZJaiD9Y5bjnooLNCUsj/WvccAcO1hDcD48ufHANn/6qwFdBYTwnouP79/46vlFWeO0CxMi7LiNhX0gwtQXj/6jzERUrxb5Ag+tflKeUae6sbIYL4oyDDhbsXj5oH5sz41uEt1o4fKLIsnCAGYNIImIRAOVrd9UAoA9jyGHTzIs2qwd4RV65lT3njdTmUfmfdU1pgocuFBPAD+KKXBz0L6Tk/7pIYzWbkI8DFeQcNSmdoTY493xEvm6epGk3l6iCcoELjF+4aXPOcG+96aE/7QVMI1ZRsFZg2erTk4q7VDWETbCAllOvoGrlI8Og934TUpfEu4Nh54hgLemPUnlc2f9iGhFU9A4ZCn5e+zBADEBqKlwcsr0SmIyqasSSPSATEk5gChzkOEGN68nhjrwKB8nq/2blPmwJryAAQEgq9Uiht5Qti0RyYYsTPZFtKClQQcgqotbtkOQsdkg5FTP4SGYWJuAmzmJml3yrIj34DWGtCYjuSfm8f6I2JMclNlMTw2DhM8pJjyA2jaa/DADxwjk9I8IRnp3sugHnOdx4MNbeVxm3q3fsyd5qHVhj4SYGp9MtYEh+CIWboUpNVr80Jk1hHzR9pnReNGQaspTysgzA7WYVjAbyvfnHhjBpsx7tyf5Rh9Q1z8ZglrqQ3x4Ny3cfF5tC99p8CsSqME6aU4T/vBHJV41rk9lQAAEABJREFUxbpjIAn+8m0y6BOCB/Hn7RgXxJ/HeTdWawD+wTuY0FfMi3GCA/lSMBZ1pW9PzCEE7lICt3555jgmxssY33WtsTZHg/7DiXl+YzTuvI95enoH97TpXFngQDiVZYAW3FjgBIxVyj/6xGiM5l0lH0aEEBDjzr1g3AT3Xt2YfrgfI+FqWxpF1k5uQNaaZYSLp3rQU7fkYebBTK/elGYOuENwNTDPKX7dT+MAA3m9lDDwHrye4u1NY7QHUtwyT4IzKwe8i2lkNTVGcQQ+tD9vN28DvSCMo7F5/DreWS1YKvO67GX7QMjjp94JEtavzAf3JH/xMm2T3+YTf0bAYrmioCS427sUrmXb8AFeqYyH50t+yXhY0Vmw8vyUeOhcjf5TIsETNR6PMhJPKRA4XdaS6rUeYCB9z32yVlH4ucbXnKCvcID+pLq0gfkXUlz5tJ/Ls1zyoJP2jrOsXLzRDDwi6wgraekdEGMM9oD0cl7VBw+xzlCcoNv2hvhWGBYADJrmEZIuAZX7DYRGOqttCBOUOkC6NFgMSopbxxMixTjV6uIDSPNUS5sbB9hqE68NyLdVn42DGSbdYeQwVPpUItJW+VY8oOSaZJParG55aOVdJR5BoRXAmJTrD+j4uWIC8jYgblo8RI/ZELDrK2sKZprpt9Qa2OBM/nk9U+85fE3lXSUd0qL9KMef12kO+LWSuiG0PA0yZPEwlyRzm7RkbOUnYN3//vcP1tNmB3PiR4P+gUUaQdqQ0XK1fBhf4y6RNWRm3+dz750AR7inlUvMsbXH/Kof/qBB9J4Hc6IdeEGbKc1clEhQGrjHYGAgfW8q6BefZb6mMe5k+oyfEF9rG5FE6BBF6+GqUkIAC1/J0IGZJABA2vAEdw9KB8oLViOwBHfmbWFAaL9q85nnW/c7XGde8nqNgaBKCZHHe0c70AeabDja3uDKAgcSaO0L+ZYNYJFAAbcsW8doOcyF8ZT5Me3GX8ZPfbOqYWittbWkICjhY6qOPB0+YQ0gOOfx63qHtwlpJZ3HENH4E+JTW/YmmkGTXMJuyuOJLhAewD2GvpxHeEW+VgB7rTRWQkyVvrTyLBtvjjHueXn7mIYWfsrje+/2kmAOy3zwrt89gBfKtL34tiaUfug4D49Wm3CCvpbpeCUwmeLRI/SBVTfFeVpD9TvPgm5xFRSfgoPSFAb2eI2hh0dYFVmq4dxULsYYavMalvxn76PheXF9x7fAbXl8/k544f5WwrK+mg8KI8IeWpHK6XcNN2o/zyc/uKMsVA/6OcX4KyMMCQAGTRpE0MqNT2phHuGyAADyxdaAAZsg71PBgGPcSWSVF5Q1MAexAAfii5EkTGCuAUVL06BfEJc6Vg20P+UYzQlfLIdnMMJ8VWkr8rYgR5skj5v7jqEyzwQxhCLGGAgQbjqwSW2QuXWO5gek1r9k2CFvzArgrtWFESLRQpaQAUYIM6j/NLsxXrHe1hnzzw2gVlcrbhS+WuVH4mk/EOkRZtxmZJ7mCpITM/GIg7kAL54jbS+bB/OMcV22PP9iiB/TmtdBu+XwJcEvxp3rZx8itrQx/JtZ/bwjwrSZ3FZKopnXDS5ovPl0I4oIhj2X5/EO3ggA3jcZEBRmWXs8b0f7zOHWNI+fesecGVeeD/yCKy6RYAbDn9qTlnAdYkzJksrGGAOLijlNcXvxBLcIV96WvWt/1/Cs9afNhgPTuPKyc97Ntz2FBjCr88c2fpq6OfUsm5e5vmahwNA4m2O/lOub2oILMTn/n707D9luXQsCvq4D5oGmHU2SWDtoUGjYYhxTK5QgpOEkUSQcKgvRoMGyiKSOnEPDHw0ey/wjMocDCop/iKDgfJxBVMyBg6h4VBQUh4Mi4vBH+/e8+/q+672+e61nrfWs5x32fj+++73nYd3DNd/349xk2hbfXlCXP1cPPGbzi2CaK3NJOobUHEQ8P/fas65gJEk7HI2Zl44QRh/AUWAiabzngRFyNB/SMBRMGr02RAJc97g2OPuLP3Lmu+Nk5cwTfEz6Kn6k0ydm0HfXdklzCTxq2rmw/QTGdaIu6yFu3UNh255p9+nDg9YZDkBwIlwJnF566aUXhmV+kmYwZ4QpTEB7QZovL6Ax0yLBZmbuQRaEs/2iL/CRhhns7fXF0ULmSjgdmrLDqszb4xO2IMBrXTCJeZK9XtNrGM7EjMKPNV044vZZkrbFmTPzBdebpy11zzIAFg3wRnz3iQTQcF3s63RKDdQPooM7+mjlu4uI0wXAni5uHCRGPtIiQHzscm1AEiXEL4JF2e5wURBsT98axwgh4rU3qgsBMm9wCQ035s1qY1WWOQfJ8NImUY4DuGg0AC8AXxpngwOSLk/dJTAAzCE2EkfjSGecAHq+DBIRmXXWh0i6SQUGDkOJgJxrwH7qedLWzGuvtzZO5Y2IgfhqHSo/6zza3yShzg3pDcYQ0eJpRxemqO/sZcCptrcUNjcAIaSJSGQyAKAs1aGBIZlYKjOX57xh+vqZguDsZa6P3zoAhtkmghVRhEGURnvUGWN7qO5x5ahZATSwxXnvDIM+mMS4KK38tRykRvLW96m9BkkhzOeQ9mhMiGN7CVKs+WATQgghC4Zknn0F6TG7JNFhWgUhZj4f4eAOkXbFr+3sixHhY9yk+ohPBKB5y7HYp32NM2+tT8JOsAIGQcC0p86QuYEA17ZzSTnfbv8mQVPbwgDQ2GFE7EtCGuVrGWF205gX4TmHiAc/vAICdtCmgSMILAykey/OwKi+evqwR0f5l6aZ805k1TbtA+eGKSq6gMZPvnEx2XEfj2ACQ0BAIK1qB9TvZwpc0cacc37U6/lgJq3bEj7pddbGEe3Oc6cFwDMCE0Tx2rbQFc5xxDz+hC9pU5KeWNv20eXAY8JGMMeeJICFswlhO+2nb/OTeAIN4Yz0tYLX4AmwTh2OJoiW3PfaL8zmpGM8CJPgNvFzTv/Ozblya/ONBR1Wy4PnXvwC55xVY675ws4jxvA3fuM3RM86MACTvATb0Iju+9Ec8s82OihwlgFABADspOi1PuKfjRJCINPnGIBzBzjr50bJePoOlQm08BDhqD2bj8s61Y8Y/xhFLbMmjDBBDMyNs7Zh0zH1YTuHiLKYAB7pnmcLEYSIM0QEqb40QBMhoDzgQh0GcNZ2bWh3MJj6IJJq3jXCpJ/GBMHV9q0Jpss4jBFSjJgHYLUugEcK0BGkA2Seatn7DhujM4DxqutOSkUaMUIudX8i2BG+iBYmP84Im0IIZO7bMBYYK8AEgaMe5hvwsYeMBzG0REgguLzkAAnP9bOUDtlQ59czZc1JMAFjyLXmact3zxEmECLtT4cjgD8tQdf6ALIp9Yq4va9owuwTMEG/13DOH2kVhr627/toHhF6CJU+B+bIPNQ6GSa0gMjrPpKnDftMOJ1+SMAgFjBPOo2HfYEJE+ciYgIv3CcRn3MEBhgIiFX5uXLn0hEqTLLAoVFZzBoCENwjeQU/zBWNDljnu0b1pJk7DDU42NXpiDzt6lvZ+3C0UxituW83poiYaDZpzJl7Yhikp0OQIuwxd5nGh/DtK+ZACCR4hsYE7LAPXYq238Fa+IImUb3uSP47k9jL7I07w9YALDrXBnwAbhFUgGHnymc+Ysq5ynj69kaGq+/cMKMyZzVdGBztcEX6Ec66wokRt2ETuA4+O6dMX83Zuf4wVGiLpXLmxF4AE33zUtlr5tm79h+J9pp+nHdr544jxgEDX+sxCwT/CcZq+lKYuR8mt5+hUR37AkN2xJzBCYSA2hz1RTPK2oFAGrztZQgxnPOennFwnQUEOGCdnRumn5mfvrlHG6BJvCxYGegss9afZQBMmLeIDQLxUhsExAD0SvzLt7iQmXA6yHDNQikfEbMaAPk2HsmSN4QBOmlrnA3INnlN2aUy1JQWealMzXNoXUpxYcl8ymNDbnOYK4cekHdIbGrlSEQS4dss8tTrDoGEoEBM97yj4lS6EBmkV9u0ntaChJuUF1G3BilkG+bE2CshpE0aDwRAllvr22Nry24tR7JB2gGhZV37yfdD8L4hIjLr5M+Nxx5429veNiEkTgVn/kBcLh1B/EwcqmQkqyBCIm73m3n2DUmJuoiGTF/rA9b6RnTVOiQ9XibB/EN0fc19t3WsdTLM5KkT05go8whgsvvUbpbn+8YRsHVJDDGpzLUcJI7ZMobsw7pD7GyaMX72RM2v5TJcfWcfsVLTRmHrh1DH4FcJkLXEULJ5r/XsK4Q26WpNzzCJlNcsSIoIILxGlXlbfdJ/3xAx3nvZnnlh8mUfEyDRhmI8EDHWeoTAnSXEEPwyInAhYDA4+7hrnzna2v4RsjR97j6Y/xyrNcS42/uZxo+ICXG/hmG3/xET6lXn/BEsjeaultsbtr9GsAsuZgIxahe+RBQRJozyexr6Ad6s6b6rxmtY++bXfqvpwuZizlxE/iXOGdL3XBvwOwEg7SdBqTM6VxbD2GGtsuAAPx3hEW08s8RMu2vf/gWX4Aj4emltjI3Um4kXIh8hLi0dOoe1BFiXaWt8MBGdRAB5rn97idCAW9P2UhkCOGsFTs2Vk4dJJpEHb2s5hDsiv6Y5x4R5nm4HM7TvrICX8E3EbTiLHiR4RJevIfztO/dD9U0zC4bV/ocMgEpUmKSANnJW0DkA5Y3l0aLZxP0gIgj6Rs721vgW2ERkWUQCTpIqCafUAWmWqz5pJSBV0/aEbQBEe69L4uJg9HRxAM1l19yAiOU6R4gIqn+2W+ZcnXQILPUzXn3zCtCPOMRabm8Yooa8ugTDWpJM2hts+bVvv/gO4XNOWYikA08HATEICS61EXH7QChrj/CPdtTXAF1nskhB2CvaUw5txPMxLY0FI0HCN7emOf6IOHtxyXyPiOPp1X+k6swEzs3lq0Vf+O+bmdUh8mqmPY74R7hJh4zsT+F0vh2MyHj6TPUQQ+pkGt88YlScHcIEQgW2oPLmnP3HxELduTKXpltzjJ+9WtvSL8SDQJUO2NezLM0ccMLVAeoQgv1S03vYebZ2YMEIwAPiTMnMQ60LNlGxI5JrurA9R3VvvBFxdm9NC/8ILJhBLhS5lYVgJrRJxEODhOEDkyOen5usBIf4ho4o5WOMEXXCd+3sBRfyMb5r+3bOrXkl2NSl6bTOwt3pRx3Mu2dRMd32gb3ntwDAIud6NA/2He0Y7V9v99I4Ihuesj61LesEDxsvfFTzMmwPgCsZX/LBNURbL+Pbepo4k6hOWErnzBMzCeEjnTVwnqzVuXYxzDT5tGDmsJfXBvoAXVDzwFHr38fv7JH6uo9Xy991GNy2r1kudFiUY7E37HXjtQcy3d5HxIJX6MlM3+KjPTAVXpkyV0t1wROS+6Uya/IIMAgo1pRFNxG68LM8s6U+V+aI2SS4mOXST3id8fQjXoSbmdd9/RP6EBhjLjoD/wIDYHOT/FNBVGAHqOBKIEfq996RepgFg655iPf+0TW/hnvdzBsdfhF3f+EAABAASURBVGOwAXFPc4An6+NCEUUZ3+M7qJBYP6gW0PNtVJ1zWgZ1cy4d6FE5WhaIEvDP8VEDd6Ip8xBAiCbEU6Yd5dNQsL8m5aht2sDUmoh/jFjmUfvPjTPLpO8Q4ZAr8Wp92XS7I5Hltvjqbym/piwVL0azaz+sH7tHUnnfgAiOuH0gR+Px3TQ8nbAejcU54EZ5mWa+9Z3x9DHEgAlmKtPW+vnNHUiQODtnXujJthCykHXG+b4bYyqcDvB1aawjP2eWHT0NUpYlVLDvqEEzrfsYRaYw19j3+sL4gn19nWgcmMKZW+U4BB4nnG40B+aV0KTPQdZJn5SGtMZ9E0RfplffdzPl8WpKTceIIPSdTfAm88BlqmImidLAK7BceKvTLs0dZFLrIuZJpX17Tc8w5sQYMs5+31yM9jimGqzu+wgewYTOvbqUbXcfzHZHiTDDXuz5a+Ns3zEA5rnWMZcurlq7mp5hc0XgYQ9kGkbGOc04X7sEBIhW+ATxgGiGwAmPfAepH9Mq547E3Zyom878WwsEVqYd5dtbYFjEbVhnTQiEaEOdX/ur92md4Td7sef1OLimfE/HeNBGMzklTMh869LPqjxEIS1dNyWTd6lzf8E5GDEqo7atFw0dTVjPB2uZBVr/muecg+EI5E4/IeRo0bRZ69x1GA1gn1p38937B6MwACk0tV8xtGCUvY6I73W2xGkA4FR7z3zN1bV3Oh6fKzuXDl6hWzr955tG3x5x81wnQXW2+Zu/+ZtTh2vqjuhBdbTtTAtXNzofNb+GnTnfL80+dA6F073AAPiBBgg7CVYFAXeImVrcoZLWnYmBZPrgfPAIKPT6GY+4DWBMgInI/OpbdEABd03yUfMyrH9SRS7T9viAH4K4H1TAnCqLdAaBNAK+vh9g1i+7WOV9l3h1uHt9ZBrAhrjOePruDpCiARCZdpRPbQ9ZQnYRz9eCxIk6n/qv7wEbrBOjvs/c13EhIBwIAKymm0OAjmqvpvewvRXxfEzy9cM/0hknKTjEXYG8ObDXMML6s+cRwsLV9TFpj7TD3Y1azuG3L+2Pmh4RZ6W09gU3tX8A7h5GCqHh9R12u+Y5m0WMe8UDkM00/tyad2TFNp16s86j78ZAkXRrqzqSJfNrT9T0DPtmxCSAnGlH+ZCEHywk5c42rSWzNKrq1H5kHuIOE5hxPljFCacDU0lh6rxmXvrOtPlnE4tgNT+YDeeCtgnyybLOPVOghCmZjnjyWAOXaeCJtc35t9fAzczf4lPlm5sOAzGILvGlZqS3CfGAbZmOgBpJbcFwTCHCIsumb18hNhHImbbGR2ggEjBVzCfW1BmVQQCP9pwxsccljDG3o7qQMFieeeZ/VBbONVdZrvvmHeFJ6u189H1mrzpbvd6lcfvHwxNJyGV7vgGsgdN8E/xAOzUaF0ZphBuzrfThkdyrmQbWEEqCQ5hw0mO4BdPFDNW+z7LpGxvzH+PKtKN8eKGuZ7Zr/zPvynj1jZFgzVzWdGfBXYKaJqwdQk4/7Da6xwBWoX1oV5W/K6df8CXPAkGFRynArToGawO+OxuEhmz80wwUfK9lLwmjRQhsmFlhOEZtgbsdTo/KLaXBOUxYI27TH2AVM6/RuYOrMO4peACv7dvaD7g2OhfmmcYN7VDLC4MD/DWOpQU6RVlzcJYBAIDyAJKcu5BFfc3uVSNzTsNcxO0JAgx8+Fy9NenaWCqHOIEw++SqA2GQqPDF9zoImDqv13dQSa+1DzjZ9HVBjd0mJdlSF5Frw5CAildn3pOgtPAIZetRy9gwJC40DjX9iDC1JkYPExDxfB2pqKgxSR1GAJXmJ8ddx9HXA+Ak1bIRsxykRRJAqplpS37E83FlOW1k+Aif7SYVK2SU7ZE8k84yAck039zXR14fDxUoxucDPuADZJ+cMiQYCN66X2QCWF2yLL06Z62OT569BhAzFxBf6wBzANTa2INZj5aJKQrztExL35r3b/dNxpBlEF80hhB4pvGdF0jAmRGvDoI0DsRQTc8wYMY8x5hI6zP9Ut8c2N/s9M2/9nwPJGwOEN3SqhsxAOo4o1nOmYKknedM6z744NyBDQQJBDCAv7syGDLEK3MAZwQR4QwiDEjTelu0hgQ1qUkkIU0EpCzJs/rCW53zS3pf6znjbIGZAvgG0vuan2HlhEnCfUOfD/nuV7jsqlx3xg0f9fSluO9mXmGfciOibal+5vlu+8J5zzQ+IpNJlj3iYrxw3f/KcBB2Pc+IBU7eFgdO0JhZd33ba72+dveub29L3Dp57YUATLw6sAZhl/0hhmgKO/xB/IMlWa620cOIpjx/mee7McgZ5yvj/HUYKI+jrcaYCh/pwCZwp+8F3+gM0NAQFI36dIHe+cw8MMe+IjjNNL69DjfYV+AOhgdzLK86sBITYDw1/Vph3w7uED76TkSqvggqCC0ww+KIf3canQkwzUMGiH+4Tn53vgHxbg7BEsweprmXy7j2wEM0HzxCs0L4CubpEyPmfCjvjNh7xii+xxkLeDxigDG/GCB99LbtUXXgSnn2NlggnA6uSPpYP2Coc+SMw8m0f1mWH3HzoM3cvlemOjRrlgWDOi5+QQNAkgP5RsSEeyA9MaG10VEYsLXBe56F8JE9fW3cAo6Aaq0PgSKIO/LRL6kdKVotvzWMIIbEER+1roNKOkiiLx1BgwnAkOSBRfhD3MaoDAfJSTM+8XQAZB4iC0/S0zeMjeFblc16R/gAvbWukkprh1nB8fumuX5scAi25ls3yCjTbG5SpC7tMC/mA6DIslt9fW2tM1cecQnA1L1M2ubiOQlUrWfOSHZqmrFwmYYYc6G2A3lEMGLPencVICK8zyciBHBgbmC/AXRVqpr9OewQY8bP+b6BFI2EM/cahAuZ2Q8km6M2MCCVkcsyCDlhSAnTiOATT4dhNvYRQLZHELv2YMSLjF62AbAqQzhBI5Xpe31zQPLv2TlAUjuAsrmmCRqNVRlr3+cArKr7ntQIEFZ+5BBR+oZAwQP1R+UgD2vkngTEjziwNhjTXp5ZAaRKcENyZZxZxneBWxlf65NkgYF9HyPMwFiwz3j8oq89Xdu1n5jOSfMNNGERt9cXHIDESRSVs8b8dNrQR8bX+GAoeBMRJ41aJ9qmFf/sDcw7YUwvbqzgI1gMabv413GQOohRZYS5pXWW3x1hkbl1KZ02CawEmyucyTrmzZgzfqnvTHi1zP6rbVkLkl0MSU1HsMKBCFiwwH5mPuc501puLmyNfEPNRxiCGdrUXs2bC9tPztZc/p5080qo0ZlgbcHLBHMk3tZqdMaM3Zwoz2Huu6ZdOs2FMyXMaXeOBqPhgxcw1cpe04ElzoH18YpfNcXCFHjlDTHuvKAJrIG9b/2Zr5m/Pj6wzDzQCIJT4CXCF2ENLvbyYBAcgRlBlMNRmA34lODOGWRSZSzaYVYNd9b57G2ei5tbgpTEj1meQMJ+1zbB7wgWZ1m+7+/4wjl2ttAX5gl8ZzLZ+1Kfi4gpcZT4koNP3b3IPq0b+G0cWe8FBiAztvoWcER4IG64Ne1F3EYKWcfByfCcj8ingkyuHxLGJUJIgNVcvTXpDj2k2ssiZvRR0/WFgASsmQ2w/cWl1jKQgU2LkMt0wBwS+a7v+q5TEnW7xTtFXvtjg5G4AISvJQ09xBdJNQKGfR6pzEiC0yvbINLMN1tbbUA4JPTS5xxCNDdZlgHoEBsZR/w7sHVjA+y+B4DLcud889TLjNJ6mTVxUn/IC+GQ5QFj80A6nGnpkyiO9rz5U8a+sRfMj3g6c2tNAA4mO8ksZj5G03wBLkxwzBNVO+DA7hPQ12auV9YTp6my5+ohz/yRj9m3zzAckBaGlo2mfhCZozrSAJe+5tJ9O6m3+QLMpaVDBLpIbM0zLX3tAdjWYNRulqs+mAP5uQgGMdS8LWFnzZjNgXrWHLNnDeoZlVcdYFr3szz73jwKc74FQyfcHaIBjPC8sTzf4bzOwcuImJgMpCkLQgMBZs7Vrw5hARkitms6uGiMNW1N2H6AWGtZ/YJXxp3pCAEML6ZJX8qYQ3FMBKIBcZDl+eaLSRMYLj6aL4gS3JS/1mE+7SvlI2KyFmvPhToc4gGxoa54OrAN7CeFzDTfQBqIMMg030+6iRiqaX0NxJ13ZmCcc+KSI0aXFNFelJ9t6F/bGU9/NHeZt9W3Xl7wcc5qXcyYJ4YJbmp6hsE10ljCD98AnswRsFmHb63AvojbdIDvNKcISzgeHlR+zmGw7LmRVHauzpp08Nx3dQLMPQMwTZ/2qHOHgO14CZwnTNIXeEOwVgVN0u1z60ybJM6ZO3Bh9N0RMSHGEZDaU/4aztqQ+GPQtG+d9EvwK85hiDGFhFCIZrgRcctszd0NRHKnQ+zjEbzDaMAHtAHaPucIqwmy4CyCIVoIuAE8sibn6s/l+z5nj1/LgG3oMCZv0mlGwALp4ukwQPD3NE0TjY95yzy+s0Wb7awIS0sHLvY1j4hJG1yWm/PRCGiZhAl8Gqi65940V3lruo4sdq8HWIwWuJfLeMTtw+8QAY6Zv+RbeIeUzSzEinhFVC/VOZfnKUyHPomDLG9TQcAWPdOqDzEzm4IUanqGbR4vJzjcFprqyyHO8To0pKxZ3hxAogAvxIazJUF24LzC8J3f+Z0TyZu5hpBJXyFtEhxzoS5TKMgs26y+72HqwGSDlE4fDp/0Wq6HAQYbyuaqeYC2tZdGg0Kyrqw4B0iTMpN8nutDeU6b9oNwOnHpGd/rO5wIK1oXbWjTZVPEtHWS1p3v6Xs+x4NwIJ0GyGo9QBJTmupQElQSvlqGJMS+YztvPOI1fylsnyISe79zdRAmiA3AlsQYYuoMa6/ruwGSvubKIZR8tzFEPD/L7hFhpEjIlKsOcMUQ2dP9W80nxgFirHUyDCFheCFg+3sPI0BqS0KJINcOuOHsZh9zPgCr/5rvnNrbmcYcIM9BpvFJrDBJSfRKcw4QkJg97Ujrzn4jMXOm7CXnH5PYy4mTfndEEfF8TZRZ4yBz89rbchHVGbaHajtgor2LYHP3xXxiqpg2gWu1rLB5R0z6fvGRcx47ch2Vq2le/kiCPyJODEDNPxe2Lz00Abf1suyyCVh6OjNBewdjL88cwQF9jnyP/HT2ufVExHDOEG08PJFlqq88V9MiYhqdyWnHP/DQGJzjWt2+hF8QuUvrJY/WGKxLnFbbGYXBDutFkFHzzZW1J1xz6RQ8dq5qmRrGLBijMdT0S8IIV/CJ0Ke2Y1xgR8Jzeb6XxqJqIJQDZwh/7CsPTHTmXF1Mi3swfezOmb1gLpTrDnFuTcy3Oez5l8a1jybItYmIE0E70ob4Vvuk9olpIhQ1RrAr82izME4YgUxLn3DKHTL0V6YRUCG6K4zNvIiYvNJjnWgTaa4yb6+PXqL56OcKPEP/2ZPadr6ZRfkWcQ7Ost4YRHNnvTFH8tJhknxnxtOH82hx0ZF1zSNiIkAhfMqycz4aAGNU880PvJBqQ/QLAAAQAElEQVRpb8rAJT6CwKa2yLUdAArXmxxQzVsb1sZosefqk1aTupKi9EM0V2cu3abHmSHCahmbm5QDd1nTt4ZtIFI1RBvECHBRewEeVFh1szh40iAJNvmYHdIVai/IGeFmYWudOh6Eg4OEYADYa16GbWbfBIFn2jkf0LaBja+WBQTMP2DEhrRKg80f6RkO3cGp9faE6wHZU18dZhrW2XcgyB1mEpVKoClXncPVCUD7FRGLCIA0npV/NQAhUIVau1ejp//WHJFwxDdoUP9bzxzmkIRm7boDPojfDhStK02ZfZqScWkQF1MaF6iNsToSYcjTHhntXeeZFPLd7373NCKks63c3xhkZ5MgIPPO+fYp5tceZasK6J6rA945b/mdWd73VmTmrEIWmc/H7NsHzEfEq4MQaXrsO2eo5mXYvqO1EKc9I0FKyaK0JWe8HU4vlXd+Me9gYS1nbOY5tRc1L8O+DzMJrlDVm9u+xgg5609yl/XMIZdxvjE7V8JrHAKWeUGez4gbyVnvf6ktjIu93Pc56aLvntsnpNQYIEQeBgIh3PsBZ3raUtx+w0CB+c6MdYx4kZnzvVu+cdQnfE5oRHiknyxjTTCnHomAhzL9KN8ZxmRG3P4u/RKSZT+YLBLXes4yTzlwzPnJtEt980Gr1eG5dp1l62uPi6fTP5jCJ/wgoCMBl4+JIWypcyt9aV+Zb+eESbGyI4cwdN9MP7Q3ozJ708BGcKfW1x/tcU0TRvQSSsBF4ukiYqKZRFOZ00wnuGFNkfHq2/d13s0zeOfxjFquh+EhZ4UgruetjYMfaIA6VnXtO0w9JlM8HTxK8OouE0EsIQ/NDfxivX17xO29nXWrD2fADwTCaJFOG9AUGFut08PgNhhEUFfz0DkEOpl2CAPg0FJTdqBm4CScOKDscMm3YbhaRnwLA1DrXhK26BZhhABsPovjUG7pg6QS8Q0pkhrgFh0WRKBNRW2I+McE9AMcEZNFhQi39NnLkmCwobOxe96RcdwvosRmcwgxCtqnEgOgAEHEjrQtzn6o5cUhiJq2J+zw0qhQV7P3A6SW1tdaAIh9PZwBe6aun3OACDbvmL46PgAN8DNfNX1NGEEMQEAwNEn6cGEMAbJnbtf0qYw95LwLV+c7AZgk1JjjIRYwngBmLctUCUJzn4WUsRNZ1pW0J4lh2qg5pF/bRfyYf1I0c8LUDoNcyxwRhvjMQ8RtgA5W1bXEwJDepSoXYrQ+iOe5cRi3fWgtETS9nLOUcyzPN7pThCgXX3LqgddLZWoewt389X1uf5GyQW61/CiMYEVA9T3j23wjAqrWgzzBw5pm3JjOmrYUJmV0ATjiZn2cS4IKzOtSvczzzQjuXt4cWzsaiyw78s0PQpU5h/zqfAuhT03LMLjibIAV6iO4tQVPOCtglDkzn70N34iItj+yva0+xomUFtNX27ev7WNMDby1td015a2Puellwfd6puw5gqw+DuUQZTQEyvR29sZpxWnT+7zSAtHSwB2jthH/tOk0SKTImAWaTgKN/p32O9ywtK/MP8GZtRj1J805tXfBA9rWzrgrs9Uhwo2ftLrWtT/6pVL58KY5IYgSrw7Toy10QaY7I9bNHGRa+vCCfZFxvrbRX6Tk4nMOE0Cw5EzNlZlLVwcNQLAacQNDsixbfWdxtMd8C3rH+jKRAiu0gzEbzVW2yQcP4Ula04StBKR17yvH4gJD4ayKjxz8QQhGIFDzjeutb33rhBaVfggDoKGI25MkDbDEAIwmSv4ah6gwMWvKHlXG4iPUIa5+6BFrELiF1h9GARAg3aX2xaF3h0gzFzY5yTCk6vY/W24qNFxaXyhtX8vpz+Y8on1SC8SNdartIfQRt+YSUpJn7jBVkAukJm2LA+B7PwjFnralzVrWoWOStGZsgJLDFHF739svJMMRN+mAIGBBLQlw1f4yjODDLGUcICQFQAADIKSNgDliGjJiFxwRk3lFVEEwNEnSqT0BkWzrGj7C1/f3tiEmfUNizH3c+TDmev4hUqYTzNYAKPujt+O8I3J8q++XDxCyy0fYY3ykLTnrgAB0KY2UHLLQlrMKqC/VXZPn3JOA9bLOuXmo6fqkAcHYM+0yPzV/FIZEScwRXBCOvZ/lnDffk3HnzL6lGj93Fsw3hJ51l3wmcfqvpojKg2e0WCSt4kuO9M53U0fXcsaJuCXwqPtDGRpjac62OIdp0ZZ5F19yCCx3eezTWg7DvubbEU0IcCZEtb4wIs5c24/iexy4YX/Wuggj6w1fsv9mxup5Q8SEuUNs1fIY3RoXjohJem9b3hqH8QCrmF1UfAQegY1g9xrYuKavURnnqTNcytkrxiCcDvEPFtj70pw5BPJewZI2Rg6jxfVxgdmkvSS8o3o9zb6lZaWxB7drPnhHGAK+Le0rZ8I6MDGq9Udhe535KpxDQHBOYjxqI9PQKmAmYjzT+BjOuk+kpUMfze0Vc8kkJsvyfT9TQOHqwD04tKYJgz8EBxVvSq/OmTJuAr2avibs7MFP/ftoc/Vt/61phyDw7/29v3d6UGepvHaZ4TKTsmZZFs1k3TPOtw4YABpIDCFBgbmAU9EMBILMh+w55bvDGKFH5B/CAADYkIKDWjuDqH1YTdsatgE6B7S1jS3lIYgEvpBOrQspM1uhgsp0T/VR83of26EjpeoOYLNoWee+fYdmDRBZM06bkySE1K6Wtx9oNpgBUMXhgnH9IzOQWm8pbC8gsGoZRIL0mnYX4XN70plwOEkgMHxzwNBY2X2Slgtz1ob0EfBCRCPqISEIgvaIpF+5+3IkQR0wGou1AXwgOQRY/WaEJDU4G3tMACSgTncIW0wDwh2SrfmQI2ISAYbxrHlL4YiYEIM0A9TyCGXaNgB+qd6ePPsCMdLrQtwEB3VOeplR3HojfJk1UpWTKjJvJC2s5WkazA2ifOk8gGkY1Fp3FKa1YQaCuaz5YDpkbVw1fRQmhWeTbB/3fMiepHk0HzTGCLv6HeAnaSoBCqK4t0eiZV6YEvmhvhHxbg+MxlLbwiCR1pFSRtww8ZnvjpU+IN5M2+MjABEnve6IMehlzsXN07kyo3zzhxnDBCDssgyhljV0fuG/TL+GT6s2ggvgSqct9O++DEkns1WEv8uao/2k7B4HBjkD9k3Wh2+cNf0RLGT6ks+OnGkiuIhBq2XNL60OAQH4VvNGYYQ14ciIKB6VJy32HcxSwA+MrT0+KjtKQyQSWvB7vnUBD3q6uDkCi+BB8eqsJaanpjm3GDoMcE1HqxCG1bQMg6dgUW8r8/losa3MD8GT9UC3aSMdmARm2W+Zds4nPOHmypkL8ASdALb1cuYRPdDTI25wmr2FWSH0oPlhZuQcLcEBsIemnvDwEAbAxOBUIL86UJKqucWr5TJsMhywjPMhgaUFVuYoR6VCfYigrwfVmBAjLu1V4l+/CB6HWPhIp0+HCyGNKIJ8zKVxkAgiApkR4fqYRuDybU4IqjsMDSky4AEQkVxcQoj378R1VuBlHTF+NCEYBHMGWNcyvY01cfvAfuhlAaKedu24tUGo9PEAzCRlgCwi6oQkzgyGNAGApjVB2CLyAMQz1e4tG1C2Fn0Axm+/9nRIhwkP4msknbRfwA9qXUQe7YF909sRl46IxyQ4F9K2OmMwFgTDCLGtaQ+ista9rDkwxp5+aZyUByI2P8Kj9sAGjII9N3cmfDsGwP4ctSENMUjQ0REn+I7xWFof9TltgEOY/kpQynMZEtFDIyPenflDbPY9hvGkPaQ5cE4IGOw3DBftKsKdZnPEnOoD8wNBEvKId2dOSOFIwM1Tzceg0+RgYGv6njDcAgnvqXuuTodH58rLR0TAexjNiBumx/6BX5iKkiZaE2Wv6RAlmKDeh7FY454ubj0Q1oQC4kc5QhfEP2Iq2wSnCA5c0p7bu1mWbz+R+ru/5BzUNfdNJL0EPc7alvklTLA2W9YaMQsfIZq93GVca2AfZntkoun7CP3QfsIjh+aA23oeegms6unoBPQJ3CrPHCGOzbl4d+YM02ot5ubCWatr2NvoccQ/s1OXZWseeJ/0VU0/FzbGEROknu9jqoXZsBekdYf4B9vAu563N26uvEzmmw5hAAzEQgPGwhwClr0r20XxNc7A1KtlHXwbraZdIwz4QayIAnZ02QfVo40MEDp4mZ4+Ds1hIgXPtDW+xccgmSPEHwIe8gEQmHNAmiRFuDQIC3Pi4p88Y2XuAclSBVHV4wAhQMCpO0QBgEaV55lFKqw1Y1xbBrFKbZ0I24YHZC4l+Hv/1sJ+qOn2TPZb068ddrAxYojh2pe9ijCpaWvCADNpln0GAK2pc19lML0uLvf+AZTRt2MEMUtZ3nopB7gxGQJ0mcIBhCPEkPWqj7ikFfGjQx1m1HJzYYgL48qfK7OUjiFHpCIKspxxANQutmbaXfskoOYFgY2p6v1HxOk1HIix54kjVBAkVNfi6SBl8I8W6ty5ZjppPyO2I24ISu2YH/ASA4eRkDbnmNqM9liWxwwwZUTYVMIq80d+REyYg07cK4tYc+7sRWFp6eAwRPAarUfWqX4Pg1nmoqfXuHznBJPp7DgvnP0Kd9SyGbYXwSPwN9PW+LTY1SQDgYbJ84oTodGaNo4oA9dV3Jtt+l5zlvFr+xgiQjKmV9kXeI+Qp81FlGb6nA9nM8sgDKqEtu+g/aIVZ4uNeJ1rYy4d3KHlgn/sk7lyo3R0BToCrmFrPipT0zDUtAg1LcP2JVyQ8e6D5YST4H/m2ZuEll7Yy7T0zTHBDsecC1N3Dt6Ad5gA8CLbqb7vdeZr2lyYoMo5d8m2lvGd+iAAqOlrwtYKjWfda3l0DFNYNJt5qnk9TMvhHDoHPW9r3H6xb8AysORNWxuYK49LA9zzQyFCm9sCzdXp6eoCYjWd1ElbNe3oMOBHQungJzIxFhPloJAILS0SMxfEC668LhKkafGZHDgILgBRx1FPA3SQFyCDy0bAQ7y44KW+jv72I9pzcGkUHGzI0sbGyR/Rdm3D3NoPNc1+Mc817a7CuHaMr0OVfWKCaT8yvtZ3GDFm9tLaOvdVDlAjxbUeOQbrANBjAjItfQy0PR8RU0RM7JmZy7FFZPPou7PsFt9csWVEmGK8RnWNC0FOe5aMNomh8WAiRnXWpCGCvfJQ9x6YQStxbXh1bnz2EkTG9hUCxYwjJM0FczNSJ2V6O4QMhAWeq4uIZ9nKMgOBIK39s4xBABwkTba2NRvid/eBdpWGouaNwszFEAl1j43KbUkDp7Q7+gZMCYIIY5FtWk+IF8zeovbP+nM+GFH3jXLgGhMIRDfGBuHinLhrg4B0XjjnZQ4/mCv7z3ppc61D0JoX+M53EhbZN+ZrbRtHlLM/KyzNNhFLXMav7TOlyP1rTOYFYwhurKVnSJ3dJYHnjdf4CcqYwnpRxxm5ZH7hHmYjYOcI5upzydkjYNhSGfuOCU3SRLWs/ep7wJOa3sPurhGQErbAlRhL8blvNy50EjNRFpusSwAAEABJREFUgsw1820uEOgjgYd5XzM/zj8BgDOW3+D8s7Rwl8KYMn2L/3M/93MTUyjflfWcU4IvTOYIFmW59JUBz8FNQoFM3+rDAWAMnAmuqX8YA2Az5c18khvcMmJWJ2udTWXSa3mAklq9ph0dBmTd0AZ0jcGBx7kjzHHxa/ozoSTyJGhscSENqnYEvjRSegtujtZs6jV9PqQykBLEgZkCKG3ao8dnbbiKJBzwOWBydP+9PeuI2cnD7WCT7pBs97Kvp7jvZYaBkMnvsi6k4vIy7S58+w5R6clCkiOIwO8aIGCksYVkg0nq5TxjtBE5R+wZhBPTkPxORC5N4BFtZ5uX+NbCnJDigXHmglnPHFx234RmUTn9OluEOAgNApJz30WqCbnXewPOBHjKhpz5jjOj7XPO2EncMCvaOFf+XD7kZ90RJL0sjYULuJX4x8RD+tKtc69zSdwe6ZJTTCpVv0ulvn2ufUw29T3CtJeBJwmcevq5OJND2mGaZbAb0XOuzjXyfduIwKH5nWPwrzEOwisOjLMHmN4xNdrSlzlEQyB4afbNL1OatfTEmr6cJfDM+UYgokEQ5PYuRlA+5p9g0r6y/9mZs3Lw5DVa5Fw/tGURz4UBWZ6gj5T+HExQnnCQyaWnzp3pNXXU2+Ksj7mu8Fh980CQIDznWEVgzKqmAy4DO5lNmbu5umvSSfDRwyw+nFsCYcLeLTQSPGfdmKFb404nz43DeSKs07/6YHmlTw5jAAyARI7aF9dIcr4EyJTvDrHfgT2keo0NU/umuUCwU50jEgBC0sE9/Tr41N8O19bvr2N6Cr84A4hMe6QyAOJUdC+WvpsUmh226w4zAAzY3Vr3uxnGnffirEMseV4hb1KeOx/Iax0iVBH9Lud5wQvwJjF5LfsqHgkY4imJE0QdKddVOruDRp0j0jJnCtIkzccUkGCt6Z70LE2LmKI4D6Rn4CniY00btQxEpT5TAAgZ8qz558K+A0Pu/hFTyTmcxKyS1F17vp9UlaSdRPAaZ9l30UbBbfoEz4xzzfkhaFMfYle3OqY7CIWa9pjCvsv81zGbGxo1DFJNv2YYw8cU06MBHjPYuwecG/URe9q81pjhHgw6JsNjJO5SMEGi5cQcEEzSLGHu3Gs4Z36X43R+nON+7hCyhAi+L8s+BB/NRdDgbBFegGck3nDV0vjMVzL/zhB44ccW4ZA9NGDvSxs0DAhwJt6EwXvxBM2RNSao0SbCHh7GVDDD5nt8BLxlXsS09sM+7MMmwhc4so/tUAagN7417qDj9ms9G7BKGmvekWHAh3QIAX9ku09tHTcDABJJXgVIgNFeAH3EyBxuAJ5EhQnZG2X/mHOXy71Iwf4S8F2LWI6Y94fQhrUnUcPw0wQxk6GOfghj2zMG60dT4u6RF3y2SishTkQzKROkiiCxL/aMJevYZ0wBmCd5mYek0zgxXyTppJ2YT5I+MNz8MwmDHCFK5hake9Kzze7bwxAmYgFyZud9FCHd+8o4CTMGCUzTl3kisc38JR9zhlCpZTDiBFnuxNT0xxRGJBt/lW76Low12uAxfcvrYazgm9884uf3WA/mKxiATHtIPmKfEJfmggkTxujc+MAt5n/gFvgHXqw9i+farvnOOzNIMK2m7wmDf/ANwh6Dx8rEXR4+rQVmz6VlAoOl9h8UA2Cj1YMOEJgsnNzSRzzlvTFmwP7AENoXvph0COInHRR/cnc7AwgOJhIujDL9uNveH0Zv4BOilxkJNfTDGNX9jAIBTkIFyTmrR48Ccw2hk6Qxp2BjjdHwTCOJJ7ttv37pF3whR5LRNWNAgHtKj9R3JCVb08bWMuaKVgKzhUlhJrC2DdoCZgBVEMIsiLnUNeZ97bguLecsYYx8S7ZF8s+M5TF/V37LY/Td36JJJWjDcDPhwZBbq8f4PaMx21tg9xXg1qi7B5X2oBgA9lsIugRs1JyIOwv0oGbtaTD3NgM42tQS2R8kFNLubUBPHT/NwNMMPM3AHc4AeIfYT8EYEzSST3cI7nAYV+kKwUkT78Ujgh6Xk5k2XKWzp0bPzoC9RprswRIMt/sMryfi/+wEvM4LPCgGwMbysgaAZt4BONIO4Sf3NANmgOTMJXNhzCJ1uPCDdE+DepqBpxl4moErzACJJULZvQH3jlyAfL0IypjVuU/i9RmvwazV5Fxhmp+afJqB1/UMPCgGwExTw7DJZFf8BV/wBZMLDdKf3NMMmAGXLtm2+d0El1wuvaGvzSf3NANPM/A0A0fPwDXbQ+y7D+F1FZfeCc+u2d9T208z8DQDr78ZeHAMAG6fyoldMXtPgO71N+1PX3TJDLi04/kzau9L2nmq+zQDTzPwNANPM/A0A08z8DQDB8/Ao2juwTEAj2LWngb5NANPM/A0A08z8DQDTzNwlRnwo5JebvKy2lU6eGr0aQaeZmDaxQB4ZsivrnkxwcWQN9I8vpEBk7X2WoUfXnrIa+5FEE8Fej3CD5NdOlbfrc1N7RxQ+KHtNc+dei7xGnPh+UU/WMKW+Xf+zt95wOw9NXH0DPyf//N/Ju+IX9ou/OGuFzM+Z+vS9u6y/lFzUMds73t2UNtrz9a3fdu3TWAxE6Da1l2EjdPLV9c8p+4BetbQZWdPHroLcBfftqYPF2G9SHU0c2I90VT3saZrvntUJnHUEevjh0QfOm3hx8/89s/aczqas4eUtpkBALD9Op53mf1Qhh9dOAIpPKRJWRqLZ9sAptz4a4GAXxP0gzbX2jiQqhdx/BjS0vgvyfNLn5479D74//pf/2u6JgLYO04/6ObHMPzwCTOyf/7P//nepk71fKP3wT0V6K3ua63fqbP254M/+IMnew0S9E1r91pr5pAoAP8pn/Ippx8U8Vb30Wfer896ztH77Yihh8gIuHjpB1zucx3mFtM+9UOG/Lkyl6b7hV/PAFof52xve4jXD/zAD5y04a4XRp1J39727rJezoEzsLQPto7Jm+V+f+CHf/iHJ78p4T3vpTZ+z+/5PdPf+Tt/Z4J/EY1HjmWpX3nmwI8keYr0aDigfS5/JM1FYD9m5XUgZ89TrfLv0xnTn/tzf25CDHoT/yiC3W/JoKnce0QrXPMsHzV/zjEcletzyTn2ux2YS3SMt/iPGuOR7fyO3/E7pk/8xE+cnP9r7f0jx3uurc0MgB9eceHIG+waB7ggBVz6UQdBu5c6hNo1D5AfmrDx1xJnntHyK3DeToeoL/2+Wt93+gVU72DblCS1Nf+o8O///b9/iojJr306oBDPQ1lz4zAeL2NgTn0zotI79Q6s+B4H4fzxP/7HJwjX3RSMAObH/trT3pY6b37zm0/FIRw/gmSvOWd3iexPA2h/nHnv/ptv896yL4pGxPRBH/RB02d8xmdMP/qjPzp1RsBa6te6XNTRxsr2Oyb+wz/8wyfI7iEhaEIZ92GMyd7c+GmbikfE5Dz87//9v09IcM9edK/Lj3fpGBz1S8Ha87rXY9AKRMREuIAAPEIa6MnLJHgJmDDb9vgaxujNr8IIRCPYoPxdnYuImD7kQz5kgvtZA3gb3npey4Hlzp4foEIgYh6v1dfads39X/2rf/X0UIlzdwlO+It/8S9O4Kq+f/fv/t2TX+F+CLDeeJYcelB+ro9zDG6jQ9Al8ra4N73pTRM6xnxaZ3B3S/27Kmut7H2MwAAGDofhXBMiHY0za2fm3EMpHtMRrnmj8GYGAPD+tE/7tMlzjNlgREy49K/+6q+eqAYzfatPwgyRXTpBECKASJKyZhK2jNPbxLV8Jc68WXxOcoO4gagB+Eu/M8fhsGBGxBHnmAE/hCN+pENce5pVmxE3a44Yuk+1nTlk7kMSBhFaD+NLh/ECTPfug/e85z0nQicZXoyAHw1y8Dtxmn0e4fs1Q4igtuXbnDN7e81eq3UvDXtt6f/+3/87/cZv/MapKWMx384rYH9KvOBPPvtXmwBkMQIeBvADU/Le+ta3Tn/5L//lCSFwCaLR1hZH+ph7316yp2hlzp33LX3sKYsQ+pqv+ZqTpsia0NBdqvVaMw4IHxFME7oHlv3Ij/zIlGdKfxFxIoB8D60AcwjpD9khADGkYMERZ6B+q7VMxoi51Md8zMfU7BfCWT7PBW3dC4WukBARE4GL80kzdG2CLSImTGP/JeQrfNrqJsHpxAl798Gf/bN/9iRkyk4jYkLHHMVkZrvX9iNioslAHMNRYMSePiPiGSNwF/tq7xh939o1oj1IhhENCI/s6XepDlrQLwMTfAovlZX3Jn+2OsT/537u5071V3u1gThiggJ47/k4APWv/JW/Mvnlub0HSb//43/8j+nP/Jk/M/lVyDWTYOxrXXK8vTyEyG4RUdLzxL1Z/8u//MuCE2CNeKI+9DsHl7gf+IEfmCB9/Z8af/WPefwX/+JfTNRpr0YP+48IxF3mD7VpmNTDO9TWXfyuHG4a4YHwZ+7jm+f6hkgRknP5S+n2+t/4G3/jpJavzB/ilLkKYgXRcquNAyK/9/f+3pOmZdSUtSYpoYkb5V8rDVBnvlHb/32/7/dNtAGYf3uh5m0JA46+a1THuXFG5DGL4kc8RzQQxDWZMf2RxjF9+7Vf+zXRkyaMRJKQ4RKhx6mxHX/sf4QniVud99/+23/75FlIJoE7mt1cBTEGljGTO0ek1sZJjfMH/Wo6psBaf9ZnfVZNftBhsMDZsB5HM4TwDdjK5rxOwvvf//4avRX++Z//+Ymm8lbigRHt9+Yi4qQZete73jUxEe75R8Xf+973TpgbeOioNo9qxz5gGvU5n/M5m5v80A/90CG8h9cwmX7vgb+54XuqQMNnHxCcXDKEiOf7as+8XtL32rpr18iZhT8wjARIR9MO/+k//afJPQp4lBM+JwjexQCYGE8xkjwB2OLpELcIMqpRxHimb/EdJB/zDd/wDRMJ75a6ADHCPyImk/C2t73tJC2crvjPHCBGP+ETPmHyy3lruyKdxqhc4tjNQfq9T4j5H/yDfzBh1HreJfF3v/vdk8Nd27DOGLatpkf2yBd/8RefJB21vbkwiQhJ0/ve976J1B/h4fDNlc/0nIu9RBGtF/Mf6rvKBETcEKGYTIRY9neE/wf/4B+c2FeO2sL0GQ/mZJR/rTTzgKn8xV/8xVtdOPMf//EfP/ndDnvhVuaFEVJ22i0EpqacZ0yfMycesWwypMxRDkLrPzx3qdBjy9jMrXPG9prmjfQJjOttYAiM1XnpeZfE696v7ZDGvuMd75g6kVrL9DBCzn7q6QgG+APD1fMeQhzsmRvHr/7qr06Y8rn8renO99/9u3/3JBDrdRESPY12zhkkAbzm/KW50qh/+OHf/tt/27MOizt/tLKHNXhgQ+bf9/+zf/bPNreKASDUGVV07r7+679+gn9G+Q8tzf54+9vfPiXMXjs+Z8sc9vLS9s5rb+vSuDGO2rBG8BKh7ihfGvjwm7/5m4InARJNCasKAixCj0scmoBlTqWHhGmD0dKnTgd/djMA2kL0AA49Q84AABAASURBVP7C1UFK1PSX2AVqgxkEyeLaiTEJn/RJn3Qi/HM82sEJLU1Clt3r2/A2+wih7W3z0noIJMQThujStmr9b/zGb5y6FFg+0yNEqTUTX+PcKfAChnsRgNuIYKHdYM/2Ez/xEyepFvOmP/JH/sjpAC318Vu/9VsnDZXDRRrGfAMhuVRnKc/aurvhkJvbWtZBowVgIlPTLwkzFfuAD/iAF5oARBDhiIMXMu8gwTpBRn0OIuKkcdu73zA8/XtpmtiBVqZa+BM+4RMmcAHQrZ9McID4IFm5llkaG/URA/S3//bfnvyAISK9jumIsDNC2EIanIQ9uLbUNjtazMJSma15+h/VIY0F/0Z5c2mIuD6PypKOsYMX3uus0T/6R/9ob/Vd9cAFd0SOPJcELVsIeTCOQAWs2vURF1ai+b/kEuiF3d+qDpcQEm3BR7ca2BHBAO/5fhpqxOCoS3DW3iIxHuU/xDRjTkJ3y/jUUbfX2TuvvZ1rxr/iK75ignN+5Vd+ZVM3hGfuVF0iBFZ3ThCMNmGWhxEYDexNo8S1aYhBNsAQda+j47/wF/5CT94cJ2HzgWvcuUn4x//4H2/u/9oVaDki4kTQRmz3//7f//vTCODbkCRpCKajvwEDgBDt7bLj9jJFT5+L59ggfJIujABC51u/9VsnxAaAgKhysP7wH/7Dtxi72iZi3wVC42IKgvlETL700kvTn/yTf3JiX/nKK69MiMNab2vYPOOyR0geQYYwPUpNiwGguehj/KVf+qUJQ9zT7zKOCUBs9D7NwYe+qsru6Wvi6kbEraLWfyRRtQ5sHJ2djjAi4mSDSl18jfPu25cYoH/37/7drW+oEc8HYmgQ5kuMAoKA6va7v/u7T2cbUcc0EnFc21sKm89rCz6W+j+XZw1/8id/8oVimLiP/uiPfiF9bYIzjmGiKbzG+s+N48d//MdPazWX/0ZI//Vf//UH8ZmIf9plZnJMP5fO2pEDHtFBa9r/03/6T09MKUdlCVgJVZyXUf4bIe0xfPv73//+B7sUaHGvVo0GeBEDoEGXwEbEgLyRraD0+3CIQch5rxnIfYz5kj5J1651cL72a7/2BTMgY6XCxM0Kr3EI91oOI4DQwTgyY8Ad13xhBJ9vwyywySZ5RewjmL2kYI0xpspewyH+9TtigCCaD//wDz+k25dffnnYDqIJgzTMvKNEd0Fo23p3EKC3/Hv6mjhtUC9H9Yuw6uni9ra1HzEB8p13BIDw0c4dpRHAtw/nAK0x2M/OBym+i80k1fYsm2ZaLqY9vou977/5N/9m+oiP+IjJ3Qh155zz4C4WLdeXfumXTh5SMC+/63f9rpNNsfMwV/e+0+2hDgN879IcLo0Z4UfyTxvJvBLhNCf5Wmrn9ZKHEfrYj/3Y18vnrPoOewDxT2AYcaOVZKK5qvI9FWLKB/f17sFTwoZr4rPe50OMz9GXD3Gse8bkfiihZUQcLgj22ALBJEHxaGwXMwDUv6RavXFmMd/yLd/yLBlB53A+S9gQgOQjzk8OqRmp4ahpiAbSdahG+U9p62eAWQ0Jfa9h7kkte/olcRerEZU0AZA5TYALsm95y1umT/3UTz3dBbik/T112dmag17X3hoxBr3cmjhtSi+H2DMXPf0+4mxxEei1b2ZaW01Bsv7oHovLv4Bjluk+YplGBiHZ88RHl0ylX+q+5Eu+ZBrBPOtjDta0T+LHbAyMZEpJywU+IoAjYrEJCJHgJc8DZoeWi/YJ0cv0wdwsNvIAMjHTfY0IEVyu3jM8l2X/2B/7Y8+qmheXMjFTzxKvHHgozTN5ZZLIFptg4qGM65rjcF+Qhg7xn/3QhP3Nv/k3J+abmXapj5Zw1i9tJ+vb7/Z9xtN3zjH1GX/MPvrvjbIPH9I6ERiyqpgb08UMgIY9U+ZQCKcjxfI6jLiFRzT5gYtrSuBJ00jh9FkdCRlJGBvwpcmodS4NU/OTRl3azkOtb2P1sbnY57KOw46Y6flr42y4mfIg8hGGH/ZhH3b60RtmHWk2tLata5RDXNGCYHhq+97zll7T9oRd4mP61utihsxNT7+POBv8SpxjfD77sz972mKzXMfN9KPGhV10PLfeiEhmH1Tl6qSzNvYjMxBMCRiUeUf43lzvMI95lscAjmifOQWBBSaot0faj6h5KOehj29tHOM20hKzh96KJxB43uOOuM08MZvyShPmYO24Hns53+oiKtU/nHefEnBMLlqA2eIWRxM8Wgfpc+3QTDKn6fXsAZqxrXuqt5NxWsku/Mi8rb4X5irTmvUxGO7wEbBm2mP1CTcIjK6xDwk7mKEfDd93zvWjq3YIA4AYcGEpvx7S/u///b9ndPJCBEDkh0OYTxx1EJ918GqAuhOh+Grw1n+qera3/+W//Jdb6deM/Ik/8ScmF2Lv2g71mt/U2/aLlVV6Z80RYjQDlzJ7XgLBsDHz6f0+lLg7Fr45x+NCqvf59xLA2Q7fvQUmHMLV2csI3pq2FMaEeYuZNHCp3J4838k2HZFuH3zhF37hlG8bQ1ouBK4FysqNGHdtjzQtfbz6g/ytQeYxE/uFX/iFiQSUZPxo5IOoqcQ57Y9xkEDmGNb6kD2NqbUltWXCg3hDCNc9tra9x1LO+e6Mm7Ez34Ev7F9w3Y9b2cOEC/acvYcIZDJlna0DfIPQU787+wtsoiHuedeIg/9goPFfo/2lNv1OiCegfbNyJOAeUqAtEr9Lhzhjykhr6VI6yfxah1YYjVX6XBvMQEd1pBFK0Y5ZG/G7cF7gI4BY6st9H5qqXgasZ2rY07fE7QGMMX9LvSPLovXMu3VzJwkteFT7Lly75O3yPVOp+zhvo2+xx+7r/I/Gs5R2CAPARs3CetsZYHZjHTLUsQNAEp4I3kH0hKiNIb+6973vfc9+aKimrwn/9b/+16d+kBAEEAbCZE0bR5UBcL1UA5EhQHDAR7X9UNoB3DEBxkMbkGsO0bLhd+D9HsNondXhSMyPkqRo7y4dIgRTSU1LEmy/f8ZnfMYhQ3CRlh1zb4x5ibPW00dxwJCpCoLAKwDO4ajcJWn2NkINALb+2kJo02C4gA4IrkE+kOCo3OgCsD5GjrYRQSgPQY2YRvT8oT/0h06XxyEfRKT8I5xnOJm76Ysjzaa18h32Apt+4TV9ff7nf/6kLCLpkz/5k+/FrG3NONeUsQ/AhbUwj0YL81TbhitoUK0n+I3wJ8HFCGAI7GlEoD1OU2buRucF/MccYCKtlXLsrWtf1wi7xGz/YwaZpejDj2URGsCP3cFPcIVy1fnGXjbj8mpZYaaRzmTHg7Sod/nbEMYC7vtdCK+2YW6Z8Ton8u7LeSSEYOku+gfT/OgT4hccmuvTfhw99kBiDn7P1VuTDhbTyvLXlD+6jD2A1kPzaZtQg0ZIuvhaRxhmPmt5Z9kz5/Z6REysBZyvrW3XNo8Kj87/UW0f3c6QAXBJjVlPAps1PltcZgARMbG7zDqQokWqA0ccj4hDavs9QALHZYNE3Fb/UqF5BaD2fe2wjQn42+z6QoAAAiQh4t0B5DlXe3yIMfvqbV8zDqliukgrAXrSCkQmYjPHkxceIerRWDriH5V5yGne8GW6gmChymUalONldsBlfItv3rpNqLlCLK1px3wbm70VESfG+NM//dNX/97Cmj6yDCluMiUIbIQ2qSPn8tEaJgDhMiLgCASyn3M+gt+dEFI3BDW1eiIede1JF6GORBCQmR+s4pwFY4BsMUBeKRLW99Gu742j27+kPcw/eEwiT/Az15a1oZmB3C8RAlQi3ytgNCiknggCl65pBWjUmIeCTbSLc2O6ND3r6wseYI5C440JYM7FBNYdJueyOozfaP+7GF/L1bC87C99e3zUjnzzDQ9ZG/FrO4IBTI0xYWoJiWjpwAvaQmvkzETE8OKjdRyNUXrEuE7Ecrr9gGgctXt0mt+ooZFA+7zzne+cRkyAfYEp6X0zJbyU+P+iL/qiyW+mYC6YC5rv3s8ojlHFdK+lRZhk9XasOboEHEbr1Xz7EH0JR9X0pbCXBdPkkjk3AYOz7pGEWg/etLeW4E4tf63w6Pxfq69L2x0yACQubFABsAp09oRJaEaDtFiQxBGvFJC421i1H6rl//bf/tudP81GSkWCW8dibIijEXAGyPfMa9bRFwK09rcnjJhh1rD24CvnRy+YV/HFR8yePQSYbTnwe8b/kOpYa5ImTnjL2CBoQLjXYQ5Dld7TexzhgblGiEXEs2wEsXT5zxJLAFDeyvRb83Qk4IQAgH82iwnADDMPJImdc5iEEZyAXLL9Nb7LtIAvjQQNVI4jfefQdx61F5nnkHBywta6MkAQMESc/R/l+82Eo9o6sh1CGNJ5bWKMmUCCD+bFLyZbQxozd1mYCnqtBbyse0bd7uaIfPsNQaBdLz5Ze8Qm5heh2du5i7jzSyAScXP2wD+EEDxnXDRVTObuYiy9D8QmmNTTj46DMc5u4iVEKJNYwj2vnQibC3jj6L4fSnsEDbmvMQGEov0y+l/6S39pck76mDGpcGZPXxv3OzGYa/BXHUwwQShzGfElh1F1ZwrzljTGkj+Cs9YdXYIBGvXlTCDoEx8QnNGiozvtnVEdab6HwMAZM6acX3npzKd5lp9pd+SfujF+MDDi+flPIcCpwOCPuaYFBMf2OgzXaD4G3d1KGjIAJFkOKaR+q/TBEcTvmk15rtt62JSlSaB+pYoXv0vn4HnJo/fpMFjonv5Q4iQrCEzSKIdnjxsRcRExaWuJ+Hwoc3DEOEh6SBodRo5JBAn52oNNjUlK2MdC6kvDcq4dZxaSjbgBQNlOxPKTeIDvJUw/4oKpQfaXfkRM0gHGOSc/4vZ41Ydc7J2tzllTf+Qgn9FexHRtkXz1dTDvCFJrnv1CWOABhJxpr2c/pZ75jeAd6SfkhEC3jl4/GglCsk76bPshcnuZ5BYRk5L8JPLf+ta3TvrA7GIij2Lscgwj/5zZojn44A/+4FtV3U1DBMBTCHD7jDZPGq0UU5F6oT4rM5uJiKGEXF6WS18b5itiXMc83oUE/J/8k38yIQBzXHxngUYQ0wcOSHu9OmZq4GH9PvuXRtgF7UzHKPazQNPLWqDDl7VxtJs9henKfviEH5iANXOPbsK0O4PqHu0ibuME9JL9cWk/GEyM/yd90iedfjT00vZG9c+dfwKNrvWAcwgBWIOM2rQHLqG7wFXnDeM1an8pbcgAqGAjsecmFaRuIbkgJV4CMBG3AY+PJr3RXnVMhXCZnr8iIap5W8NMLyCGWs9hcSehpt1F2KUUi9378tIFBEUS2vMA8ojb8xaxPu6w46B7u3viiFXjcZD21F+qA6hBgEtl7jvP/t6qBbHXTu7//b8JEdi1ICQWVJV/9I/+0RMj5LAuOcRCB97mZS2QAHwiQpUXHCBLW4ZJ6ZnO+7WYfvufaY75qf1iOOxd2o2afs1wxJgR2ir56msI4WNk+titJXv4veZAfuCut/lQ4853ZYBG4wRb/V7WAAAQAElEQVRbSO29ZAQHIObZKZMA1vKkppgyzHNNzzDcxNZWPOLGBpjQh1mFtGs5BNpS24h5BE0vQ+NN+4To881sv5msuSviHPTyjzWOwGTaA171b/CdH/iBH3j6fYued1TcS1CIsKPa29OO77d/e11z43UmBKp96uneXoagx+X/Dl/WxufwR0RMNA6YgN7nKE5Dg1nFqHrcAl6j0USoRsQzppTgsNcH09ElEc/LRdwOM0ly0Rk8cNcLPCCAJLyt7TEPdI9Ae7X/Ub+sPsAF9/NqG0eG955/62I+MeFHjufStmYZAA3jBBHpVKu4egT9HEBWvjqSLxw/oqOmW1DqDoeU2rzm7QkDuKRKWRdzAajahJm2x6eeTBWV8Jo2/JptPfg2t3e+MSmQ3bnNs6aPa5YxZ2z6t9hqRtwcbHbQ/fAaq8MN6ECAXoaR9lAdoAIIAXJrAW4tN0cEYgIAdqYP9/3tiNS5C4GYAAD0+77v+6atTD/GsX+bs4jwRchhLjEeEMu//Jf/cjLHiEVzM9oXYAOEFXGzvyKO8wHhkSQUvDta8gUGMHcxt31+1sTvC2aQVCZj65U3avel8Y6knsqD9whzuMMldngEjET8wAHOnKdzvdikfDrnBTGHUMq09DEa2ulEJuELTZb8LHuJTwOBADIPNHMIuLn2pJuDZErE04GBLufSVHz7t397Jj9oH/5GUMGBBFfWas2ACRFeeeWVW0Uxd15pITx0P+Y973nPrfyjImy/rT9G64g9wJTQK2rWny9+bqwsGhJu1bKYXkJAc8NO/eM+7uOmuzblI4ygRTZPdWxzYbAao4p+QbwyS9oLx3of2kYXeLHKPIAHTAYxib0sARKarvbPeqSXI0iCN3r63jiTRvueW7P29tzoRwytPQGYe3jOQh/POc1dxHnch0FCv/W2z8UXGYBzlefyAUoIn3q2loEMEcQuI9X0vWFIyUGCLLIN3B8GI+N7fONHtPA5/XBLbTnYFVnRfLB7JQ0wpqW6DynPJiIldokOMHdQzzFAVO+ARFdBIQARVHf1/N4R82jfImbt1SPayzb80qPLSwiKJYnK6IdfzCPJUcR5QBBxvgzTGsRujq360rcy/TRftBy1HWH73rjtKXGIn+SHxLciEupp+dW5CHcfv3hsv0N259Yp4vk8f9RHfdTkbfA6fmEElP0EdtCgSnssjsSqMrejNarfgvjtJoAIXwjehWjatZdffnkizav1hO05r/QIV8cUjvakpoE1CLy58RA06AMyVg8Rj/BST3yLY8cOrpsHiB1BsFQf0Yy5yTJgCJMElzD/43/8j3d+Hy3Hscc3Xy7nw3/weNeyj9qMiMkdGEKGzEf8OE8If/Ag04/2CRcQkGzAmVrYI77hkn6cawSw9SewMA/n2kOI1R9xtAfAOsJBhHcSqPYnAUhtj7aPQFNZRGfEcxgTsS4Md9U2a9hY0EqYlJp+X2GwttJq4AMmpY7HmEdEc91jWR4D4HGSjF/q/6t/9a8mDCXnftnCvJ26smb23yny2p8f/dEfnQib4IERc/NasXvzrsIAvOMd7zg9y9S/yuZH/CdB0PO3xgHoiggQDSRNW9vp5RHybPYynZRyCQBGxPTxH//xJ1tndRD/JEYI6KO+VbsP1bF5xzDV8Tm4pF31gNf8uwhDXn4k5BwDU8divfZoQSCLERFoHtgNknZAJhxmCVKsEg1jQCgiOISrc3GSaVJNeyhhcwzAVcLH2NiPft7nfZ7gWVcRZhYmdczwXfsQ09I69fGQqjG9qumQkR/qqoT/j/zIj0wPEQnUcWcYk5hh8K/btWceH6Fo/wtz9rwnPBEyiHFp5xwtg+ciaznaY1rkRLwIOmeGpL+Wy3D263leTIV0Z4rJBUIcIpe2xqnX13Spnjlg3hMRp2LGQoum72sSvqfOrvCHVDYFOoiyimfnuoMDnJvMBwNoFK1Hpl3Dx+S5ZFsJdNpYd08u6c/DCb59bRuIUnQAIlud3ANesak/QAr+d3pCWdYV9q2xuzf0gz/4gxPcqq01DhP05//8n3+hKAk6JtjlVHC6M9UvVLinhJy32j0N4givdkJbHQIH/hEOXrMOa9sCI8GpiJvzr54foiQc80Ki+EN0hzMALnvZYAk88qNJMb3KY5Nn2qW+w+bQaccBAnAhCPFLnMNpQbMNfSwhA/kuYSiP+KfyfqMQ/wAOqQVk7fvTIVoRUhm/a98BRnyQtDiYNBFrx4AJ2KQFebVhZi0kGK8Gb/1n9071vUYLMrpAqDHEPwJG+KE5phgV6Rufs0jl7xyILzlrU5ltZdXf8gSoOvflSH0h9I68mAxQ+146LvCktwE2Mcvs6UfFSbpJUbM939bXKPP4yqf033g9dwk20/jIX+Oo+Jla9LLGQYvwsR/7sdOXf/mXT0wFIp4j2SwP+WOyIe3KdOWZpIEbaamyfvcJl0aMaS+XceuRBKg5wNAwGyD9zTKPyf+gD/qgk513jpk2JsNzPiYwzbIQ/4QciQMwR3C/NV7jzP+oH+m1PkbTRfO+P+1ZMHwL3K/9wR/2Uk3LsPUdmeZhUJMwVWZuD8CX1WxZu7SFVWBi/LQOTCjXMALGSwKNFtEeZwwYChpd2of7xiHGmL/vQQtujNXZc53hMs++o5YT7vSGNIwO/wgHfm05/zSEufbwl1eOCBK3wMAjxr21jUMZAAuM686JyMFYQD8cdaQ0GGFn0rMP0v8jiH/tIeYTkIljZmxO4ZGLiMmBpapi648BQkROb4B/I+mn9XbA3SW4rykAOBFnAAVVK0mKsV5jPIArFXfEbcLEJSdMyFoigI1wBeDGSirKbE74oTlSUqYf9awYI2RGZSp8ziHQOvIm9WEXea7ufeeDdyQ8SfjleBCj9t8RMMD9gWw3/YiYwKSMj3x7ktTPGEf5S2nMaJKgV05fHaZLT0c7EBGnH3H07CnJP21v5q/xzZW7IARFtXxETO4C0OQxS6p5wmAuIgdxP2Ky+95UZ41jy49pWFNWGRoAvvF46YbZk2+Sdt+OcAIDtWUcXeJPI3Cuvgu+ytj/7hkl8S+NNvibv/mbp7WPIVQNlPrppDPJSYfoBt8zv/rSmeSgFWr6mjCmHvOZZcFhmlxxvrhwdRjziJiW9gCBmf2MXsi67s4x/cQgSbPvMj8iTvelwBPmJMxSlOnOfJuTTAdDnX/MxtazmG0c5cMRX/d1XzfBC2maNSKurW3v0zyb754+iis7St+T5ncsXnrppdVV7euImBD/BNEEwGvx/upOrlDwUAbAJsVt9nHi0kfAuZfbEidVTaBr0gGYNRLHNX0AKnkAlceVLjEAyjhwLvdQ+YqvdQ5tlWhsDWO4ALq1/R1ZDoENUNa50r6LtH7jQfg+HPWpsSH+s3+HmURqDzLINkY+AotdeyWYlMMEfeVXfuVUkaD0OYeYJkmNuM1EIIRJ0+fq3Wc6lbOzUsfQkVnNG4WZDThfNc876ZBdTXuIYcgYoVjHZt39SvB9Mr+If6aWJIJgch3fmjCNTmVEnW9EyVJdJk/vete7Jrb+ewlfAqKRuYz9MXpZh9Dnne985zRH5DibnTlb+obMcxbNQcTts5j5c37iAPO+dw7m2t6bTgLOgX3mY007tHKd4MekSz9XH5HnXIxMca0Vszjn+1w7R+VjZJLo3NKmu3twRtaZk0Rnfvq+jfBjbg8waTOmLM9HKKojzOnXQwXC6SJi8jqQb+lnGgyG75wT5Y0BDiScEL9rFxETAhpDQxNEKEq7Xc8wwQ9tQB1bzc90cOWuGRjnBFwH93IcC/6zLLB/TuvzrNAdBzpd0rs/jAFABLnsVIkundkAkJFNLn6Es0CAUR4SktajiH8cOqKkj3PEnWYZgB/y2nPg3GbHBOx1tBUkdDmW9JfGm2Uu8a2B7+0I1oF14C9Z767m3cIU6ZfUJ4Fh/UaSSjfxjb2mXxJ234VZQm9jK9NLXd0RA6TzTd/0TdORF5v6OPfGMVLM/fp5N/8VmZ1rf2Rni3gaSb7PtUXD4wUjYztX9tJ8cMI+68w3dT1YcGn7e+sn8U9ib21cykQAbmmPBiBhq3rCiBLhkXPR0zlg7z3K35LGDALOWKpD4OM+BSmby7VzZTHUe846DS6J3ly7o3RwDwMEJo7y7yPNS04u4dOCeCyjE45zY0JQ9vWGYypTOKrrlSdPnIL/o3xpGBG/gwBOYJIJsGhL4KuIOJkdRcTkdSjlu5Me8bxcxPkw+Ky/3tZcHG3RX/Ih2ACX5upItwf8xogLn+LdYSwxAOYy89AuhERrYDwCk5VDb592O2kW2gfahF4m+7sLHyFPEGDPIUAj4tSt8YOPLvyjG9CF3/M933PS8JkbMOtUsPzxCtWauSlVLg4SamJQtjTk29z7tJfP7ZPerrmAM7bQOb2sc9RxkX5GadLTHcIAQLgGQEqQDfNxojb3UcS5NjncNSQlzH3Hd3zH5GAIX+ps2i790CZkyh85F/u8YzvKu6+0pfEeMSa232w+a1sQs5dbSClq+tYwZLCXIWImMCL+jSFi/Aa8vD3Ovv/ET/zEF8wxSCYhgi1IR1v9sLJpJFHYM7Zr12GX3dW4CEHE/xaAXc9xjpkJgX2U8TW++UNcQPZ+YEl8Tb29ZZhVdCSx5/v39I+gS+1nrV+J/0y3pxAImKNMW/IRzc7eUpmaR/hhzY+66AlXLJm8gTHyEVLnLtfR2iJG6njPhRG/f+tv/a2pwxBIfc6GGtFF4noEA3RufGvzrbczmgwQfLCWGRyZItpznSmoY7EPXLJmjlXTR2FMAvt284wItOZ3LeUdjUua+XKXpJr/SPeE89z6y+fQIUt7wPlMQl15ROMWLTFTGCZ26qZz9yQFr9pDB221Qsi2ruXbG8y/3IlxgZ9wzJmJiImmDeHsfminH43nPvYFkyWMi/7TLTGABHX2MJt/cCLrrPWdLecB3N3r5gTB58ZwMQMAYCL4uvQyATWkfG4QW/PdCsc5Zz2HaquNY9atvsNvk0KaNf2IMAA8Uil5tisinkk+2BFSnWWfiAqH2gaJeF4u4iZMClk3HUDFZOSIC4g5hu6Tfn7Kp3zKZOPWPC+3eOKxpj20sHVYiwiXxm6v/Ot//a+njigACraXIxX4XHsAzujCmWdD2T7P1buvdEgO4omIZ0PI8+7Ow7PEMwFtjKQ+W4F+h0FgEZgk/cwQdmUzfQInIm5/v5c+tnx/dr6k8ZKX5dK397x60qVAkOhoPl966aWJhnbNfFDVI5yzrzU+AciacufKgCtMgBA0c2WdL3CGZHCuTKbbB5WQR2CQ7mZ+980rjQIhQs+jlahwNvP5CABwWjgdnETS3ddoFCf9IwXMuukjBkblpcnLculrQ1seHrAXrHvm8eG1c8ygPVLv1qn3RnHW3/klBIx4frZ9/1aYpE515hXDU6X/nhoeSeoJwGrdDNu/XehAUEIg6o4lhnjUXtY/yickME9Mfb0AN9cuWsRT6MyB0Gfgo7IYFCbCGGYGiQAAEABJREFUNCbi9iWpO2sI8XSYBJq+jN+FD7Yba+/L2Z9jAI3TD0n2Oo8hfhED4MCQdOLq+seSAuKke/oRcVIGau1kAgDsI6R+pNo40tEYl14lgYzYao/qZRqkmtIonDrpMObIYcgyfBuNNAnCEXfoEYikC5CTtO60Z3zeQfaCkQup1Ku93FHxkfQTl086YW0u6Uc7/+E//IdnDFFEvBDuTE/215mpiBfrRsSJcTH3WW+Pb2+TlPW6ADJziJ6+FO/2psq6DOnVE+GH5BBpI+YPgtzK/JH+dyLFt7pHhMhZ62hJOgwSB5vAKG0e5Xw/yWo3h3BngY3znn4gfATdyMnrbSIiSHx6+S61qvXWzIe5wthAyLXutcP6Rbh6PchThREx2yWCnr0z4kkdRP5cYS/X5MVUZcxbXzfpnDE4bzQLXVCDuUXsKLfWIQiYwiDK+zr1OOFOF6boB0HUy2ZcnjLVaUNbhAlz3+m8gX1zGjKmG+attiuMyYFnhF+vjjbC3iIkqt/o2y8lRDFemMJsF7z8zM/8zOFvQ/T+s45ziZHIePpemiF9ZkaKfsj0o3xnjCkZAt5vFXiVjoYJrcE8sPeDSXehX74xYep7GUIkLumcni/OggSdJHwXjumfewmjs0PoPBjDIUloR3daI+IFWidiXdocTXRugBcxAGwKR9yyTi0+STagOuKolLnEMS3y3JtNoh3EBK50DrAps+TYoCG0AdFeDqeKoenpW+MYFpw6KRtA/Z//83+eAILeDnWSS80QT+ZhBFyuwvhkGp+NuCfW2Kx6D3nUnnJHORwyIiEiXmgS8mYX/kLGTALpOYQ+k/1gk+0xko8+dlJAa7cFCJNIdntTH26/0SQIPySHyO1SKOPz7Ks9KrzWYbZHl0sRvUnorPE90Rtxez9GHGvu5ZsQiZjT/v3Wnf33XSIr49niIs7Px5wABBy6BvFnPv/9v//3E+YJgdH3jz5J+0nY+rd6RlEdWjJ4RhihUsvZR5WYt9dGhLM6NCQ0UhG395E8Jn1eMRHe4ghDwOslImdLe0eVNU8jDRlY5AUnjFLvyxxcSgT3Nq8dt7/AjzX9gOmI6BHxDW972eVcO0w2R2W0DS9m29qzL+yPUfmuxbP/0TmIbXTOqM6RaZgMQg4aBXexEL+YbdpIY4t48YzU/o3VK4DnaBFtftqnfdrpdaBaP8O/8Au/MM3BVLAhy6Xf4XKmr/GtEQYQTdLL+54RE9PLLcWtP1hXhTTgqnPlXsS5uVpqu+fZL+AiLaDfoOj5Nb6bAbCBmVLkpq6NZhhAxwHiHHGpnr/KvCN8kgycZm4GhADV0h6GA/E6t4F+8id/cmKndsmYvXNNsgLImItzbSEkAYpajgQA501Kkek2zuiQWB9vkTvMWfZSH4Jg9jLikBHD8jE4tBE2OwB8aZ8Prb5vsu9OgKINzn7HFCMWSIpb9jDqgHZbehKUr/3arx1Kh4aNtERjhORb8sVRe2rErGgYMZ9rj7E1BulLjhS7EmhLZffkAbA0b5j7PfV7HRIrWp+I2wjQurOBt+6ECL3eufjSxUYXObuJjefuSGojYpPECAGBcR2Nx3qB1SMBCFU+s5JRvT1p9qb5wuQyZUJU1HbAcxJ+l3ydM0wnRFnLZBhRTwiFmACnaWMhP+MlVctyfPBzDh7Szo5wmbGA/eCxNrY6girwwvcgipyNt73tbaenHSO2rV/EceXdlel4YwSLfK9zZD7nTCCUeYgOQQfXEoydGx/CzP7o5Xw7k9q6/vDfiElyLnt9ccR0wnjEJMGlfSGvO+ewt00DASco6yUgZYSPdmgpwisEKYHGW9/61slZBTdGfTmT9sUob20aLRnNMSFrr4Necq5HuNQ9sV6+wxH5aBI0knUER8Eb6d2hGUd3P5UDT+A24b3OHDpz4JVv9VIcmpOG0G8OgIVLbdMeeerVeozK2XtgDFhDGAy3Kt/PeK+7iwGAlEhcRgcmO8Ax2eziiEN2YAAp05S5j1B2q2PzRgpugdVlDkT1PwfolRk5ai0XeW0S+dpzGHwHLjUXyELKv7Zj94/z7v1AVOe+DaHmtRsbzFwcATC0wexlbu0QCTZ2REwYMQfNnFGp9W94zHHAagSQSMDtGXudhoc5A+Bl3ua+VzskD50IZj6w5Q5BbV9/7C69ruDSWc27JGyczNVGZx6RxHQr4mbt7RPf8Fmf9VmT8Yz6ZUcKmfU8yC7TXBZzJyZinvCRr1zWSR8TilkmdLAPM32vj+nW3uj7telcWncIjZrc2s+dFeXXOjDA3Nby9ticsKKW2xJm1jUHV6wlhnTUnrWHfEZ5PQ2SpRFGYEBOmLOIeFYMvkBsIUQxlIQmMpk+euoTjHbGpI1cRJz2G4ZvZAYDdr/lLW8ZVZ0ISxA0NZMkzVlCwNX0DK/1EXu+h50zBA22n0PMa9s+shwio8Mi7dPQgHvCnL3Or84edeZq2n2GnVcvsiDsCaPQLEvjcdeqazjsNUwPBrTWZUY1YpRrmQwzB02hibOCyLYHMr/74GKHmXArk1BlabCcI+Gjnb1uHSOen8lRHzQdGAR43g9ejcpsSUMbjuYzIibzgVhmnlPbNJc1LmytafGE07nPgsgWt57OtHB3NB2+vadjHuCzS3EIbQb6SPu+lSDY74Ww6pB2zoHB8C+44W5Rh9XoavNIwGDM59rL/M0MAG6aDXjfpNlg+pCyzV4XCvJkYwnY9gXNelt9RDpCgx1V1l1j75pl07fApHvGGBGnH/ZCXHjphgZjeu3fEUj9tabOeiPuGiBYskdN4j+/g3SsAu+znc4UcAgSkI2KQJ5U8Q6Z/IiYIHjjYaM9mjcqemWrU3/ukNZy9xFGALrINZIUUufW9SIVxpwixOcuNZLG9jkg6fmqr/qq3U9/0kBYc9IQiAvhfulcATZMBkhjR21BUCQkxp75TDQQTqQSo7PujCqT5fnWnrQlmQAIxgU3eXNOvnI13/4xHpL1mr437Pvt/0QkvR1n0hxIj4jJ3BOQIHQxAudgpXpzzssfncAmIZyTVs21cy6dVHO0r0naPvuzP3t2P5prZjpz7Zs7d5MwMoh7WgZnI8vDD+973/smZZg3zN1fIojBMGMcIEN7JdvY4r/yyisT2+tex/llQup74RT4i8aHlls8y5PgdSKZ0KgTj1m++8wn7YkRPOxl98TBqB/7sR+b+FvrIyKquRLTNgwtKSrYnu31cyvdetTzL+2+HAbQ2uV5df7El36LyBoTloE/wp40te8x9Yiuc9/i++3lWg7spal785vffPqBKHfU4IRapoc9VY3uqOkVvmA+EMU1/6gwLQdmFSM+ajMJf4wiAaN5GpXbkoZRQ2Mt1XFW4DW0Z5YDM8x5xvkYAFJ24XQYbwS3OAIfHBLuzv1FT0hnurbtBesFNmR68Z8F7Xtw41nCikBEnH7XAdyjuUS426fnqipDywwejhiBc/V7/iYGwAL05z6Tq+kNiyP+IEHh6iyoHwTZA6RqOxm2QF69ybFE3Ni7UgFmmcfoQ3SQS47dpmRmQIKUadUH4BxMACfTIXVE6yVzrS4bWZLHbHfkQxYOZs3TPxUXe3abt+fVuPDSIZV/Xw4hY24B4NEYAAH7rSLQiJgQNaT55rDWg1RJBDsxQXpMGlXLrg0DYswLzLk6ztlekzj1OWsGMSLYxeccCXGXBkXcADn1+/cDzIip2h4iGrPNl44oxZQLzzlMaZdIkrZAtnN1tqSv+f73v//9kzXuiBOhC4HQfFqLLf1mWW1XGCA94oa5Fj7KGb/3wwlC7GHaUMjpIz7iI07fph/SR/45h0BBTBNUuMjNbPDll1+ecl/6HsgVsQH5U1nDLWskV/YzzdGnfuqnTqSz4MW58dR86+keE5vcmi6MYcZYIcBoEPQlvTrnnyahpm0JI0pJ8ggGjtaOIjhJlxFofPEtY7MenpeNiJNpmW/FYK9ZF/Cv73/jQKTYA1sde/PR2KWfa4sAxfrV+nCidUdI1vQahr+YTlh/+xW8X0vk+n6wu7YnjCaBt8EjUt9z7cEX9eK6NtRBJArDwZ3IlX6UI+hx38GYs03rijnwOMOWOcn6Sz5iFuGeZfTr/iOmJ9P4YGnV5BC2JZ6Qz8EnxiicDt7O8JJvjjEj7ngx0cKo2wvuQdR6hGDWoKYRWGGWa9racERMhID2xjlcV9sEx8wdGEjYRThS84UxFedgwJsUXOOo0CyAhcjyAAO7xox3HzIh7SAd7nmAC2YCIdTz9sRtXBImG0h9yAYx1AkPeZe4ulmzHYtfJSSXAL4K3KgwK4Fow9vQtUyGSSlIXAG6HFf65noPQlDfBlJXG+IQbifypXO4YEBUGfF0ETGRSpOoZBo/OXPhdAApgJPxh+A7bIhYP1r1bDyDACCJeAcQajak3/c6AgYwqeWESYC+8Au/cMp1XetbfwDMvtdOur0mcVmf5BuRHRGnpP5tp8RX/5B+Qa6Ix1ejt/77/v4DSQi/urdVIEk2fyRN4hExffRHf/Q0Am7ypXPC1fmhGUKBmrY37Jvs3Yjl7yc99T59wp/sLyImqlnEZaZt8QF4yKnX2ctQ9HYyDpbTSHm8ARGIyOhEOYYsy6ePwMGkZJzP9IxJkbYQy8owI6ERRvxiJCBXQgXfp85W56U05jyYAYQ0PGTf6MteHLVnbWhUCCOs16jMtdPMlTHSEhEYYASYqV3aLzjtJbzcF3wCodH5uLSvtGev7fgmjHdNI8CCD5x/l3G3OERRbSvD0s+1A053OKg+3GhfEhaK73UjIn3UFhjE4gEMJYQbneNeD07oBCa8725LlrXn4aSMH+kbI5Nn+MR54fsGtAgYcWRfcAKTnYgb2KpttAWBAXpK/9LS+WZMHDzHHJDZbebxI2LCACgnTsCGoRfmzGG1FJFWne+jHfQYgrWredcK+0aCM3N8rk+wo48D02NvOWceg8l8cwu+gglgQ6Z3fxUDAAlSoeXEasRkOUwmVXzOkSyRWvvQXgaQQqT39L1xgL1uCkQrBoBKcG+bvR4g0tN6/BLAV4EbJEndn+1DwCQbtUyGEXodcGQ9vrlml1/XUPqSU9ZhVFc5a4jI8X3iI2cjku71PAC5IyPr08uNEEkvc9dx+78SgUv9+zEchGwvYw5zryOQmDpEPAd8WT7ixo4+13Wtv7T+pPdeBMg+1vo0eMz9cl9ZG+s/V3+OAVK+nhuA2XxIrw4xBPD/zM/8zLNkxAb772cJJSBdfkmazo2xlj0X9v1MQOxdZTH6TEOER85cIXR7nvp97/cyS/HRfkJUkbQv1Ts6b45h79I6mii/6IvpRaRDUogmL8zIQ2QcNTZ4yIVihApNEFMcZwahiGjxPB4n7FKh/cKMaG//2lV3rzNXhBzqR8SzH0Kyr9Yy+6Ny8Gw/U869H2kjNNLfEQ4uTXhQ23PurEVNE0bUOEcjwYD8u3QEU6SlGK+j+7WmBGC9XfsSI7Z2zxMe9jYwthhX+FeePciUTvgaziG/PQkAABAASURBVJiZVbuDgzmllT26H7QFgcNLL730rGmCP3bxzFs6LZeFwD3EMsEBU/Kck8ynuYFfxOFE/Qgf5cCYo9rSju+wluZcfMk5Y6N8547JKc2JfN+ccwsmEI7PwYBFBkBDpDaklRWBA7KIf4dbh+cciebocETcEDvn6q/NJ9VxIbiW9+HGX9P2hiFcyGxNfXPzUABfjhd3jJjN+DlfWdLLLId7Bhj6oct8Pq0PkwfAVnzOzSESRBYicK7eXadbw0oEksYA9nPjMHZEcp+jiJu97kxhAEaapLk2L0k3DhIGzN+WdjDO3q7Oc0+q6jIW++KldpgRsJ/tZQD3TCOp6N/Pzt28KePeQGoaEBtzl96ky1cnHVW5/Zfxvf7o+6mDR3As+wDEnRlEXqYd4ZOKWcfalvlDVNe0a4crsl7qCwIHcxFaENxS2SPyEFgkg/Yqope2DhzBkCJiOGGI8tL+MHO9DXvV+ejpa+PGDU9hXPY6961G/eV8gDuj/K1pCIoRIwjeg/2j9sAEWmTnmqaGaQJhiKewI+JkbhRx25+7vyM94nbZiNtxZfo4jI8GGiN46T4YSentAXuu97sljr5gDlfrOPfOP9zrG+QhQl1uFb6Ww1AiIi+dq7nxuRxNOJD5vpPpEWJVGloODWVexatzVsTtpS4VB6P8ro585UZ7Vd5e99r9l73VX6iHMbxkjjHW5tJcZeMuFjPdzDgY4Ayaj0xLf5YBUJg6nm0SNa4KFumbv/mbJxxY7VDeklMWYaR+L4e77WmXxL/3e7/3JAXMNkjQ2XteIoHLtmyubp8nbw74m/Q5wOdyEMIy4jbwilgf/8qv/ErdTy7iucFPMhAxX986OtSnSmf+kNQB0onwHDTEsLU8U3WiBRhdtqnS0TlEMrKjPNfftfI7EYjwRwRWYnbUN0DWiUB7H2FMHQzQj+plGnvRiPl1jHgxz5OHkES2kT6imrYBUZZp53yXlu1b+11ZYzcm9uziS04/Ln3XM6F+vWDFrMe5rO0QKiDUpIEx9pswB4BRaQqnY/9IG5ZxPmRBADBHiCizxlGZ7v1+Jo8jWHduzyyNy7om8s9yEBsYnfFr+1T1bKN7P4ge39vT7ypeiX99RtyYG2LExI92THd6m5hXEtqe/lDi8ILLrEeMB6OBAO1tnYPbcKF7P6SzzpZ7bBjm3s414+6eHNH+6PvBngrz9vSDISLhrnXBDUIXuFNYHtNJJpTCj9GhxzwMUXEAJuftb3/7raev7Rk4s39j0iT2UL9jGhETXKiPawhIwN0+niPPP0ad6Q6/9zOK0wpUWgudS+NJqJDlI2Jyv4BgpLc7ZAAQAAgd0t+IOLUD0GuA1G3PwUWs9rsABo9gP3Vw0J/3vve9tzaRZhGbnpYTvsTNAb8lqaBN3AEfKQQERZpurveOKaUFCHt2YAgnB2tve1kPoY85yYOGGHMHxLdkmSUfAeYiFoI5y1lrKruMs3UfERQkuFnmPv0REWh+XXadzgzMXRREWy1m7wNWGLCUWiPqzEstd3QYc0jKsLZd321vOjPqQGoIeoKAte24RFXNxOwfDIT2tE/7I5zOPjGv2b4nVCvgx4j0c0LKIz3b4DP/A2eE9zrjYzd5yfe7ANthAgZn75jAtM5Q2kNsnfe2ubWeudbnUj1CDba5IxOVa6TBQ6N7T+AW+AWOLY13ax7kWYmWrfWXyjsfETGUhkecTx9JvWkr2TQzJSVRXep/bZ5zMdoHzvDaNq5dzh2Ta/YxkgIfQQSS6nfmAn5A4IEfcEh+F9xPCJLxa/kI6e/4ju+YwLQj7msSWpBYV0YafmDGR3hUv0Mc7oGDarr5yDihkfoZ52ubyWuHjxgnsEGZvQ4c7HWPYP60Cb4wgaKpgoOlbXXMLplB9XoRY8HICwyAN5dNak4e6R0inf0mG9fe8No4FSwbJe1lHba+JHYZP8IniQH4aluANls2E1zTt4YduhHws6ldkF7TvnFAlDhJwNRCIzq2joUkpV5wUZ/9oMtx3JqxqNOdi38uwSQH6XAh/kk2e9mlOISEcMkybFzr5avRXCKIL1GHZV+X+tYDs2t9tGXPkuq7HNWBkfzuMED2NcAgTx2EKaKV+lga57IqFZ7wQ3C+uxK/1oMmCMOaxPmacSLMmBxZSwyIbyetUdfrCh1BgwPVbEdfCMmcP/VoTSAjYeOEjCJC9OSsEQZtjYbqVGHwR7sQXa67sQPIW7/fGDDA1l034NElpjCI59E+oQHZe86Na4uzZiPzR/Ah23HmvfxDkrnXlGVLPTa+I3hsPOAXEzZaPPEjnD1ovntb9ok17un3Hbf/KiN9xHjcoxhpwb2jfkT7R7Thrlxvh/QfEd3T98TdI9lT71wdJrqI1FqOIIFABPwAJzPPYyy0chm/lo8hAWecI0wqQQRc7nUn2mzmnGv7dnbgVRrdrAPWI3jnhItdmEQLgo7M+midb/3Wbz09s5ppfLQQRkA4nW8hxM34Vt98j4SWW9sZlTc3cI0XE8G0PQIMAg/a/ojneFFf4ACaxG830JhKS/eMAUDEvuc975lwEAYDoVI9Ub2zJzriIoiFRhTo3KByY4sf5RwUm6q3Rw3qskVP3xK3oTATvQ6AgOBxMLxI0fNr3DyaZ/MrHbGB6EB8iK91kNGIG4X4MBhMPzAba9tTziF3qAEXccCHPdlW4l9dRCA7YJokziWVui40ADa6sulIO9TL+H34VGgOSaoPrRPi39xsGZtnbj1VhjjA/CKUAJD8JnOL0c74ffsk7JX4Z5pnL9hLdd3WjpMZmDPnvHj5RT1whflPRXLml4SJtEeZdIA6rWPGEaCpxfMLleKZxze/9pnwHuf8OYf5mwKkbe985zsnzyDu+X6SaUiSJsiPX5nbPeNSB/AeEXLgDoShzLUdhNrPqz6dWX46ZmIIBeuaafflg4/MTaztEWNAPCAieluIYhJ2tu32eM9/PcWd6Xp+fRtGXTrYKX7fjnDtWmMAw0dEIObYE6V7198e9bpPH7ezn/AHc53nyhp4mKJrU3v9o+O+E61I+2C/0y71PsBtJj09nbDTmCNuCFSwA0MAzvayGYdzWUqA774dTtVO5vPBbXBWeMmxlAAzl8os5YEnv+23/bYXithv8NretVcvif/UUKDjtggw7J9u+mOgBOJoLy+yefzAfEpP94wBwMFT45lkhL/CtACkOln4Up+tqEFC1FQ+CIxL2xzVR1z1dICbiq2nb4kDcg5erWOzU/9F3Lzn6uKb10yWiG+EXx0jogPRuQWAeqZvhJCNzToal8Mqvsa5RGfsNrk9gJmh9XEZaE39URlEnfsinHAtg8COuAEEmc6Eg1Q843ftm3+EWkooEO+IN1LrfnDOjU15yALzjIFABCOG1bM+CGTAXfy+HSkO5hwzau1J32mYAN4jx4aYtu61TWvucnFNE6YxYDIlzEXEROqvDcCun0NaSnWU3epIW0iSnEPfb+1I/WlDt7aV5SFt5l7mlC+eeXt8yB+hVesiRD7yIz+yJl0t7DtG8IZJqLm3Ljr3nczFEMSEMR6AYNNK+xURJxOXEU5RD26IuCkTEZO4dO2mo5XyVnfE83IR82Ewm0Ym61/iz81BxM3vMngpD9w8JwS6ZAz3XZfmto/BWUT80nrSfIGjvcxdxuGw3p+zQ+jY07fG7ScEW6/nUj7tOZi+Z/2ZW3f7f3ud9i/78roeCXjGwatLhZrZ1pyPViEEtLa177ny0o2ZAEc4HU1yvVOIPnnHO94xsfvPMnM+7YD9RQDEvr/DBOebdQGGYq4N6YhqhLDwHmdfIfZ7XetGAOyem7nq+UtxGk/wkyAnif8srz976tx5IrB1eRp8yrrwGCEwrTkGKdO7/4wBMKn/8B/+w8mb3wj/0Y+g9Mp74qTfCEKaBn3uaWNPHUBqxK1uaatOcNbzRJ9DksAlIp497YaoGAELG5a5gkXKdhCda59sw/XjwrNu+saAycJ8QMyQcOYt+dRGgNZLL700ATq4UZeMrNVSvb15xg+Q9vqknABoT7+LuPnC7FgH/aUEGHF4a5/KXOnUw4Q5xOZWNWtu7QE/8YfgqFQRz6Q2mHIApzNsR4zTs50Y8WzLXGA25vapc1KRDg0caVHfOxhwl+Cz3a0+RsMb5taLdMn309Rtbeea5THGvrP2QaLlnNa0a4U745b9QFpMFyB4CBAjYB4RJl75gFMgcIRh1nmsPkl/N3+xJu6vgL0Rt4VAYMpj/dbRuOGJkf27s4PARmA544hFOGSEL0ftHpkG38L1vU3rRBra07fG0Ua+s9aDMxG0ETeMIEGaS7u0p7XcUpgEOQVEWY7UGxOdcQRdFRwaB2FI5l/LR8cQvnzcx33chL6w1+f6Mr7K4FsPwq5K/LMCoSkkBJ5rp6ebB0+4gi09TxwBzMSl4gvp1UXE9Morr9SkTWEwsJ9/c4HxiIiJltSPJ54TANdOabLtKXC0pmf45Zdfngg8zGOmVT8iJk+1J90iz3iYThG6nMPjzxgAFS0MYkD4MbsRl+Z7cOn8PY40FwHS67q0inj2xFnNczgBAC8pjYh1WhAHvNaxiFRic4udZb3oQB2d8fRdvKTu2Uq4+50GxC/1GrWTwzp30LKvS3zaC1xzbYO0HQFR0+bC1HiIn7n8PekYXjbFiFIcuUvVl0iAjcE6OrwOsThnjt0luOb86merYypBukcTtbXumvIQVdfA2f/Mo+bqA/iYwsyPiMkYO4LHRAB4WW6rnxJ/LyXQhD20tfE9zKQIG4SrYzZgbmva0WHmhvXuSrZPUwxniEfE5FyDI+AJJkr6WkcrtoS817ZzzXIYz7737BXas4poI+IkBMKUuht2zTHdZdsYvZdeeulWlwh/5xQTnRlwnx9rQgjBjZl+F769Cu72vsB1e6ynb42PTFdpMcFN8Ex7ETE5l2DSGkaIOQ07e3Wrw0SgHzLNHpOWcb41gbOFr+30TwKPoR+dVUwQPJoCHQzgl37pl072AgLXGmBiSPIxBUePFw5zX5Hwbq5tuFj/c/lL6WBg14JiLJ3/uvYefXGnDeM02otLffS8iPHl3SyHJgVrI+KUhAb0RD8GC2w6JS78ucUALJR7NFk4Vaqx0YCXNsaofE2D3DoDgWhF0JlopiO5CbJeRJw0KjjTTEufxLUCTekRN4ttQ4nPOWYl/aIT4AbhIGbm6i2lU8VRR1Xufan8JXnMFpgv1DZcciQZr2lzYVJkAGUuf0869aqn7EjAze9WJmrUJ2kyqUnEzeFELDET2LtGoz4eSxrJMGCV44UMmEY5B5nWfdoggNTe7nkZd+YgmYzv9a3J93//9++tftV65s4dFIypeaud+dVeSLmmjcKQ3l5k5FJvZ9j1QSvRVe8YcwIKr3fQfCnXnfPb00itSJJ7+kOKI2j6eDBlNFUu4DnfNR++AFcRAjV9FAZ7mU7sdUwkRu0emcZ8AnFf20T0gdvgWv9+59282AujuavtHBWGFzqTpm0/WNqdf/+dAAAQAElEQVTNUqRvdaTAETfwPOsSUpD6Y34rrEIsMqN113FJG0RS2xkr7YzG635NJb6dJQzE3rOd37DFR1xi8hMW8QkDpFepPuFOmrbYJ+4MMHXCSGzpb6ksuOZ3dbKM/glyWGXQRhhb5vEJhwmRhLe6D/mQD3mhCpoSw4P2og3IAs7JkgA4y1nPiDiZRkaMfTCVGWnWqb48+13fXh9kuruFuXoUDAAE50A4xBxVHkBJwmCTQUK4TCoYF09JiOskZbgDqExf4zMfsnlqWWMhfZQGyFMF9w0XERP13ohLhzjqYdYOAMZEyveId+egI6Aj4lYWG2EA6FbiA41Qw9m4dXgkG1XaUfPuIoxYAdxJco7oz36whtZTe15wwFxYc/E3ksOUMy2MeL5nAc4l4j/nx54m1ch49Z01SNJc1/TXS5gpH+LKHHiMwR4ibKjf5xyZX3ChptcwpIAZNY/udSyVrfUyTDrJlC3jfK+BYOCo3iEeayE9HeKXmRsNWKalPzIjwQBcAp+z7Wv5zF86XvHNqbV0rhEdzEHqGBCBnmZGCNf0HmYKgAnY62gneptHx8HtiOdnWPvMBsFt3094NMJniEA/2jTShGvjSEczjijubRIU9LStcdqFTjzSgKT2334Hj2q7ETFhoGn2R9/v7HbYqL6zTvghXB3zKoKqmkbi7OW+mnbtsLGRfqPFwACaiEp4YvgI1Qj2CGjQQEvaMFJsAg537tbCJ0IR2gg27hUHEOa4P+SVRLSSMtJoasAqe3Hr/BgTE8Bez5OkzJM8+pD7IMtE3AiA4Tl2+pl+tI+5sgZglO+s7duzmLWkl1mI1PxHwQAYMERnETgLC1Da+DhsxDVVGy6UzTaOSJ3qbFa/iFrTtoRt8N4u6Q/uPtthw+/gZjx90noahIynPzrM8kjbIA3h7tjWdmAP6Pp+EtNe/qHFATzMVB0X5q4Dzpp/F2HERyeuXuh3ZQJkb/0gf1W0bY9WACn9jeIA40o8QZoIBsz7uTmwp7umLOtALq/HOYUMmVVAsogDsA8MIVEF4/L708e40hJkvPuQAAkjwhuh4IGHXmYpjvAzhloG7CPwkEZjaY8LV0dgYt9jhGt63QuZTlpnrTN+lA/eGBtinfu8z/u8XU0zAaVtqZU9/VmRPikwYqCWESYN/ORP/uTJhTzxx+hIWplP1LE7xwRgCTcRwIgN81zLRcQEXyOC4e+ad3TY3up7VR/wP/8SR5uL9qhtIL6Y50kzD96fH9EAc+a9HTZqx/xpcyQplyZPGWU554wUfMRgyD/KIWStub7ZnZO0m+9+n5PZF+GsMXmdxwXZTpjWMRk32gmNRfiJllmzT0jF0UrwrLtGI02T8+gRAkwY+OkFuaWx1HHVMCZW/ZpmLrIta48RIdiqZSJu9v4lT+jX9noYHDYPc8yVeWTa7Pyhlzsd+mgYgP7hW+Mk5CQ0W+spz8aWTZ9wOouPaLXwmeaCDKRNHZNp/IiYUhI8lX8OM8l3SXoWhHQhr2cJrwWoei3qa9GTh0Ai4TtFHvgf4+8HCSFH0vnAh75qeGwQcdmQvgrenmaT586H+BvN2cNMQirzTGW+dr+S7JBgj+YN8CcZ7+dhVPYxpJGakfYTKriDknuIdJw9MeId0Y1hrt9D4tmJ7JoP6EOS0kioSW2F1zjr1xl2BADEmgQ7uIcR03Zv0xpB6plOSkU7kPH0vUKX4YfoQ545hzk+jIX1yDhc4DL0SNpMwo+IzrLdX2MKEBGzpgKk773NI+NMNzCRtU0SVb/xUdPmmMGImBCMzERq+a1hmigE41w9Utp+UVPZI/YXZhyxrb10JMAI44wTbDAJGdEA/fsxhGiLChu1gxleolW8mmbulU3nIinck/GjfQ93ECRExKlpMGDOZBKznDh+jvE5NfLaH2vj7Iiik1wkR0eBh9LmHHMfcyVfPUQ66T4BirQj3Wj/O+eVbgG75xhgmgiw8MgxaQvDcQlt8SgYAAiGJIn6Bsftw7c4CwVA5ibbUldZi98XzzgwAPKrgwhdDK5p7goYQ03LMBWy/Iynz0behaOM8x1CiCji5hBKo4oHLPZ+mzbu0lEF9tcO2BIDnHc5jmv0xYwIp48gBSABB8TP6+Hb9s4XkzyXp7I+bdW73/3uCfObaXM+c6yqSenlIm7uzKxlJnr9hxKPiIl9LKkZSVZVFyMyMZAIJ2cckmHK08cOLrjA3NPBjEowkVp34qHXqXGIq0u+wTKItpYj/Z4jCCrBT8rXCUmMQzITtc0jwjQnHd5sbReR1i+wO99MFvq4MazuhfU+ImJKoqjnPfQ4eAZud0J1BLfhagRqZ1J9I4Z2yRZemXOOAMk+Y3oC/2I4ML/Mf0lBWQT0cdpfI6n8ub5qPqKSKVxN840IvpomPKIBpNfvN6doGoyhvHQEiwQASzgDg+GOmj2Y9SJiIt2mfc60I32WB+cI8uyPJD41LhHnYTS4VhnniJs60pb6NA/m2jroOyJODxEwOfK7NtKOch/1UR819X1FkGKv1z48e5xMSU0nPOjMY82/qzBhUe3rUTAANjr1CukR8xfIZjTJ9cMyjOAgPWMHlmlbfcCvIxHAv3L+2SbChmkDoJNpNrjyGa++dER8TRMm9YNohdMhJkk4Ms7HQHzBF3yB4IN3Lit1IIqDHc3jg/+YwQDZPCKu7DkMJ8l1qggHxV/3SRAz6X/EDcPqHHsFgqnAuY9H1CNoIc1aFrOsnUwj+bGvAN5Me2w+osUlykogkiASeLgHAMnlNyE4PamZSC/TEboYhUrsywO7arsYAMSTvDUO8dvXgMaxn1kwzkU4e7+2i6ChBcs0jEpHhOAcjUKWOdLHbPT+traPsOqEmnPekX+2i3jr8yAPM8d/bI55GTOzOm4EHkKvpmUY7EMcZfxo35lnikOi7kU1JiNM49w3YebW+zPWEVPWyy3FmVmgPWoZjDiGvKYJowE8I2zvi1eX+8J5N/6IG9iYZXwHyXbG53wmM52pcU4xFWzj5+rtTR/Bgbm2CCRpeTPfejHNXoL7GOf6AmXEOiZAm+zbsy8+GsmjLEyQxC918Eu/+wH+jpg/Zx8TXHHUpf0fWb+fjwfFACCyI24fiP7xEA2bMxwepLE00YhoG8vzUL2dtXGL34lWAAWym2sDg5IcOkTuklRHmFkXckQEZzx9xKR6Ged3FSTEiUs2J/JHjqRhiYse1blWGoIQQs72rZ2LhHNzk+UehP/aIEhnuyTgtayJKs6+JKVimrK0Llnn9erbd6TWVXPG3I2GZOmb1YNAaA4gtFoWwmMG05kqNr+erv2yL/uySf1a5zGEEe8Rt+Ges+FbOtHheyB/Jo3C1THVYX9b00iuq9QHAwBu1jJzYQysl19qPthHwFHTMoxpwxxknK88SbEwKSonXN0I1tX8S8JslO2PvW0YLyasnnlrw/adBHLU7mgeCHlyHkZ1HnIak4y6h4zV3QeCNeHunE/fap5qHoIYvqtpW8MYL3tqSz11OpG4pT6m2kMkdQ8gAJmpYMhHbTGN0m/NI7zw/Qh0hHqHb/C5S/rmr9YbhRGZJN3GUfPhV/QOgr2mXxIe0UDJyIzahfecj7r+vtWrOEvjQgdUWijihgkg4AQL5/pC7Ju7mk/o4UlSc13T94ThdPNa68JF1r+mZZh2tI8n87b6NGYuRqOTttYdle/CkAfFALhkRFUyGnhPw2X7ddXRYbHxHDQSMVLEXndLfPREl809B/y07QBAGhCozUN6IH3kIGNcf82zeRyGmubgQOaZ5hupQDE4mdZ9gMvGITEU7vl74xUQrm2DvSNzgojnhA4A6XCvbeNcOYf+XJlL8/WBUZ1rx360LnP5b5R0v4joOdX8Xnv6HHLDqGKsEfOdaANwEbeAPQJLe9k2X3m/QItpPnKva/sot8Q8Zh+IG9pD3+O8QDIknOYmyyA6wAcCjkzjp6StmgH4obB6Xvu8qTfn/Bpyl3wvwT5wj/Q3+wCjXFhM7Qwb+GoOpl+EBKmZ8DUcU0rzkm2PGKrMG/lM0EgUa945uNXnQV3S/3pfQNpjcOA22+86VkRarmlNr2FMfNfS29sYg1pua5iUGDEItyPq7bGlNjAdaAVnZqncUh5inYlRLQPOj6T/WcaehncJADPNM7eEIAj0TlAqh2nYYqkwkn7rC6xgMYFmEL/UoWH6eO2BpXbhQOegljEul4etX03PMJj23ve+N6MnP+KGCQDzTwmDP2gg/fW9YMzm+pJ5UJcJeMRzusWesr721WA4k+9g2VHzfv3Xf32y/2vaXNj8wHU/9EM/NNECM79CG3fifa7+Uro5qfkPigGoA1sTdgjZy+GslXeISKBIHtm+VtW5/K3OBThS94jni+/C6tqXJAAA7ly/Xvxwp0A5CBFz0QGBTVilqQ6gjabOyCGCEA5uf6+5iDNqYy6N+nUuby6dbXMlJqwVFfqcFG2unaX0iuiXyj3lXXcGnBvqV1IfPc3taXnpSDqcZZK2iOfnTT5m3isqeZ6dDba/HcFExOScUL+TNql7tLsECDPHcYlxbkyIRKpy409kZg5pzggKvGaRdT37BjlkuUxX/tM//dMn9ycIICDdzON3pkHayJF8G2/E87VYA/usDVMM47VGvkf79gQGoDPP1hb8U+YazvdXoVLvf6lPY2Z2WeEKuEXCdw5u5Ty4JErD4UcFLyFCl8Z5zTx7r8Jt+43pwxLxazwIJLjPfIlzvv+otUb0eSjjMz/zMye4UPsjhx5YY1IzqitttAfgalo436PMnCOBxgCbM/NAGEcgaU/WOvJo1dAtNf1cGPxD6I++328hoVMwsOfaWcq3/tWMM8v+/M//fAaHPuIVvOiZzJ6WXiH7zu/8zinpuazr/LngixnNtO4TJGLMe7q5xgQgqnvemjgh8x/4A3/gVlHmTSwvbiW2iLUHzzMZ4+fZ+IyPfDSbNWNaBr6L+3ZlXWzfArvU4dzfqjjLfSym9PK4R80A+AASAcgG0ZzErrC8S11/ostBBfwd1kvbrvUdYjaBpCokGzZszbd5mZXkBgBQIP+5cdg4SfxrJ+LmBQZ9iN+1A/QA0ojnxATA/D//5/+866G84fqjsbjrjya9AHj168wwzel7Wl46BCtm0FNtEc/3iLoICXuHn+X573znO6fP+ZzPmTAX4tXpGwGGUEHI1rxLw12CsrY9QBdzEvH8+2pdyMLZ950IZ/Ga731zSAVxnenO88i2OZmA//pf/+sE4Gf5LT6tZZWWp9RrDubUtml63vKWt0zWFZECfvkNDOtSy2FGCDHOEVK1Ds1IFYTUvFG4S+99E+HQqGxPY4bWNRYIG+vQy47i5oHkmGlWMq+jcg81DcGFMY94vmcRMs7emjF7Gx2hjGCCN72OZj+sqbu2DMaKSXBqnbIeHGmt3BEgKMz0rT5YVvcAmMTUE84+15Z+CRAx4r4dfeJJxlpPe7R8mPs9c4MRQ/x2UyB9GDdayByJ73EEdx2GINA7fOpt5YpptQAAD4xJREFUo8kwvz0dM86qAkzoeeI0jCNCGROqnjIjhyHX5yjPK2jusYzyltJGzA/tLBg4J/3P9sBxffLtF0+h2pOZX33mwp6oZ1ZHcFXt9M01Ws8eGs1LbWcUhguSbpSvbUI2Ye7RMwAWnqRqZBvsA/c6wI/6p6rPARSStb1tLtVDsDhsVKe9nI1UL2ExhwBYezlxBI8NCtiIp7MRqDKPsInLNtf4mBGEDTvnLA94IAi2IP6sey/+HXdq7ai3tzjM1IgwSgnCNT8hIqYEMsxPIL2ImCA3e3FOsgUJfPEXf/HkzgzAVMdIykYKwv7Yfql5GcZUeHcbIZlp6SMUSa6YXejDPsy8+/AxI95B9129f8SLeYMs5LHvxRB1pE6SYy7zDCMwMAGj+fH97PdzXbS71oEhHfZRzXupaG0bWQ7Rj8CBdCKeE5L2hm+0xll2jQ8eI+LXlGW60i/vuRNAmniuPqHFX/trf+307GaWtU4IP/OeaUf5e858hQ8ERH0sEc/PZc9bE7fPEF5Z1vdjatZ+P4IWXma+gIA5RzRlP1t9uJMgMOuRiDMZYf7mLl6mb/WdLU9aRjzftwRXzuqWtjChzHUqDlcfMUmSDO+bK2l7nLa9ODciMMFY3+GZWed6S/vaTVhe6zFnWXPJu7+GmG143RBjmfHq0wJ30zH5ETHRagjPOZfSR2Y2pOfn6vY2zRvCvONUTAZ81cuP4vYe/EWLOKcxIRRCy4FVmKNsx1oyDXcGCY/mzg4JP1id9bpvz/n+TIcPmNhmnUfPAOSHHe07lBX4UWdZ+CXgh3vDwVbAfETYAe6XsN71rndNo7YxREx+RvNBeoloysUflTk6zdvElfiCRADQJHaO7u/10J59hyDY4kjPEYj38f0AFyRvX9GaYTYReID5nGSLXalnL9mZq5/jBvjYTwKanvXL9Dn/7W9/+wRRQfqjMgC5S2ykK6QsgPqo3F2kMUVwlsGS7I8Gg5QOEZNpfLb0IyTrDPseZTjnyBkbIU35exykU4lsZxZBtQT7Rv0gONzp8ANKEc+JKGvsRxAxM6N659LchbLXzpUjxCEFreUIIkh1weqaXsPglbEpK52bWyd5R7g9Z77Ch7peOR7nyrnM+BYfA/QxH/Mxzxgg53mrjfqW/i4t63UxRLC7R4g947+EqLa/MC8VpmK0twiuwB7nhsaoa2LBK7DLPrxknOZNfZqOkTZQPiEQLSp4TFBkXNKXHPhsbGB5L8fUBp3T03sco+Cs93RzCo71dHHfMmIctEOTpMycIykfvXCmrrHM1Rulg9MEyzXP+qNdjLGmrwkj1H13L0tQE/EcNsrXvn3jyWR4QBqnf3519hUhGFhX04XBMcIOcEA8HaEMQQYm7IkByFkpPuDhwETcLAzgD0GTZpZiLwQtltc5EGMVOF8a7sAdBz3XJlOBFwZWEiw+JmANECjVdgUdFk/oRTyfxxGxs6vxp0oPbgYAG5J8xAKpL+IeMKsDtf+YpzlLpBMRN3tDGUQsBOvyMOmJtDUOYe3MjgBk1gcESVlcIjYmavPMu0sfHGED61vN05x5FGKb1I7pTR8fZFLTmAEgfGgGa/oo3NX5vQy1N2ktSbs8Y6RBMW7xtQ7jRxhhziOer7H2ECIELNZhqT0M0EhjgqhnS04lvuTMs3XvfajPxKmni4OLNDV+WEmcI6llwgNuir/eHcKham0RUJcwbHcxX2AAgoaG4ty+Ojcee8BlVbAqy4ItmEIMd6Yt+R4BAcNo3SvhZy4JOPzQnzEvtbElD7xAtBrnXD2PEDBFYmPuPPvOUVkCADClfn+WM37CFJLwTJvzf/Znf3bqWkxlXYZGJwmPnHtBHe5hOpiRjcpnGosC35bx9GkF5pijLFN9zF8KsqZpOmURgqBn1q7/qVL5g56cY3qymLm1N9yVgs/6PrbGXdsdEZPzStCifnUsVsDfbL/6mCz784kBqLPyathkVuC3FfgDEhC3hXi1uQf5n2QOh3nNwQEigF9KEDBRpA+vVyRKgrd1PjFyXinp9eyfiDhJ3yLW+Uwsfvqnf7o3dadxUiiSez+I5kWeDsAQqaR03r3PfWGAyiGwEP57TezUBzhJAs+dPdq0zlQbx105yBWMYQIDXsz1S6U9Uh07S72O73dRGvLseTVOpT2HFBAENCTKqGMeEX6YMvE1DtFg3M56F0Yg5t3boBZfIlSyHy97IDaMI9PSR1QZ75IjXcvy1Sd9dd+qpmUYEeWiYkScksB/P1xnXk4JV/qz58xHxDMYQfh01NDY1Keturl3edXZdk6P6uMhtwM3Ms3IMWKsnQG23Jk259v/BBwEIH7zIiKeFcX0awecQ3w9yzgogDgFT86dLUIa9vRzcIA0OWFAHxpCfGSm3MuJI/I7wQp2ufezxEC4OA1WaINTx+VYAgXxJQf+deYBDAFrl+plHnji7hLcnGn6v0RwyYwMU5FClWy3+s6WfYeJ9QhEzcuwPeUOTsb3+hX+XY0BmAO+ewd9V/XYpGIC9OcChsO8BfhbSMSPzWqTQzSkYQ5cRDwD2BH3F7Y2cxIw373HQcgpmaQ+ROgnxwsIkKpRve9p+17rrOy8mgusrPK6LAZ4kcLVjyMNY+7jUqpLkRFxynZWIAMMqXsu5xDXqdLCH3aSELe9VhGIKggZJnMkK4h/9wOkH+Hq3l/bHmJipCGp9T1p2gE+idoc8YAAIGnig121rQxD7DSUGa8+Bq2qvUnN1hJ+EKd1h2whOzAm20ZEU8/TEJ37HYiskz5VdZ+DzNvjMxEAmzBhvX4XWtif9uwW+N/bfGxx5nSeHUSsODNwmHkhfXxs37JnvKS8Xq5iNqM+SSlBFgZbfM4h/O2p7//+759o0aqAA8H1uZ/7uRPCf6+AY67fng6uYDIwLT0PTMTQg4/OtbXtZcTRLiTewtXB4zSo8mv6XBj8qhJ59b3e5PzN1ZEOJ6hLW+gMosnO1VGPw0ibb2EOTmGCJbzGIcKryaIxM7FZ2/+oD4IMv9mAkRjlmyN7DG7yvaMy0mg4PBCBkRTf48yN+bRX1b+YAZizMXQgdPCYnMPvwkVETJAW4t0zUFu/wSICol7CoOqmbvMk2tZ2HlN5l0sAPcS/Q5Trz96ZVI17TN+zdqyQJKKC5HltnaVyfqjpp37qp5aKrMoD7AFSUvFVFVYW2qLpIM1w+ZXtcErDcr4QVhhtF5KOJi4QmbQM1Kn6g0jMBUkMCTSksPJzVxXLvb+q8MZCkAeiP6uZK5fGMt5930bCjmijAvb9tQxCfXRhFNFebX4RMhgU/dX6Paw9dzX05dUX0sUsYy9jRjCA4CoGLfPW+upjakjhmRRYy7V1lfP9xuEpTnuO1BNTIa863w/Jp9DCPELKvq2WuzSMsERcX9rONeqbg9wD5o3kH/46tweuMZa5NufojbnyW9KdGWsOj/l+BDI4gqieaweM80NN5shcpYmd+mzW3Rt0J2GNZH6uj63pmBXfgXlRFy4A9wg+nCXnlAkdOkV+d+gVWgDtYL4RjaTyXsVyb6GXn4trn1CAIIFjfoTInStf0wko0RI022tfnVIfc8JUCMz0/ZghMETeOWf9mSw7o8qaNwzxlm9Wb+QIP80nujLz7RHwncmlvExf8hHu5oVGA22ljaXy8giDwE5mt3BDNT27mAHQwchtBdSjNnwcbsflvVH+kWkQFGLf4bdxIYs3kuTn0rmkdiPdpSpD/Fs76jjvwTMHuLT9c/XtN5v8XLmj8n0fAO8das8KeuZrb9vawkTYc15ugUj2tKUdY4J0APtrENdrNR3WHOAlaWeHjQgjfYJEvMTCTAiRtec719ShiSBxgwDYR9LCOddr6q4tA7AifDG8vm1tvS3lCCWYTVlb58n3kASda4NJyJ/6U39qIoggfTf/c3UQ8VXt7cUfEkJEzVwdZxwiMRZ7336LiMk47cHcyxDOnMZiru2ebp8gCJgU0SxExGpNKmLbnvUU59Kec459kzU1X5iWtUi5j3cp7huYoNUybJSPYPq1af4RbF6/Akd8l/Q1TllzAJYy4/IK0tIeWNPm3jJ1juo3kaTvbfNcPcQfO3mSWgIDxOcS00qoZZ6cMWcox0ngIQ2zwpzqaLhz7jvkY1qcGePjI7y3jMOZpZV1T4vW0IXwtaY/+k/nDOV9RTAp09f4hKaYsDVlaxl0HJyD8dJ/zZsLY36rAIBU/p/+0386gXFzdbamoydZlIAx9grh2J4zZk/SUrG4AN8iluEhARW4Q6Cjbh33oQyAg+OX/qiSmcHUjraEASCqZMSCH51yiLbU31PWYpD4e7sWt3a05GfPmB56HZuYjbKLjGy/P/IjP3JC3OFyqbxIGwCia34HwiYJTf1dsy9tO7ykoyQ6ALw3lrcAVm2kg/j98Il9bt6WCJSsM+cDlF6HMSbnZe+Y5tofpTunpCzWGqKpZRBt1KcJDwAg60MFXMtdO0zlDlgeNR/2G1MiyMITk4hs8+17r/Etxu3CIKmP+bPXt/RDIka4Yf7BZBoh+622ATFB8BExIf5JDxEAtUwPI5YwVdq1D0jYSQ7BAHvwkr3c+7qLOHyDmSEFNF/XJHx/9Vd/ddK++UJkIh4R65d8J0EZot8PPyHYMDCI2C1tOpskvqTFTFbtvS31jyyLEAdbEHCIpPwm+/nIfmpbLv6S5oPt5vHc92P+MVsY3jpOZ/Wa46xjXgo7w+bu2jh4aQyPJS+ZX/gdjGVKak2PHj/mxKMKBFTg8bk9dnT/vb2LGQCqFsCM1BG3SMVK7bPnw9idOYCkhkwGAKQ+4GvGIXVS7JGK+Jr9Pra2rW2qBJmEUJMCNiSBNjYCArd5LaLIIcWoHSllHK7BINE32uM0HYPsTUmQBER9xD63JtSJmwawo7Dz7nUWxIt3tklZvJjQJQskJ5C2udoLD3YM7+pVfM8rr7wyeRP/Wvu7f4S1ZRN7SX/aoPbnhGsf9p90ZxpScpZr/ihMGkjLQ7KIESJhxxBgREflH3oamEX7tlVKufW7zBtm3z0M8+U3H7a2MSqPCQVLthL9tS3mBXA4E7qafh9hElmwhRQaQXYXY0DHEBas3QPOpMuiL7/88nSX47yLuXij9VEFALSWl8Dac3OHCbC/Oxw+V+8a+RczAD4EMAOALp00hAKzhTUI6BqT8dTmuhlwaZPEEOFQayAC7Ye1ALTW3RJGhCM4HpuUccs3PtSy1hfBh3h5rMTeQ53b+xoXRISAcaYRQWvGoQ6BCWnxpXB/TX/3Ueapz6cZeJqBN8YM3JUA4KHN5sUMwEP7oKfxPM3A0ww8zcDTDDzNwNMMPM3A0ww8zcDOGXhDVPv/AAAA//+SozdQAAAABklEQVQDAN78a5MjOF/iAAAAAElFTkSuQmCC";
var TARGETS=['祁','煜'];
/* --- the word the tide answers to ---------------------------------------
   One word, written once, in either hand : the lower one, the capital one,
   and the capitals.  The two characters above are still read the old way :
   the sea has never forgotten them, it simply asks for something else now. */
var WORD_T=['rafayel','Rafayel','RAFAYEL'];
/* the words that must never fit the writing better than the word itself.
   Every near neighbour comes twice : once in the lower hand and once in the
   upper one.  A cap-height row of letters and a small row of letters are very
   different shapes, so without the upper twins a wrong word written in caps
   would have nothing in the sand to be compared against and would be taken
   for the word. */
var WORD_DECOYS=['rafael','rafyel','rayafel','rafalel','rafavel','rafayle',
                 'RAFAEL','RAFYEL','RAYAFEL','RAFALEL','RAFAVEL','RAFAYLE'];
/* The words with the tail cut off.  A word that is only half written fits
   the template very well - the letters that were written stand exactly
   where the template has them - so the half word has to be measured against
   the word it is a half of.  Without these the sea answered to "Rafay". */
var WORD_CUTS=['raf','rafa','rafay','rafaye',
               'Raf','Rafa','Rafay','Rafaye',
               'RAF','RAFA','RAFAY','RAFAYE'];
var WTPL={},WTPLV={};
/* ?dbgmatch prints what the matcher scored, so a threshold can be set from
   evidence instead of from a feeling */
var DBGMATCH=(typeof location!=='undefined')&&location.search.indexOf('dbgmatch')>=0;
/* two hands : a plain grotesque and a rounder one, so that a hand that
   leans a little is not a different word */
var WORD_FONTS=['700 150px Arial, Helvetica, sans-serif',
                '700 150px "Trebuchet MS", Verdana, sans-serif'];
/* the comparison grid : a character seen through 24 cells is a blob, seen
   through 64 cells it is a shape.  The distance scale must follow it, or a
   finer grid would only make every score smaller. */
var RG=64, TPL=null;
var CHAMFER_CAP=8.0, CHAMFER_SCALE=6.0;
/* look-alike negative samples: tighten the decision, never a target */
var DECOYS=['\u7948','\u7950','\u7953','\u7957','\u70e7','\u711f','\u709c','\u708a','\u70ed','\u711c'];

/* a word, rendered in one hand and read as a shape */
function wordGrid(s,font){
  var W=900,H=220;
  var c=document.createElement('canvas');c.width=W;c.height=H;
  var g=c.getContext('2d');
  g.fillStyle='#000';g.fillRect(0,0,W,H);
  g.font=font;g.textAlign='center';g.textBaseline='middle';g.fillStyle='#fff';
  g.fillText(s,W/2,H/2);
  var im=g.getImageData(0,0,W,H).data,m=new Float32Array(W*H);
  for(var k=0;k<W*H;k++) m[k]=im[k*4]/255;
  var sk=thin8(m,W,H);
  var bb=bboxOf(sk,W,H,0.30);
  if(bb.w<3||bb.h<3) return null;
  return gridOfRegion(m,W,H,bb.x,bb.y,bb.w,bb.h);
}
function buildWordTPL(){
  WTPL={}; WTPLV={};
  var all=WORD_T.concat(WORD_DECOYS).concat(WORD_CUTS);
  for(var i=0;i<all.length;i++){
    var s=all[i],vs=[];
    for(var f=0;f<WORD_FONTS.length;f++){
      var g=wordGrid(s,WORD_FONTS[f]);
      if(!g) continue;
      var face=vs.length;
      vs.push({g:g,d:distT(g),f:face,b:1});
      for(var v=0;v<JIT.length;v++){
        var jg=jitterGrid(g,JIT[v][0],JIT[v][1],JIT[v][2],0,0);
        vs.push({g:jg,d:distT(jg),f:face,b:0});
      }
    }
    if(!vs.length) continue;
    WTPL[s]=vs[0].g;
    WTPLV[s]=vs;
  }
}
function maskToGrid(mask,w,h,bx0,by0,bw,bh){
  var g=new Float32Array(RG*RG);
  var kx=RG/bw, ky=RG/bh;
  for(var y=0;y<RG;y++){
    var ya=by0+y/ky, yb=by0+(y+1)/ky;
    for(var x=0;x<RG;x++){
      var xa=bx0+x/kx, xb=bx0+(x+1)/kx;
      var s=0,c=0,xx,yy,ix,iy;
      for(yy=ya|0; yy<=yb; yy++){ iy=yy; if(iy<0||iy>=h) continue;
        for(xx=xa|0; xx<=xb; xx++){ ix=xx; if(ix<0||ix>=w) continue; s+=mask[iy*w+ix]; c++; } }
      g[y*RG+x]=c>0?s/c:0;
    }
  }
  return blurGrid(g,RG,1);
}
function blurGrid(a,G,r){
  var t=new Float32Array(G*G),i,x,y;
  for(y=0;y<G;y++)for(x=0;x<G;x++){
    var s=0,c=0;
    for(var k=-r;k<=r;k++){var xx=x+k;if(xx<0||xx>=G)continue;s+=a[y*G+xx];c++;}
    t[y*G+x]=s/c;
  }
  var o=new Float32Array(G*G);
  for(y=0;y<G;y++)for(x=0;x<G;x++){
    var s2=0,c2=0;
    for(k=-r;k<=r;k++){var yy=y+k;if(yy<0||yy>=G)continue;s2+=t[yy*G+x];c2++;}
    o[y*G+x]=s2/c2;
  }
  return o;
}
var TPLV={},SHEET=null;
function buildTPL(){
  var im=new Image();
  im.onload=function(){ buildTPLFrom(im); };
  im.onerror=function(){ buildTPLFrom(null); };
  im.src=TPL_SHEET;
}
function buildTPLFrom(im){
  TPL={}; TPLV={}; SHEET=im;
  var all=TARGETS.concat(DECOYS);
  /* the sheet carries one row per typeface : a hand is not one alphabet,
     so every character is known in several hands */
  var rows=im?Math.max(1,Math.round(im.height/64)):1;
  for(var i=0;i<all.length;i++){
    var ch=all[i],vs=[];
    for(var r=0;r<rows;r++){
      var g=im?sheetGrid(im,i,r):fontGrid(ch);
      if(!g) continue;
      /* Every variant carries the label of the hand it belongs to, and the
         base of a hand carries a second mark. Counting the variants in
         fixed steps breaks the moment one cell of the sheet is unusable :
         the groups slide, and a jittered shape is then weighed against the
         base of a different typeface as if the two were the same hand. */
      var face=vs.length;
      vs.push({g:g,d:distT(g),f:face,b:1});
      for(var v=0;v<JIT.length;v++){
        var jg=jitterGrid(g,JIT[v][0],JIT[v][1],JIT[v][2],0,0);
        vs.push({g:jg,d:distT(jg),f:face,b:0});
      }
    }
    if(!vs.length) continue;
    TPL[ch]=vs[0].g;
    TPLV[ch]=vs;
  }
  if(PENDING_DEMO) writeDemo();
}
/* a region of a mask, resampled to one canonical size, thinned, gridded :
   two characters are only comparable at the same scale */
function gridOfRegion(m,w,h,bx,by,bw,bh){
  var k=64/Math.max(bw,bh);
  var nw=Math.max(6,Math.round(bw*k)), nh=Math.max(6,Math.round(bh*k));
  var src=document.createElement('canvas');src.width=bw;src.height=bh;
  var sg=src.getContext('2d');
  var id=sg.createImageData(bw,bh),d=id.data;
  for(var y=0;y<bh;y++)for(var x=0;x<bw;x++){
    var sx=bx+x,sy=by+y;
    var v=(sx>=0&&sx<w&&sy>=0&&sy<h)?m[sy*w+sx]:0;
    var o=(y*bw+x)*4;
    d[o]=255;d[o+1]=255;d[o+2]=255;d[o+3]=v>1?255:(v<0?0:(v*255)|0);
  }
  sg.putImageData(id,0,0);
  var cv=document.createElement('canvas');cv.width=nw;cv.height=nh;
  var cg=cv.getContext('2d');
  cg.fillStyle='#000';cg.fillRect(0,0,nw,nh);
  cg.imageSmoothingEnabled=true;
  cg.drawImage(src,0,0,nw,nh);
  var im=cg.getImageData(0,0,nw,nh).data,mm=new Float32Array(nw*nh);
  for(var i=0;i<mm.length;i++) mm[i]=im[i*4]/255;
  var sk=thin8(mm,nw,nh);
  return normalizeGrid(blurGrid(maskToGrid(sk,nw,nh,0,0,nw,nh),RG,1));
}
function sheetGrid(im,idx,row){
  var C=64;
  var c=document.createElement('canvas');c.width=C;c.height=C;
  var g=c.getContext('2d');
  g.fillStyle='#000';g.fillRect(0,0,C,C);
  g.drawImage(im,idx*C,(row||0)*C,C,C,0,0,C,C);
  var im2=g.getImageData(0,0,C,C).data,m=new Float32Array(C*C);
  for(var i=0;i<C*C;i++) m[i]=im2[i*4]/255;
  var sk=thin8(m,C,C);
  var bb=bboxOf(sk,C,C,0.30);
  if(bb.w<3||bb.h<3) return null;
  return gridOfRegion(m,C,C,bb.x,bb.y,bb.w,bb.h);
}
function fontGrid(ch){
  var S=140,c=document.createElement('canvas');c.width=S;c.height=S;
  var g=c.getContext('2d');
  g.fillStyle='#000';g.fillRect(0,0,S,S);
  g.font='900 '+Math.round(S*0.88)+'px '+GLYPH_FONT;
  g.textAlign='center';g.textBaseline='middle';g.fillStyle='#fff';
  g.fillText(ch,S/2,S/2);
  var im=g.getImageData(0,0,S,S).data,m=new Float32Array(S*S);
  for(var k=0;k<S*S;k++) m[k]=im[k*4]/255;
  var sk=thin8(m,S,S);
  var bb=bboxOf(sk,S,S,0.30);
  if(bb.w<3||bb.h<3) return null;
  return gridOfRegion(m,S,S,bb.x,bb.y,bb.w,bb.h);
}
/* what is actually written in the sand : the ink canvas, read as a mask.
   The mask must stay wide enough to keep a drawn stroke solid : at 256 the
   core of a stroke is thinner than a pixel and the skeleton breaks up.
   It also has to follow the size of the field of writing, or the same hand
   is read a third thinner on a wide screen than on a narrow one. */
var MASK_W=512, MASK_MIN=512, MASK_MAX=896, MASK_SCALE=0.592;
function thinMask(){
  var W2=MASK_W,H2=Math.max(64,Math.round(MASK_W*inkCv.height/inkCv.width));
  var c=document.createElement('canvas');c.width=W2;c.height=H2;
  var g=c.getContext('2d');
  g.fillStyle='#000';g.fillRect(0,0,W2,H2);
  g.drawImage(inkCv,0,0,W2,H2);
  var im=g.getImageData(0,0,W2,H2).data,m=new Float32Array(W2*H2);
  for(var i=0;i<W2*H2;i++) m[i]=im[i*4]/255;
  return {m:m,w:W2,h:H2};
}
/* a jittered copy of a glyph grid : slightly rotated, squeezed, shifted */
function jitterGrid(g,sc,sq,rot,dx,dy){
  var cs=Math.cos(rot), sn=Math.sin(rot);
  var o=new Float32Array(RG*RG);
  for(var y=0;y<RG;y++)for(var x=0;x<RG;x++){
    var u=(x+0.5)/RG-0.5, v=(y+0.5)/RG-0.5;
    var sx=((u*cs+v*sn)/sc+dx+0.5)*RG-0.5;
    var sy=((-u*sn+v*cs)/sq+dy+0.5)*RG-0.5;
    o[y*RG+x]=sampleGrid(g,sx,sy);
  }
  return blurGrid(o,RG,1);
}
/* the shapes a hand can give a character : a systematic set, not a random one */
var JIT=[];
(function(){
  var scs=[0.94,1.0,1.07], sqs=[0.90,1.0,1.12];
  for(var a=0;a<scs.length;a++)for(var b=0;b<sqs.length;b++) JIT.push([scs[a],sqs[b],0]);
  JIT.push([1.0,1.0,-0.10]); JIT.push([1.0,1.0,0.10]);
})();
function sampleGrid(g,sx,sy){
  var x0=Math.floor(sx), y0=Math.floor(sy);
  var fx=sx-x0, fy=sy-y0, s=0;
  for(var j=0;j<2;j++)for(var i=0;i<2;i++){
    var xx=x0+i, yy=y0+j;
    if(xx<0||xx>=RG||yy<0||yy>=RG) continue;
    s+=g[yy*RG+xx]*((i?fx:1-fx)*(j?fy:1-fy));
  }
  return s;
}
function bboxOf(m,w,h,thr){
  var x0=w,y0=h,x1=-1,y1=-1;
  for(var y=0;y<h;y++)for(var x=0;x<w;x++)
    if(m[y*w+x]>thr){ if(x<x0)x0=x; if(x>x1)x1=x; if(y<y0)y0=y; if(y>y1)y1=y; }
  if(x1<0) return {x:0,y:0,w:w,h:h};
  var pad=Math.round(Math.max(2,(x1-x0)*0.06));
  x0=Math.max(0,x0-pad);x1=Math.min(w-1,x1+pad);
  y0=Math.max(0,y0-pad);y1=Math.min(h-1,y1+pad);
  return {x:x0,y:y0,w:x1-x0+1,h:y1-y0+1};
}
/* the ink of a grid is judged relative to its own peak */
var GRID_THR=0.34;
function gridThr(g){
  var mx=0,i;
  for(i=0;i<g.length;i++) if(g[i]>mx) mx=g[i];
  return mx*GRID_THR;
}
/* distance from every cell to the nearest inked cell */
function distT(g){
  var G=RG,d=new Float32Array(G*G),i,x,y,t=gridThr(g);
  for(i=0;i<G*G;i++) d[i]=g[i]>t?0:1e6;
  for(y=0;y<G;y++)for(x=0;x<G;x++){
    var id=y*G+x;
    if(x>0&&d[id-1]+1<d[id]) d[id]=d[id-1]+1;
    if(y>0&&d[id-G]+1<d[id]) d[id]=d[id-G]+1;
    if(x>0&&y>0&&d[id-G-1]+1.414<d[id]) d[id]=d[id-G-1]+1.414;
    if(x<G-1&&y>0&&d[id-G+1]+1.414<d[id]) d[id]=d[id-G+1]+1.414;
  }
  for(y=G-1;y>=0;y--)for(x=G-1;x>=0;x--){
    var id=y*G+x;
    if(x<G-1&&d[id+1]+1<d[id]) d[id]=d[id+1]+1;
    if(y<G-1&&d[id+G]+1<d[id]) d[id]=d[id+G]+1;
    if(x<G-1&&y<G-1&&d[id+G+1]+1.414<d[id]) d[id]=d[id+G+1]+1.414;
    if(x>0&&y<G-1&&d[id+G-1]+1.414<d[id]) d[id]=d[id+G-1]+1.414;
  }
  return d;
}
/* the cells that actually carry ink : cached, a comparison runs hundreds of
   times per character and must not rescan the whole grid each time */
function inkCells(g){
  if(g._ink) return g._ink;
  var t=gridThr(g), arr=[];
  for(var i=0;i<RG*RG;i++) if(g[i]>t) arr.push(i);
  g._ink=arr;
  return arr;
}
/* how close two stroke shapes lie to each other, in cells.
   The mean distance lets a perfectly matching half hide a completely wrong
   half, so the distances are raised to a power first : the root mean square
   keeps a good match low and a bad one high. */
var CHAMFER_POW=2;
function chamfer(a,b,da,db){
  var A=inkCells(a),B=inkCells(b),i,s=0;
  if(!A.length||!B.length) return 0;
  for(i=0;i<A.length;i++){ var v=db[A[i]]; if(v>CHAMFER_CAP)v=CHAMFER_CAP; s+=Math.pow(v,CHAMFER_POW); }
  for(i=0;i<B.length;i++){ var w=da[B[i]]; if(w>CHAMFER_CAP)w=CHAMFER_CAP; s+=Math.pow(w,CHAMFER_POW); }
  var d=Math.pow(s/(A.length+B.length),1/CHAMFER_POW);
  return Math.exp(-d/CHAMFER_SCALE);
}
/* Zhang-Suen thinning : a comparison must not care how thick a stroke is */
function thin8(m,w,h){
  var b=new Uint8Array(w*h),i,y,x;
  for(i=0;i<w*h;i++) b[i]=m[i]>0.35?1:0;
  var changed=true,iter=0;
  while(changed&&iter<16){
    changed=false;iter++;
    for(var pass=0;pass<2;pass++){
      var del=[];
      for(y=1;y<h-1;y++)for(x=1;x<w-1;x++){
        if(!b[y*w+x]) continue;
        var p2=b[(y-1)*w+x],p3=b[(y-1)*w+x+1],p4=b[y*w+x+1],p5=b[(y+1)*w+x+1],
            p6=b[(y+1)*w+x],p7=b[(y+1)*w+x-1],p8=b[y*w+x-1],p9=b[(y-1)*w+x-1];
        var B=p2+p3+p4+p5+p6+p7+p8+p9;
        if(B<2||B>6) continue;
        var A=0;
        if(!p2&&p3)A++; if(!p3&&p4)A++; if(!p4&&p5)A++; if(!p5&&p6)A++;
        if(!p6&&p7)A++; if(!p7&&p8)A++; if(!p8&&p9)A++; if(!p9&&p2)A++;
        if(A!=1) continue;
        if(pass===0){ if(p2&&p4&&p6) continue; if(p4&&p6&&p8) continue; }
        else { if(p2&&p4&&p8) continue; if(p2&&p6&&p8) continue; }
        del.push(y*w+x);
      }
      for(i=0;i<del.length;i++) b[del[i]]=0;
      if(del.length) changed=true;
    }
  }
  var o=new Float32Array(w*h);
  for(i=0;i<w*h;i++) o[i]=b[i];
  return o;
}
function normalizeGrid(g){
  var mx=0,i;
  for(i=0;i<g.length;i++) if(g[i]>mx) mx=g[i];
  if(mx<=0) return g;
  for(i=0;i<g.length;i++){ g[i]=g[i]/mx; if(g[i]>1) g[i]=1; }
  return g;
}
function subMask(m,w,h,x0,y0,cw,ch){
  var o=new Float32Array(cw*ch);
  for(var y=0;y<ch;y++)for(var x=0;x<cw;x++){
    var sx=x0+x,sy=y0+y;
    if(sx<0||sx>=w||sy<0||sy>=h) continue;
    o[y*cw+x]=m[sy*w+sx];
  }
  return o;
}
/* where are the two characters : the emptiest column near the middle */
function splitCandidates(m,w,h){
  var bb=bboxOf(m,w,h,0.22);
  var cols=new Float32Array(bb.w);
  for(var x=0;x<bb.w;x++){
    var s=0; for(var y=0;y<bb.h;y++) s+=m[(bb.y+y)*w+bb.x+x];
    cols[x]=s;
  }
  var peak=0; for(x=0;x<bb.w;x++) if(cols[x]>peak) peak=cols[x];
  if(peak<=0) return [];
  var out=[],seen={};
  function push(sp){ if(sp<3||sp>bb.w-4) return; if(seen[sp]) return; seen[sp]=1; out.push(bb.x+sp); }
  var lo=(bb.w*0.24)|0, hi=(bb.w*0.76)|0, split=lo, bv=1e9;
  for(x=lo;x<hi;x++) if(cols[x]<bv){bv=cols[x];split=x;}
  push(split);
  push((bb.w/2)|0);
  var g0=lo, gv=-1e9;
  for(x=lo;x<hi-1;x++){ var v=cols[x]-cols[x+1]; if(v>gv){gv=v;g0=x;} }
  push(g0+1);
  return out;
}
/* two characters of a name, not one character cut in half : each half must
   have the proportion of a character, and the two halves must be of a kind.
   The gap between the characters counts for nothing, so the halves are
   weighed against each other, not against the whole span. */
var MIN_SHARE=0.12, MAX_RATIO=2.4, MIN_ASPECT=0.60, MAX_ASPECT=1.75;
function halfBBoxes(m,w,h,splitX){
  var bb=bboxOf(m,w,h,0.22);
  if(!bb||bb.w<6) return null;
  var aw=splitX-bb.x, bw=bb.x+bb.w-splitX;
  if(aw<3||bw<3) return null;
  var la=bboxOf(subMask(m,w,h,bb.x,bb.y,aw,bb.h),aw,bb.h,0.30);
  var lb=bboxOf(subMask(m,w,h,splitX,bb.y,bw,bb.h),bw,bb.h,0.30);
  if(!la||!lb||la.w<3||lb.w<3) return null;
  /* a cut that swallows both characters, or that leaves a radical on one
     side, is not a pair of characters */
  if(la.w<bb.w*MIN_SHARE||lb.w<bb.w*MIN_SHARE) return null;
  if(Math.max(la.w,lb.w)>MAX_RATIO*Math.min(la.w,lb.w)) return null;
  if(la.w/la.h<MIN_ASPECT||la.w/la.h>MAX_ASPECT) return null;
  if(lb.w/lb.h<MIN_ASPECT||lb.w/lb.h>MAX_ASPECT) return null;
  return {a:{x:bb.x+la.x,y:bb.y+la.y,w:la.w,h:la.h},
          b:{x:splitX+lb.x,y:bb.y+lb.y,w:lb.w,h:lb.h}};
}
function matchGlyph(grid){
  var out={};
  var all=TARGETS.concat(DECOYS);
  var da=distT(grid);
  for(var i=0;i<all.length;i++){
    var ch=all[i],vs=TPLV[ch],best=0;
    if(!vs||!vs.length) continue;
    /* first : which hand is it written in ?  Then, and only then, how badly
       may that hand be written.  Letting every typeface drift into every
       other one would blur the characters into their neighbours.
       The hands are found by the label each variant carries, not by
       counting in fixed steps : a fixed step silently mis-groups the
       variants the moment one cell of the sheet is unusable. */
    var fb=-1,face=-1,f;
    for(f=0;f<vs.length;f++){
      if(!vs[f].b) continue;            /* only the base of each hand */
      var s0=chamfer(grid,vs[f].g,da,vs[f].d);
      if(s0>fb){ fb=s0; face=vs[f].f; }
    }
    if(face<0) continue;
    for(f=0;f<vs.length;f++){
      if(vs[f].f!==face) continue;
      var s=chamfer(grid,vs[f].g,da,vs[f].d);
      if(s>best) best=s;
    }
    out[ch]=best;
  }
  return out;
}
/* the three rules, and the room each of them leaves :
   the two characters must tell each other apart (cross), the target must
   beat every look-alike (decoy), and the shape must be a character at all
   (score).  Measured on 28 true pairs and 26 impostors. */
var TH=0.44, XCROSS=0.032, XDEC=-0.08;
function bestFor(sc,target){
  var mine=sc[target],other=0,near='';
  for(var k in sc) if(k!==target&&sc[k]>other){other=sc[k];near=k;}
  return {s:mine,margin:mine-other,near:near};
}
/* how far the target stands above every look-alike */
function decoyEdge(sc,target){
  var m=1e9;
  for(var i=0;i<DECOYS.length;i++){
    var d=sc[target]-sc[DECOYS[i]];
    if(d<m) m=d;
  }
  return m;
}
function scorePair(ga,gb){
  var A=matchGlyph(ga),B=matchGlyph(gb);
  var t0=TARGETS[0],t1=TARGETS[1];
  function ord(aT,aB){
    var sA=A[aT],sB=B[aB];
    var cross=Math.min(sA-A[aB], sB-B[aT]);
    var dec=Math.min(decoyEdge(A,aT),decoyEdge(B,aB));
    var sc2=Math.min(sA,sB);
    return {s:sc2,cross:cross,dec:dec,sw:false,sA:sA,sB:sB,
            ok:(sc2>=TH)&&(cross>=XCROSS)&&(dec>=XDEC)};
  }
  var o0=ord(t0,t1), o1=ord(t1,t0);
  /* the order is decided by how well the two characters tell each other
     apart, not by their raw score : otherwise the pair contradicts itself */
  var R=(o0.cross>=o1.cross)?o0:o1;
  if(R===o1) R.sw=true;
  return {ok:R.ok,s:R.s,margin:Math.min(R.cross,R.dec),cross:R.cross,dec:R.dec,
          sA:R.sA,sB:R.sB,
          left:R.ok?undefined:(R.cross<XCROSS?'THE TWO CHARACTERS LOOK ALIKE':'NO MATCH'),
          right:0,swapped:R.sw,
          why:R.ok?'':(R.s<TH?'NO MATCH':(R.cross<XCROSS?'THE TWO CHARACTERS LOOK ALIKE':'A LOOK-ALIKE FITTED BETTER'))};
}
function resMargin(res){ return Math.min(res.cross,res.dec); }
/* the writing, read as one word */
/* measured, not guessed : see ?dbgmatch.  The floor says there is a word
   shaped thing in the sand at all, the margin says it is this word and not
   one of its neighbours. */
var TH_W=0.55, XDEC_W=-0.02;
/* How much of the word is actually there.
   A shape that writes only half the word still fits the template quite
   well : the letters it does write stand exactly where the template has
   them, so the score on its own cannot tell a finished word from an
   unfinished one.  What tells them apart is the other end of the
   comparison : the word has to beat its own cut-off versions.  Write five
   letters of seven and those five letters stand exactly where the shorter
   template has them, so the shorter template explains the sand better and
   the word is refused.  A word that is not all there is not the word,
   however well the half of it fits.
   The margin is nothing at all, and that is the point : a finished word
   explains the sand at least as well as its own first half does, and a
   half word explains it better.  It was measured, not guessed : see
   ?dbgmatch.  A hand that leans a little must still be able to write its
   own word. */
var CUT_MARGIN=0.0;
/* and no other hand's tail-less version may explain the sand far better than
   the word does : a word written in capitals is not a word written small,
   and the sea knows the difference even when the hand does not.  Measured,
   not guessed : a cut-off word falls away by a fifth, a hand that leans a
   little loses only a hair. */
var CUT_FAR_MIN=-0.10;
/* The cut-off versions are measured in the same hand as the word they are
   compared with : a word written in capitals is measured against the
   capital cuts.  Measured in two hands at once the comparison comes out
   meaning nothing, and the word loses to its own first half. */
var WORD_CUTS_OF={'rafayel':['raf','rafa','rafay','rafaye'],
                  'Rafayel':['Raf','Rafa','Rafay','Rafaye'],
                  'RAFAYEL':['RAF','RAFA','RAFAY','RAFAYE']};
function matchWord(grid){
  var out={};
  var all=WORD_T.concat(WORD_DECOYS).concat(WORD_CUTS);
  var da=distT(grid);
  for(var i=0;i<all.length;i++){
    var s=all[i],vs=WTPLV[s],best=0;
    if(!vs||!vs.length) continue;
    var fb=-1,face=-1,f;
    for(f=0;f<vs.length;f++){
      if(!vs[f].b) continue;
      var s0=chamfer(grid,vs[f].g,da,vs[f].d);
      if(s0>fb){ fb=s0; face=vs[f].f; }
    }
    if(face<0) continue;
    var bc=0;
    for(f=0;f<vs.length;f++){
      if(vs[f].f!==face) continue;
      var sc=chamfer(grid,vs[f].g,da,vs[f].d);
      if(sc>best) best=sc;
      if(sc>bc) bc=sc;
    }
    out[s]=best;
  }
  return out;
}
function recognizeWord(m,w,h){
  if(!WTPLV[WORD_T[0]]) return {ok:false,s:0,why:'TEMPLATE NOT READY'};
  var bb=bboxOf(m,w,h,0.22);
  if(bb.w<10||bb.h<5) return {ok:false,s:0,why:'TOO LITTLE IN THE SAND'};
  /* A word is wider than it is tall, but a word is not a line.  Both are
     resampled into the same flat grid, where a single stroke and a row of
     letters are far too alike to tell apart by shape alone, so the shape
     of the writing is checked before it is scored. */
  var asp=bb.w/bb.h;
  if(asp>14||asp<1.0) return {ok:false,s:0,why:'THAT IS A LINE, NOT A WORD'};
  var g=gridOfRegion(m,w,h,bb.x,bb.y,bb.w,bb.h);
  if(!g) return {ok:false,s:0,why:'TOO LITTLE IN THE SAND'};
  var sc=matchWord(g);
  var s=0,which='';
  for(var k in sc){
    if(WORD_T.indexOf(k)<0) continue;
    if(sc[k]>s){ s=sc[k]; which=k; }
  }
  /* the word has to beat every other word : otherwise a near neighbour
     written badly would be taken for the word written well */
  var near='',nv=-1;
  for(var k2 in sc){
    if(WORD_T.indexOf(k2)>=0) continue;
    /* the cut-off versions are not rivals : they are this word with its
       tail missing, and they are weighed against the word below */
    if(WORD_CUTS.indexOf(k2)>=0) continue;
    if(sc[k2]>nv){ nv=sc[k2]; near=k2; }
  }
  var dec=nv<0?1:s-nv;
  /* and it has to beat the words that are only its own first half : a
     finished word explains more of the sand than a cut-off one does.
     The comparison is made in one hand : the cuts of the hand the word was
     written in, because a cap-height row of letters and a small row of
     letters are different shapes and measuring them against each other
     comes out meaning nothing. */
  var cuts=WORD_CUTS_OF[which]||WORD_CUTS;
  var cutw='',cv=-1,q;
  for(q=0;q<cuts.length;q++){
    var cs=sc[cuts[q]]||0;
    if(cs>cv){ cv=cs; cutw=cuts[q]; }
  }
  var cut=cv<0?1:s-cv;
  /* and the same question asked of every hand at once : is there a tail-less
     version of this word, written in any hand, that explains the sand much
     better than the word does ?  A word in capitals is not a word in small
     letters, and the sea knows the difference even when the hand does not. */
  var cutwAll='',cvAll=-1;
  for(q=0;q<WORD_CUTS.length;q++){
    var ca=sc[WORD_CUTS[q]]||0;
    if(ca>cvAll){ cvAll=ca; cutwAll=WORD_CUTS[q]; }
  }
  var cutAll=cvAll<0?1:s-cvAll;
  var ok=(s>=TH_W)&&(dec>=XDEC_W)&&(cut>=CUT_MARGIN)&&(cutAll>=CUT_FAR_MIN);
  if(DBGMATCH){
    var sc2={};
    for(var k3 in sc) sc2[k3]=+sc[k3].toFixed(4);
    console.log('MATCH word',JSON.stringify({s:+s.toFixed(4),which:which,
      dec:+dec.toFixed(4),near:near,
      cut:+cut.toFixed(4),cutw:cutw,
      cutAll:+cutAll.toFixed(4),cutwAll:cutwAll,ok:ok,all:sc2}));
  }
  return {ok:ok,s:s,margin:dec,near:near,which:which,cut:cut,cutAll:cutAll,
          why:ok?'':(s<TH_W?'NO MATCH':
            (dec<XDEC_W?'A NEARER WORD FITTED BETTER':'THE WORD IS NOT FINISHED'))};
}
/* The pair is the stricter rule, so it is asked first : if the writing is
   two characters they are the characters, whatever the word scores.  If it
   is not, the word is the only thing left to be. */
function recognizeMask(m,w,h){
  var pair=recognizePair(m,w,h);
  if(pair.ok) return pair;
  return recognizeWord(m,w,h);
}
function recognizePair(m,w,h){
  if(!TPL||!TPL[TARGETS[0]]) return {ok:false,s:0,why:'TEMPLATE NOT READY'};
  var sk=thin8(m,w,h);
  var cands=splitCandidates(sk,w,h);
  if(!cands.length) return {ok:false,s:0,why:'TWO GLYPHS NEEDED'};
  var best=null;
  for(var i=0;i<cands.length;i++){
    var hb=halfBBoxes(sk,w,h,cands[i]);
    if(!hb) continue;
    /* the skeleton is only good for finding the gap between the two
       characters : the shape itself is taken from the original strokes,
       resampled down to the canonical size and thinned there.  A one pixel
       skeleton resampled would break into pieces. */
    var ga=gridOfRegion(m,w,h,hb.a.x,hb.a.y,hb.a.w,hb.a.h);
    var gb=gridOfRegion(m,w,h,hb.b.x,hb.b.y,hb.b.w,hb.b.h);
    var res=scorePair(ga,gb);
    if(!res) continue;
    /* a split that satisfies every rule beats a split that merely scores
       high : a wrong cut can flatter one of the two characters */
    if(!best) best=res;
    else if(res.ok!==best.ok){ if(res.ok) best=res; }
    else if(res.ok){ if(resMargin(res)>resMargin(best)) best=res; }
    else if(res.s>best.s) best=res;
  }
  if(!best) return {ok:false,s:0,why:'TWO GLYPHS NEEDED'};
  return best;
}
function recognizeStrokes(){
  var tm=thinMask();
  return recognizeMask(tm.m,tm.w,tm.h);
}
var lastRecog=0,recog={ok:false,s:0},lastSig='';
function runRecognition(force){
  var now=performance.now();
  if(!force&&now-lastRecog<110) return;
  lastRecog=now;
  var total=0,i; for(i=0;i<strokes.length;i++) total+=strokes[i].n;
  if(strokes.length<1||total<6){ recog={ok:false,s:0}; lastSig=''; return; }
  var sig=strokes.length+'|'+total+'|';
  for(i=0;i<strokes.length;i++){
    var s=strokes[i];
    sig+=s.n+':'+(s.n?(s.p[0].toFixed(3)+','+s.p[1].toFixed(3)):'')+';';
  }
  if(!force&&sig===lastSig&&TPL&&TPL[TARGETS[0]]) return;
  lastSig=sig;
  recog=recognizeStrokes();
}
/* ?dbgmatch also lays the numbers on the sand itself.  A hand that writes
   the word and gets no answer should be able to read why, without opening
   a console the piece never asked for. */
var dbgPanelEl=null;
function dbgPanel(){
  if(!DBGMATCH) return;
  if(!dbgPanelEl){
    dbgPanelEl=document.createElement('div');
    dbgPanelEl.id='dbgpanel';
    dbgPanelEl.style.cssText='position:fixed;left:10px;top:10px;z-index:60;'+
      'background:rgba(0,0,0,.55);color:#9fe;padding:6px 9px;'+
      'font:11px/1.45 monospace;border:1px solid rgba(120,186,238,.22);'+
      'pointer-events:none;white-space:pre;';
    document.body.appendChild(dbgPanelEl);
  }
  var r=recog||{};
  function num(v){ return (v===undefined||v===null)?'-':((v>=0?'+':'')+v.toFixed(3)); }
  dbgPanelEl.textContent='MATCH   s='+(r.s||0).toFixed(3)+
    '   dec='+num(r.margin)+'   cut='+num(r.cut)+'   cutAll='+num(r.cutAll)+
    '\nwhich='+(r.which||'-')+'   near='+(r.near||'-')+
    '\n'+(r.ok?'LOCKED':(r.why||'WRITING'));
}
function strokesFromMask(m,w,h,thr){
  var out=[];
  for(var y=0;y<h;y++){
    var x=0;
    while(x<w){
      if(m[y*w+x]>thr){
        var x0=x;
        while(x<w&&m[y*w+x]>thr) x++;
        out.push({n:2,p:[(x+0.5)/w,(y+0.5)/h]});
      } else x++;
    }
  }
  return out;
}
/* the two characters, written for you : taken from the embedded sheet, not
   from a font, so the demonstration works on a machine that has no Chinese
   font installed at all */
function sheetGlyph(idx,row){
  var S=64,C=256;
  var c=document.createElement('canvas');c.width=C;c.height=C;
  var g=c.getContext('2d');
  g.fillStyle='#000';g.fillRect(0,0,C,C);
  g.imageSmoothingEnabled=true;
  g.imageSmoothingQuality='high';
  if(SHEET) g.drawImage(SHEET,idx*S,(row||0)*S,S,S,0,0,C,C);
  else{
    g.fillStyle='#fff';
    g.font='900 '+Math.round(C*0.94)+'px '+GLYPH_FONT;
    g.textAlign='center';g.textBaseline='middle';
    g.fillText(TARGETS[idx],C/2,C/2);
  }
  var im=g.getImageData(0,0,C,C).data,m=new Float32Array(C*C);
  for(var i=0;i<C*C;i++) m[i]=im[i*4]/255;
  var bb=bboxOf(m,C,C,0.30);
  if(bb.w<3||bb.h<3){
    /* The sheet cell came back empty. Fall back to an installed face rather
       than returning nothing, so the demonstration always has an ink. */
    if(!SHEET) return null;
    g.fillStyle='#000';g.fillRect(0,0,C,C);
    g.fillStyle='#fff';
    g.font='900 '+Math.round(C*0.94)+'px '+GLYPH_FONT;
    g.textAlign='center';g.textBaseline='middle';
    g.fillText(TARGETS[idx],C/2,C/2);
    im=g.getImageData(0,0,C,C).data;
    for(var i=0;i<C*C;i++) m[i]=im[i*4]/255;
    bb=bboxOf(m,C,C,0.30);
    if(bb.w<3||bb.h<3) return null;
  }
  /* keep the strokes, drop the black ground : the sand must stay sand */
  var t=document.createElement('canvas');t.width=bb.w;t.height=bb.h;
  var tg=t.getContext('2d');
  var id=tg.createImageData(bb.w,bb.h),d=id.data;
  for(var y=0;y<bb.h;y++)for(var x=0;x<bb.w;x++){
    var v=m[(bb.y+y)*C+(bb.x+x)],o=(y*bb.w+x)*4;
    d[o]=255;d[o+1]=255;d[o+2]=255;d[o+3]=v>1?255:(v<0?0:(v*255)|0);
  }
  tg.putImageData(id,0,0);
  return t;
}
function erodeInkMask(src,w,h,passes){
  var a=src;
  for(var p=0;p<passes;p++){
    var b=new Float32Array(w*h);
    for(var y=1;y<h-1;y++)for(var x=1;x<w-1;x++){
      var i=y*w+x;
      if(a[i]<=0.24) continue;
      if(a[i-1]>0.22&&a[i+1]>0.22&&a[i-w]>0.22&&a[i+w]>0.22) b[i]=a[i];
    }
    a=b;
  }
  return a;
}
function glyphStrokes(){
  var W=512,H=Math.max(64,Math.round(512*inkCv.height/inkCv.width));
  var c=document.createElement('canvas'); c.width=W; c.height=H;
  var g=c.getContext('2d');
  g.clearRect(0,0,W,H);
  g.imageSmoothingEnabled=true;
  g.imageSmoothingQuality='high';
  var target=Math.round(H*0.56);          /* the height of a written character */
  for(var i=0;i<2;i++){
    /* Use the brush-like second face for the demonstration. It keeps the
       lower-right tail legible while recognition still knows all three faces. */
    var gl=sheetGlyph(i,1);
    if(!gl) continue;
    var s=target/Math.max(gl.width,gl.height);
    var dw=gl.width*s, dh=gl.height*s;
    g.drawImage(gl,Math.round(W*(0.31+i*0.38)-dw/2),Math.round(H*0.5-dh/2),dw,dh);
  }
  var im=g.getImageData(0,0,W,H).data, m=new Float32Array(W*H);
  for(var i=0;i<W*H;i++) m[i]=im[i*4]/255;
  /* write them into the sand for real */
  var g2=inkCx;
  g2.clearRect(0,0,inkCv.width,inkCv.height);
  g2.imageSmoothingEnabled=true;
  g2.imageSmoothingQuality='high';
  var fine=erodeInkMask(m,W,H,1);
  var tc=document.createElement('canvas');tc.width=W;tc.height=H;
  var tg=tc.getContext('2d'),ti=tg.createImageData(W,H),td=ti.data;
  for(var i=0;i<W*H;i++){
    var o=i*4;
    var xi=i%W,yi=(i/W)|0;
    td[o]=255;td[o+1]=255;td[o+2]=255;
    var fibers=0.85+0.09*Math.sin(xi*0.23+yi*0.17)+0.06*Math.sin(xi*0.61-yi*0.37);
    /* Never let the stylisation delete an entire component such as the
       dot or upright in 祁 / the bottom line in 煜's lower-right 立. */
    var preserved=Math.max(m[i]*0.94,fine[i]);
    td[o+3]=Math.round(255*preserved*Math.max(0.82,Math.min(1.0,fibers)));
  }
  tg.putImageData(ti,0,0);
  g2.drawImage(tc,0,0,inkCv.width,inkCv.height);
  return strokesFromMask(m,W,H,0.25);
}

/* ==================================================================
/* ==================================================================
   5. TIDE
   ================================================================== */
var STATE='IDLE';
var T=0,TIDE_DUR=9.6;
var PH={s0:0.03,s1:0.46,h1:0.48,r1:1.0};
function easeIO(t){ return t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2; }
function tideP(tt){
  var p=0;
  if(tt>=PH.s0){
    if(tt<PH.s1) p=easeIO((tt-PH.s0)/(PH.s1-PH.s0));
    else if(tt<PH.h1) p=1;
    else if(tt<PH.r1) p=1-easeIO((tt-PH.h1)/(PH.r1-PH.h1));
  }
  var envelope=Math.max(0,Math.min(1,(tt-PH.s0)/0.06))*(1-Math.max(0,Math.min(1,(tt-0.94)/0.06)));
  if(tt>=PH.s0&&tt<=PH.r1) p+=0.010*Math.sin(tt*Math.PI*15)*envelope;
  /* the gauge quotes 4.70 M and the ruler ends at the bottom : p is held
     inside [0,1] so that neither the reading nor the water can run past
     the end of the instrument */
  return Math.max(0,Math.min(1,p));
}
function startTide(){
  if(STATE!=='IDLE') return;
  STATE='TIDE'; T=0; flash=1; charge=1;
  wetMark=0;      /* the damp band belongs to the tide that is coming, not
                     to the one that has already gone */
  clearEro();
}
function finishTide(){
  clearInk();
  T=0;
}

/* ==================================================================
   6. FRAME
   ================================================================== */
var prevT=performance.now(),tsec=0,wetV=0,wetMark=0,DBG=false,HOLD=false;
var uiStatusEl=document.getElementById('ui-status'),lastUIStatus='';
var uiStateEl=document.getElementById('ui-state'),lastUIState='';
var uiTideEl=document.getElementById('ui-tide'),lastUITide='';
var uiTideDirEl=document.getElementById('ui-tide-dir'),lastUITideDir='';
var uiGaugeMark=document.getElementById('ui-gauge-mark'),lastGaugeY='';
var uiGaugeRead=document.getElementById('ui-gauge-read'),lastGaugeV='';
var liveEl=document.getElementById('live'),lastLive='';
var _staffBottom=90;

function uniformsNow(){
  return STATE==='TIDE'?tideP(T):0;
}
function waveAmp(){
  if(STATE==='TIDE') return 0.10+0.90*Math.max(0,tideP(T));
  return 0.10;
}
/* The instrument speaks in four places, and all four are read from the same
   state, so they can never disagree : the state chip, the level on the
   staff, the number of the tide, and the one sentence. */
function updateUI(){
  var label,state;
  if(STATE==='TIDE'){
    state=T<PH.h1?'RISING':'FALLING';
    label=recog.ok
      ? ((T<PH.h1)?'Lemuria Sea God has answered.':'See you later, Miss Bodyguard.')
      : ((T<PH.h1)?'The tide is rising':'The tide is falling');
  }
  /* The state chip still says what the instrument is doing : the sentence is
     only for the things worth a sentence.  A line that repeats the chip
     ("Match locked", "Capturing the gesture") says nothing the picture has
     not already said, and it talks over the one line that matters. */
  else if(drawing){ state='WRITING'; label=''; }
  else if(recog.ok){ state='LOCKED'; label=''; }
  else{
    /* The recognition already knows why it refused : the code works the
       reason out and then throws it away.  A refusal with no reason is a
       silence, and a silence is the one thing this piece cannot afford. */
    var why=(recog&&recog.why)||'';
    if(why==='NO MATCH'){ state='NO MATCH'; label=''; }
    else if(why==='A NEARER WORD FITTED BETTER'){
      state='NOT THE WORD'; label='that is not the word'; }
    else if(why==='TOO LITTLE IN THE SAND'){
      state='WAITING'; label='write it in the sand'; }
    else if(why==='THAT IS A LINE, NOT A WORD'){
      state='WRITING'; label=''; }
    else if(why==='TWO GLYPHS NEEDED'){
      state='ONE GLYPH'; label='write the word'; }
    else if(why==='THE TWO CHARACTERS LOOK ALIKE'||why==='A LOOK-ALIKE FITTED BETTER'){
      state='TOO ALIKE'; label='write them further apart'; }
    else if(why==='THE WORD IS NOT FINISHED'){
      state='UNFINISHED'; label='write the whole word'; }
    else if(why==='TEMPLATE NOT READY'){ state='WAITING'; label='the archive is still waking'; }
    else if(strokes.length){ state='WAITING'; label='The sea is calm'; }
    else{ state='IDLE'; label='The sea is calm'; }
  }
  if(state!==lastUIState&&uiStateEl){
    uiStateEl.textContent=state;
    lastUIState=state;
  }
  if(label!==lastUIStatus&&uiStatusEl){
    uiStatusEl.textContent=label;
    lastUIStatus=label;
  }
  if(label!==lastLive&&liveEl){ liveEl.textContent=label; lastLive=label; }

  /* ---- the staff ----
     The mark is the water itself, read off the same curve the picture is
     drawn from : the water line is mix(SHORE,MAXY,tide) and the level is
     that same number in metres.  Nothing on the staff can drift away from
     the sea, because it is the sea. */
  var p=uniformsNow();
  var wy=lerp(SHORE,MAXY,p);
  var gp=Math.max(0,Math.min(100,(((1-wy)*100)-48)/Math.max(_staffBottom-48,1)*100));
  var gs=gp.toFixed(2);
  if(uiGaugeMark&&lastGaugeY!==gs){
    uiGaugeMark.style.top=gs+'%';
    /* the number travels with the mark : a reading that stays behind while
       the thing it reads walks away is worse than no reading at all */
    if(uiGaugeRead) uiGaugeRead.style.top=gs+'%';
    lastGaugeY=gs;
  }
  var lv=(p*4.7).toFixed(2)+' M';
  if(lv!==lastGaugeV&&uiGaugeRead){ uiGaugeRead.textContent=lv; lastGaugeV=lv; }

  /* ---- the tide number ----
     The range is what the instrument quotes, the level is what it reads. */
  var tv=STATE==='TIDE'
    ? (p*4.7).toFixed(2)+' M'
    : '04.7 M';
  if(tv!==lastUITide&&uiTideEl){ uiTideEl.textContent=tv; lastUITide=tv; }
  /* the direction of the tide is in the state chip as well : on a wide frame
     it is written out here, on a narrow one the chip is the only place it
     can be read without pushing the sentence off the frame */
  var td=STATE==='TIDE'?' / '+(T<PH.h1?'RISING':'FALLING'):'';
  if(td!==lastUITideDir&&uiTideDirEl){ uiTideDirEl.textContent=td; lastUITideDir=td; }
}
function tideXScale(){
  var aspect=glc.width/Math.max(1,glc.height);
  return Math.max(0.64,Math.pow(Math.min(1,aspect),0.72));
}
function setSceneU(){
  gl.useProgram(progScene);
  gl.uniform2f(U.uRes,glc.width,glc.height);
  gl.uniform1f(U.uWaveXScale,tideXScale());
  gl.uniform1f(U.uTime,tsec);
  gl.uniform1f(U.uTide,uniformsNow());
  gl.uniform1f(U.uWave,waveAmp());
  gl.uniform1f(U.uCharge,charge);
  gl.uniform1f(U.uFlash,flash);
  gl.uniform1f(U.uWet,wetV);
  gl.uniform1f(U.uMark,wetMark);
  gl.uniform1f(U.uShore,SHORE);
  gl.uniform1f(U.uMax,MAXY);
  gl.uniform1f(U.uHorizon,HORIZON);
  gl.uniform2f(U.uSun,SUN[0],SUN[1]);
  gl.uniform1f(U.uSunR,SUN_R);
  gl.uniform1f(U.uDawn,DAWN_P);
  gl.uniform1f(U.uLit,LIT_P);
  gl.uniform1f(U.uSunUp,SUN_UP);
  gl.uniform4f(U.uBox,IBOX.x/W,1-(IBOX.y+IBOX.h)/H,IBOX.w/W,IBOX.h/H);
  gl.uniform2f(U.uMouse,mouse[0],mouse[1]);
  gl.uniform1f(U.uMouseOn,mouseOn);
}
function eroStep(dt){
  var dst=1-eroCur;
  gl.bindFramebuffer(gl.FRAMEBUFFER,eroFbo[dst]);
  gl.viewport(0,0,ERO_SIZE,ERO_SIZE);
  gl.useProgram(progEro);
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D,eroTex[eroCur]);
  gl.uniform1i(UE.uEro,0);
  gl.uniform1f(UE.uTime,tsec);
  gl.uniform1f(UE.uTide,uniformsNow());
  gl.uniform1f(UE.uWave,waveAmp());
  gl.uniform1f(UE.uShore,SHORE);
  gl.uniform1f(UE.uMax,MAXY);
  gl.uniform1f(UE.uWaveXScale,tideXScale());

  gl.uniform4f(UE.uBox,IBOX.x/W,1-(IBOX.y+IBOX.h)/H,IBOX.w/W,IBOX.h/H);
  drawQuad();
  eroCur=dst;
}
function renderSkyline(){
  if(!BUILD_COUNT||!progBuild) return;
  gl.useProgram(progBuild);
  gl.bindBuffer(gl.ARRAY_BUFFER,skylineBuf);
  var stride=10*4;
  gl.enableVertexAttribArray(BA.pos);
  gl.vertexAttribPointer(BA.pos,2,gl.FLOAT,false,stride,0);
  gl.enableVertexAttribArray(BA.local);
  gl.vertexAttribPointer(BA.local,2,gl.FLOAT,false,stride,2*4);
  gl.enableVertexAttribArray(BA.color);
  gl.vertexAttribPointer(BA.color,3,gl.FLOAT,false,stride,4*4);
  gl.enableVertexAttribArray(BA.style);
  gl.vertexAttribPointer(BA.style,3,gl.FLOAT,false,stride,7*4);
  gl.uniform1f(BU.uTime,tsec);
  gl.uniform2f(BU.uSun,SUN[0],SUN[1]);
  gl.uniform1f(BU.uLit,LIT_P);
  gl.enable(gl.BLEND);
  gl.blendFuncSeparate(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA,gl.ZERO,gl.ONE_MINUS_SRC_ALPHA);
  gl.drawArrays(gl.TRIANGLES,0,BUILD_COUNT);
  gl.disable(gl.BLEND);
}
function render(dt){
  if(STATE==='TIDE'){
    /* the erosion has to consume the same time as the tide : when it is
       starved the writing outlives the water that took it */
    var _en=dt>0.025?Math.min(6,Math.ceil(dt/0.025)):1,_es=dt/_en;
    for(var _ei=0;_ei<_en;_ei++) eroStep(_es);
  }

  /* ---- scene ---- */
  gl.bindFramebuffer(gl.FRAMEBUFFER,sceneFbo);
  gl.viewport(0,0,glc.width,glc.height);
  setSceneU();
  bindTex(0,texInk,U.uInk);
  bindTex(1,eroTex[eroCur],U.uEro);
  bindTex(2,texInkBlur,U.uInkBlur);
  drawQuad();
  renderSkyline();

  /* ---- bloom : bright pass, blur h, blur v ---- */
  var bw=BLOOMW,bh=BLOOMH;
  gl.bindFramebuffer(gl.FRAMEBUFFER,bloomFboA);
  gl.viewport(0,0,bw,bh);
  gl.useProgram(progBright);
  bindTex(0,texScene,UB.uTex);
  gl.uniform1f(UB.uThresh,1.45);
  drawQuad();

  gl.bindFramebuffer(gl.FRAMEBUFFER,bloomFboB);
  gl.useProgram(progBlur);
  bindTex(0,texBloomA,UBLUR.uTex);
  gl.uniform2f(UBLUR.uDir,1.4/bw,0);
  drawQuad();

  gl.bindFramebuffer(gl.FRAMEBUFFER,bloomFboA);
  bindTex(0,texBloomB,UBLUR.uTex);
  gl.uniform2f(UBLUR.uDir,0,1.4/bh);
  drawQuad();

  /* ---- post ---- */
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  gl.viewport(0,0,glc.width,glc.height);
  gl.useProgram(progPost);
  bindTex(0,texScene,UP.uTex);
  bindTex(1,texBloomA,UP.uBloom);
  gl.uniform2f(UP.uRes,glc.width,glc.height);
  gl.uniform1f(UP.uTime,tsec);
  gl.uniform1f(UP.uBloomK,0.085);

  gl.uniform1f(UP.uHorizon,HORIZON);
  gl.uniform1f(UP.uShore,SHORE);
  drawQuad();
}

/* A small readout, so the quality ladder can be seen rather than guessed.
   It is off unless the page is opened with ?q */
var QDEBUG=false,qEl=null,qLast=0,qFps=0,qN=0,qT0=0;
function qPanel(){
  if(qEl) return;
  qEl=document.createElement('div');
  qEl.style.cssText='position:fixed;left:8px;bottom:64px;z-index:40;font:11px/1.5 monospace;'
    +'color:#9fe;background:rgba(0,0,0,.65);padding:6px 9px;white-space:pre;pointer-events:none;';
  document.body.appendChild(qEl);
}
function qUpdate(){
  var now=performance.now();
  qN++;
  if(now-qT0>500){ qFps=qN*1000/(now-qT0); qN=0; qT0=now; }
  if(now-qLast<250) return;
  qLast=now;
  qPanel();
  qEl.textContent='quality step '+QSTEP+'/'+(QUALITY.length-1)
    +'\nDPR '+DPR.toFixed(2)+'   '+glc.width+'x'+glc.height
    +'  '+(glc.width*glc.height/1e6).toFixed(2)+'M px'
    +'\n'+qFps.toFixed(0)+' fps   window '+W+'x'+H;
}
function scheduleFrame(){
  if(DEAD||CTX_LOST||FRAME_PAUSED||FRAME_QUEUED||DBG) return;
  FRAME_QUEUED=true;
  requestAnimationFrame(frame);
}
function frame(now){
  /* Nothing can be drawn while the context is gone.  Do not keep asking for
     frames : wait for the browser to hand the context back. */
  FRAME_QUEUED=false;
  if(CTX_LOST) return;
  var rawDt=(now-prevT)/1000;
  var dt=rawDt; prevT=now;
  if(dt>0.1)dt=0.1; if(dt<0)dt=0;
  tsec+=dt;
  if(INTRO_ON&&!INTRO_HOLD&&INTRO_T<INTRO_DUR) INTRO_T+=dt;
  DAWN_P=INTRO_ON?Math.min(1,INTRO_T/1.30):1;
  LIT_P=INTRO_ON?Math.min(1,Math.max(0,(INTRO_T-0.80)/1.70)):1;
  var eD=DAWN_P*DAWN_P*(3-2*DAWN_P);
  SUN[1]=SUN_Y_START+(SUN_Y_END-SUN_Y_START)*eD;
  /* the walk : slow enough that the picture keeps its composition, quick
     enough that the azimuth moves while you are looking at it */
  SUN[0]=SUN_X0+SUN_DRIFT*Math.sin(tsec*SUN_DRIFT_W);
  /* how high the sun actually stands : the light of the world follows it */
  var rawUp=(SUN[1]+SUN_R-HORIZON)/(2*SUN_R);
  var rawEnd=(SUN_Y_END+SUN_R-HORIZON)/(2*SUN_R);
  var rawStart=(SUN_Y_START+SUN_R-HORIZON)/(2*SUN_R);
  SUN_UP=Math.min(1,Math.max(0,(rawUp-rawStart)/Math.max(rawEnd-rawStart,1e-6)));
  /* the acquisition reticle is pinned to the sun, so it has to climb with it */
  placeHUD();

  /* The quality ladder is driven by measurement. The old code waited
     ninety frames before it did anything, which on a slow machine is
     half a minute of stuttering, and it measured the warm-up frames
     (the first draw compiles the shader) into the average, so it
     over-corrected on machines that could have coped. */
  if(!DBG){
    /* A browser throttles requestAnimationFrame to about one frame a
       second when the page is in the background, and dt is clamped to
       0.1s, so a hidden tab looks exactly like a very slow machine.
       The ladder must not believe it, or the picture would be ruined
       for a tab nobody is looking at. */
    if(rawDt>0.35){ PERF_FRAMES=0; PERF_MS=0; PERF_WIN=0; PERF_WARMUP=0; }
    else if(PERF_WARMUP<PERF_WARMUP_NEED){ PERF_WARMUP++; }
    else{
      PERF_FRAMES++; PERF_MS+=dt*1000; PERF_WIN+=dt*1000;
      if(PERF_FRAMES>=24||PERF_WIN>=450){
        var avg=PERF_MS/PERF_FRAMES;
        var win=PERF_WIN;
        PERF_FRAMES=0; PERF_MS=0; PERF_WIN=0;
        /* below forty frames a second is felt, so the ladder drops there.
           It only climbs back when there is real headroom, which keeps
           it from oscillating between two rungs. */
        /* The ladder is given room to be wrong.  Twenty-five milliseconds
           was a line drawn in the middle of the two decisions, so a
           machine sitting at twenty-two walked down a rung, got lighter,
           and walked straight back up : the picture pulsed.  The two
           thresholds are now far apart, and after a change the ladder
           stays where it is long enough for the new rung to be measured
           on its own - longer after a climb, because a lighter rung has
           to prove that it can keep the frames. */
        if(PERF_HOLD>0){ PERF_HOLD-=win/1000; }
        else if(avg>28&&QSTEP<QUALITY.length-1){
          QSTEP++; applyQuality(); PERF_HOLD=1.0;
        }
        else if(avg<12&&QSTEP>0){
          QSTEP--; applyQuality(); PERF_HOLD=3.0;
        }
      }
    }
  }

  if(drawing){ idleT=0; charge=lerp(charge,1,dt*7); }
  /* while the tide is running the tube of light is at full charge : the
     surge set by startTide() used to be cancelled a frame later by the
     ordinary decay, so the sea god answered at half power */
  else if(STATE==='TIDE'){ idleT+=dt; charge=lerp(charge,1,dt*2.0); }
  else{ idleT+=dt; charge=lerp(charge,0.42,dt*2.0); }

  if(STATE==='IDLE'&&!drawing){ runRecognition(false); dbgPanel(); }
  if(!HOLD&&STATE==='IDLE'&&!drawing&&recog.ok&&idleT>0.8&&INTRO_T>=INTRO_DUR) startTide();
  if(STATE==='TIDE'){ T+=dt/TIDE_DUR; if(T>=1) finishTide(); }

  var wt=STATE==='TIDE'
    ? (T<PH.h1?1:Math.max(0,1-(T-PH.h1)/(PH.r1-PH.h1))) : 0;
  wetV=lerp(wetV,wt,1-Math.pow(0.02,dt));

  /* the tide leaves a mark on the sand, and the sand slowly dries */
  var wyNow=lerp(SHORE,MAXY,uniformsNow());
  if(STATE==='TIDE'){ if(wyNow>wetMark) wetMark=wyNow; }
  else wetMark=Math.max(0,wetMark-0.010*dt);

  flash=Math.max(0,flash-dt*1.15);

  if(inkDirty){
    uploadInk();
    inkDirty=false;
  }

  updateUI();
  if(QDEBUG) qUpdate();
  render(dt);
  scheduleFrame();
}
function lerp(a,b,t){ return a+(b-a)*t; }

/* ==================================================================
   7. INPUT
   ================================================================== */
glc.addEventListener('pointerdown',inkBegin);
window.addEventListener('pointermove',inkMove);
window.addEventListener('pointerup',inkEnd);
window.addEventListener('pointercancel',inkEnd);
window.addEventListener('blur',function(){ if(drawing) inkEnd(null); });
glc.addEventListener('pointerleave',function(){mouseOn=0;mouse=[-9,-9];});
glc.addEventListener('contextmenu',function(e){e.preventDefault();});
window.addEventListener('keydown',function(e){
  if(e.code==='Space'){ e.preventDefault(); if(STATE==='IDLE') startTide(); }
  else if(e.code==='KeyC'){ clearInk(); }
});

/* ==================================================================
   8. BOOT
   ================================================================== */
var rzT=null;
var PENDING_DEMO=0;
/* A resize re-allocates every target, and the frames that follow it are the
   re-allocating ones. They must not be read as "this machine is slow", so the
   ladder is put back on its warm-up : otherwise every window drag walks the
   quality down a rung for no reason at all. */
window.addEventListener('resize',function(){ clearTimeout(rzT); rzT=setTimeout(function(){ applyQuality(); },160); });
window.addEventListener('scroll',refreshGlRect,true);
window.addEventListener('orientationchange',function(){ setTimeout(refreshGlRect,60); });
/* coming back to the tab is not evidence about the machine */
document.addEventListener('visibilitychange',function(){
  PERF_FRAMES=0; PERF_MS=0; PERF_WIN=0; PERF_WARMUP=0; PERF_HOLD=0;
  FRAME_PAUSED=!!document.hidden;
  if(!FRAME_PAUSED){
    prevT=performance.now();
    scheduleFrame();
  }
});

function boot(){
  if(DEAD) return;
  initGL();
  layout();
  buildTPL();
  buildWordTPL();
  var qq=new URLSearchParams(location.search);
  HOLD=qq.has('notide');
  QDEBUG=qq.has('q')||qq.has('quality');

  var b=document.getElementById('boot');
  var q=new URLSearchParams(location.search);
  var skipIntro=q.has('freeze')||q.has('demo')||q.has('nointro');
  if(skipIntro){ INTRO_ON=0; INTRO_T=INTRO_DUR+1.0; document.body.className='nointro'; }
  else if(q.has('introT')){ INTRO_HOLD=1; INTRO_T=parseFloat(q.get('introT'))||0; document.body.className='nointro'; }
  else{ document.body.className='intro'; INTRO_T=0; }
  if(skipIntro){ if(b.parentNode)b.parentNode.removeChild(b); }
  else{ b.className='gone'; setTimeout(function(){ if(b.parentNode)b.parentNode.removeChild(b); },520); }

  if(q.has('demo')||q.has('freeze')||q.has('demoold')||q.has('old')){
    /* Wait for the multi-face template sheet before drawing the demo.
       ?demoold and ?old ask for the two characters, so they have to set the
       flag themselves : on their own they used to do nothing at all, which
       looked like the old ritual had been forgotten. */
    PENDING_DEMO=1;
  }
  scheduleFrame();
}
/* the word the piece asks for, unless the demonstration is asked for
   another one so that the matcher can be measured */
function wordText(){
  var q=new URLSearchParams(location.search);
  /* The case is left alone : ?word=RAFAYEL has to write the capital hand, or
     the matcher cannot be measured in it. */
  return (q.get('word')||WORD_T[0]);
}
/* the word, written for you : the same hand the templates know */
function wordStrokes(){
  var W=512,H=Math.max(64,Math.round(512*inkCv.height/inkCv.width));
  var c=document.createElement('canvas'); c.width=W; c.height=H;
  var g=c.getContext('2d');
  g.clearRect(0,0,W,H);
  g.imageSmoothingEnabled=true;
  g.imageSmoothingQuality='high';
  g.font='700 '+Math.round(H*0.34)+'px Arial, Helvetica, sans-serif';
  g.textAlign='center'; g.textBaseline='middle';
  g.fillStyle='#fff';
  g.fillText(wordText(),W*0.5,H*0.52);
  var im=g.getImageData(0,0,W,H).data, m=new Float32Array(W*H);
  for(var i=0;i<W*H;i++) m[i]=im[i*4]/255;
  var g2=inkCx;
  g2.clearRect(0,0,inkCv.width,inkCv.height);
  g2.imageSmoothingEnabled=true;
  g2.imageSmoothingQuality='high';
  var fine=erodeInkMask(m,W,H,1);
  var tc=document.createElement('canvas');tc.width=W;tc.height=H;
  var tg=tc.getContext('2d'),ti=tg.createImageData(W,H),td=ti.data;
  for(var i=0;i<W*H;i++){
    var o=i*4;
    var xi=i%W,yi=(i/W)|0;
    td[o]=255;td[o+1]=255;td[o+2]=255;
    var fibers=0.85+0.09*Math.sin(xi*0.23+yi*0.17)+0.06*Math.sin(xi*0.61-yi*0.37);
    var preserved=Math.max(m[i]*0.94,fine[i]);
    td[o+3]=Math.round(255*preserved*Math.max(0.82,Math.min(1.0,fibers)));
  }
  tg.putImageData(ti,0,0);
  g2.drawImage(tc,0,0,inkCv.width,inkCv.height);
  return strokesFromMask(m,W,H,0.25);
}
function writeDemo(){
  PENDING_DEMO=0;
  /* ?demoold still writes the two characters, for anyone who wants to see
     the older ritual answer as well */
  var q0=new URLSearchParams(location.search);
  strokes=(q0.has('demoold')||q0.has('old'))?glyphStrokes():wordStrokes();
  inkDirty=true; charge=1;
  /* Read the writing that has just been laid down before the state is
     switched to TIDE : runRecognition() only runs while the piece is idle,
     so a frozen frame would otherwise never know what was written and
     would report the tide instead of the answer. */
  runRecognition(true);
  var q=new URLSearchParams(location.search);
  if(q.has('freeze')){
    DBG=true; STATE='TIDE';
    T=parseFloat(q.get('freeze'))||0.5; charge=1; tsec=4.2;
    /* the same curve the live tide uses. The old expression divided by
       (1-PH.r1), which is zero, so a frozen tide at T=1 handed NaN to the
       shader and took the whole picture with it. */
    wetV=(T<PH.h1)?1.0:Math.max(0,1-(T-PH.h1)/(PH.r1-PH.h1));
    for(var e=0;e<14;e++) eroStep(0.28);
    prevT=performance.now();
    frame(prevT);
  }
}
/* An endless loading bar tells the player nothing at all.  If the machine
   cannot run the piece, the piece has to say so - and say why.  One place
   says it, so that every way of failing says it the same way. */
function fatal(reason){
  if(DEAD) return;
  DEAD=true;
  var b=document.getElementById('boot');
  window.__err=String(reason&&reason.stack||reason);
  if(window.console) console.error(window.__err);
  if(b){
    b.className='';
    b.style.opacity='1';
    b.innerHTML='<div style="max-width:36em;text-align:center;'
      +'font:500 11px/2.0 \'SFMono-Regular\',Consolas,monospace;'
      +'letter-spacing:.22em;text-transform:uppercase;color:rgba(198,214,244,.74)">'
      +'the sea god cannot be reached on this machine'
      +'<div style="margin-top:16px;letter-spacing:.08em;text-transform:none;'
      +'color:rgba(255,120,170,.68);font-size:10px;line-height:1.7;'
      +'word-break:break-word">'
      +String(window.__err).replace(/[<>]/g,'').slice(0,420)+'</div></div>';
  }
}
try{ boot(); }
catch(err){ fatal(err); }
